import { r as __toESM } from "../_runtime.mjs";
import { n as apiClient, r as settingsService, t as BASE_URL } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime, n as AvatarFallback$1, r as AvatarImage$1, t as Avatar$1 } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { n as useTheme } from "./theme-G0Ttq5RK.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as Input, r as cn } from "./button-juXZH0rY.mjs";
import { t as authService } from "./authService-CTf_Ta8y.mjs";
import { _ as useNavigate, g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { $ as ChevronLeft, A as Moon, B as LayoutDashboard, J as Circle, K as Clock, M as Menu, P as LogOut, Q as ChevronRight, S as Receipt, _ as ShieldAlert, at as BookOpen, b as Search, i as Users, it as CalendarCheck, n as Utensils, nt as Check, q as ClipboardList, st as BedDouble, t as X, u as Sun, v as Settings } from "../_libs/lucide-react.mjs";
import { a as DropdownMenuItemIndicator, c as DropdownMenuRadioItem$1, d as DropdownMenuSubTrigger$1, f as DropdownMenuTrigger$1, i as DropdownMenuItem$1, l as DropdownMenuSeparator$1, n as DropdownMenuCheckboxItem$1, o as DropdownMenuLabel$1, r as DropdownMenuContent$1, s as DropdownMenuPortal, t as DropdownMenu$1, u as DropdownMenuSubContent$1 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-C6Y1qr1C.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEFAULT_PERMISSIONS = {
	dashboard: { access: true },
	rooms: {
		access: true,
		add: true,
		edit: true,
		delete: true
	},
	bookings: {
		access: true,
		add: true,
		edit: true,
		delete: true
	},
	tables: {
		access: true,
		add: true,
		edit: true,
		delete: true
	},
	waitlist: {
		access: true,
		add: true,
		edit: true,
		delete: true
	},
	orders: {
		access: true,
		add: true,
		edit: true,
		delete: true,
		waiterSide: true,
		kitchenSide: true
	},
	menu: {
		access: true,
		add: true,
		edit: true,
		delete: true
	},
	billing: {
		access: true,
		add: true,
		edit: true,
		delete: true
	},
	employees: {
		access: true,
		add: true,
		edit: true,
		delete: true
	},
	settings: {
		access: true,
		edit: true
	}
};
var WAITER_PERMISSIONS = {
	dashboard: { access: false },
	rooms: {
		access: false,
		add: false,
		edit: false,
		delete: false
	},
	bookings: {
		access: false,
		add: false,
		edit: false,
		delete: false
	},
	tables: {
		access: true,
		add: true,
		edit: true,
		delete: false
	},
	waitlist: {
		access: true,
		add: true,
		edit: true,
		delete: true
	},
	orders: {
		access: true,
		add: true,
		edit: true,
		delete: false,
		waiterSide: true,
		kitchenSide: false
	},
	menu: {
		access: false,
		add: false,
		edit: false,
		delete: false
	},
	billing: {
		access: false,
		add: false,
		edit: false,
		delete: false
	},
	employees: {
		access: false,
		add: false,
		edit: false,
		delete: false
	},
	settings: {
		access: false,
		edit: false
	}
};
var CHEF_PERMISSIONS = {
	dashboard: { access: false },
	rooms: {
		access: false,
		add: false,
		edit: false,
		delete: false
	},
	bookings: {
		access: false,
		add: false,
		edit: false,
		delete: false
	},
	tables: {
		access: false,
		add: false,
		edit: false,
		delete: false
	},
	waitlist: {
		access: false,
		add: false,
		edit: false,
		delete: false
	},
	orders: {
		access: true,
		add: false,
		edit: true,
		delete: false,
		waiterSide: false,
		kitchenSide: true
	},
	menu: {
		access: true,
		add: false,
		edit: true,
		delete: false
	},
	billing: {
		access: false,
		add: false,
		edit: false,
		delete: false
	},
	employees: {
		access: false,
		add: false,
		edit: false,
		delete: false
	},
	settings: {
		access: false,
		edit: false
	}
};
var STORAGE_KEY = "hospitality_roles";
var permissionService = {
	parseBackendPermissions(flatList) {
		const rolesMap = {};
		const lockMap = {};
		const systemRoles = [
			"Admin",
			"Waiter",
			"Chef"
		];
		const systemTemplates = [
			DEFAULT_PERMISSIONS,
			WAITER_PERMISSIONS,
			CHEF_PERMISSIONS
		];
		systemRoles.forEach((roleName, idx) => {
			rolesMap[roleName] = JSON.parse(JSON.stringify(systemTemplates[idx]));
			lockMap[roleName] = true;
		});
		flatList.forEach((row) => {
			const roleName = row.roleName;
			const mod = row.moduleName.toLowerCase();
			const act = row.actionName;
			if (!rolesMap[roleName]) {
				rolesMap[roleName] = JSON.parse(JSON.stringify(DEFAULT_PERMISSIONS));
				Object.keys(rolesMap[roleName]).forEach((moduleKey) => {
					const m = rolesMap[roleName][moduleKey];
					Object.keys(m).forEach((actionKey) => {
						m[actionKey] = false;
					});
				});
			}
			lockMap[roleName] = row.isLocked;
			if (rolesMap[roleName][mod]) rolesMap[roleName][mod][act] = row.isAllowed;
		});
		return Object.entries(rolesMap).map(([name, permissions]) => ({
			name,
			isSystem: systemRoles.includes(name),
			permissions
		}));
	},
	async getRoles() {
		try {
			const flatList = await apiClient.get("/api/RolePermission");
			const roles = this.parseBackendPermissions(flatList);
			localStorage.setItem(STORAGE_KEY, JSON.stringify(roles));
			return roles;
		} catch (e) {
			console.warn("Failed to fetch roles from backend, falling back to local cache", e);
			const saved = localStorage.getItem(STORAGE_KEY);
			if (saved) try {
				return JSON.parse(saved);
			} catch (err) {}
			return [
				{
					name: "Admin",
					isSystem: true,
					permissions: DEFAULT_PERMISSIONS
				},
				{
					name: "Waiter",
					isSystem: true,
					permissions: WAITER_PERMISSIONS
				},
				{
					name: "Chef",
					isSystem: true,
					permissions: CHEF_PERMISSIONS
				}
			];
		}
	},
	async saveRolePermissions(roleName, permissions) {
		const promises = [];
		Object.entries(permissions).forEach(([moduleName, actions]) => {
			Object.entries(actions).forEach(([actionName, isAllowed]) => {
				promises.push(apiClient.post("/api/RolePermission", {
					roleName,
					moduleName,
					actionName,
					isAllowed: !!isAllowed,
					isLocked: [
						"admin",
						"waiter",
						"chef"
					].includes(roleName.toLowerCase())
				}));
			});
		});
		await Promise.all(promises);
		await this.getRoles();
	},
	async deleteRole(roleName) {
		await apiClient.delete(`/api/RolePermission/role/${roleName}`);
		await this.getRoles();
	},
	getRolePermissions(roleName) {
		if (typeof window === "undefined") return DEFAULT_PERMISSIONS;
		const saved = localStorage.getItem(STORAGE_KEY);
		if (saved) try {
			const role = JSON.parse(saved).find((r) => r.name.toLowerCase() === roleName.toLowerCase());
			if (role) return role.permissions;
		} catch (e) {}
		if (roleName.toLowerCase() === "waiter") return WAITER_PERMISSIONS;
		if (roleName.toLowerCase() === "chef") return CHEF_PERMISSIONS;
		return DEFAULT_PERMISSIONS;
	},
	hasPermission(roleName, module, action = "access") {
		const modulePerm = this.getRolePermissions(roleName)[module];
		if (!modulePerm) return false;
		return !!modulePerm[action];
	}
};
var badgeVariants = cva("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
		secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
		destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var DropdownMenu = DropdownMenu$1;
var DropdownMenuTrigger = DropdownMenuTrigger$1;
var DropdownMenuSubTrigger = import_react.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuSubTrigger$1, {
	ref,
	className: cn("flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", inset && "pl-8", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "ml-auto" })]
}));
DropdownMenuSubTrigger.displayName = DropdownMenuSubTrigger$1.displayName;
var DropdownMenuSubContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSubContent$1, {
	ref,
	className: cn("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}));
DropdownMenuSubContent.displayName = DropdownMenuSubContent$1.displayName;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent$1, {
	ref,
	sideOffset,
	className: cn("z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}) }));
DropdownMenuContent.displayName = DropdownMenuContent$1.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem$1, {
	ref,
	className: cn("relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0", inset && "pl-8", className),
	...props
}));
DropdownMenuItem.displayName = DropdownMenuItem$1.displayName;
var DropdownMenuCheckboxItem = import_react.forwardRef(({ className, children, checked, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuCheckboxItem$1, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	checked,
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), children]
}));
DropdownMenuCheckboxItem.displayName = DropdownMenuCheckboxItem$1.displayName;
var DropdownMenuRadioItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuRadioItem$1, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-2 w-2 fill-current" }) })
	}), children]
}));
DropdownMenuRadioItem.displayName = DropdownMenuRadioItem$1.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel$1, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
	...props
}));
DropdownMenuLabel.displayName = DropdownMenuLabel$1.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator$1, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
DropdownMenuSeparator.displayName = DropdownMenuSeparator$1.displayName;
var DropdownMenuShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("ml-auto text-xs tracking-widest opacity-60", className),
		...props
	});
};
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";
var Avatar = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar$1, {
	ref,
	className: cn("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className),
	...props
}));
Avatar.displayName = Avatar$1.displayName;
var AvatarImage = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarImage$1, {
	ref,
	className: cn("aspect-square h-full w-full", className),
	...props
}));
AvatarImage.displayName = AvatarImage$1.displayName;
var AvatarFallback = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback$1, {
	ref,
	className: cn("flex h-full w-full items-center justify-center rounded-full bg-muted", className),
	...props
}));
AvatarFallback.displayName = AvatarFallback$1.displayName;
var NAV = [
	{
		to: "/dashboard",
		label: "Dashboard",
		icon: LayoutDashboard
	},
	{
		to: "/rooms",
		label: "Rooms",
		icon: BedDouble
	},
	{
		to: "/bookings",
		label: "Bookings",
		icon: CalendarCheck
	},
	{
		to: "/tables",
		label: "Tables",
		icon: Utensils
	},
	{
		to: "/waitlist",
		label: "Waiting List",
		icon: Clock
	},
	{
		to: "/orders",
		label: "Orders",
		icon: ClipboardList
	},
	{
		to: "/menu",
		label: "Menu",
		icon: BookOpen
	},
	{
		to: "/billing",
		label: "Billing",
		icon: Receipt
	},
	{
		to: "/employees",
		label: "Employees",
		icon: Users
	},
	{
		to: "/clients",
		label: "Clients",
		icon: Users
	},
	{
		to: "/settings",
		label: "Settings",
		icon: Settings
	}
];
function AppShell({ children, title, breadcrumbs }) {
	const [collapsed, setCollapsed] = (0, import_react.useState)(false);
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (r) => r.location.pathname });
	const { data: roles = [] } = useQuery({
		queryKey: ["roles"],
		queryFn: () => permissionService.getRoles()
	});
	const userRaw = typeof window !== "undefined" ? localStorage.getItem("user") : null;
	const user = userRaw ? JSON.parse(userRaw) : {
		name: "Marcus Ellery",
		role: "Admin",
		email: "manager@aurelia.co",
		photoPath: void 0
	};
	const currentPath = pathname.split("/")[1] || "dashboard";
	const permKey = currentPath === "waitinglist" || currentPath === "waitlist" ? "waitlist" : currentPath === "" ? "dashboard" : currentPath;
	const hasAccess = (() => {
		const roleConfig = roles.find((r) => r.name.toLowerCase() === user.role.toLowerCase());
		if (roleConfig) return !!roleConfig.permissions[permKey]?.access;
		return permissionService.hasPermission(user.role, permKey, "access");
	})();
	const firstAllowedRoute = NAV.find((item) => {
		const key = item.to.replace("/", "");
		const pk = key === "waitinglist" || key === "waitlist" ? "waitlist" : key;
		const roleConfig = roles.find((r) => r.name.toLowerCase() === user.role.toLowerCase());
		if (roleConfig) return !!roleConfig.permissions[pk]?.access;
		return permissionService.hasPermission(user.role, pk, "access");
	});
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if ((currentPath === "dashboard" || currentPath === "") && !hasAccess && firstAllowedRoute) navigate({ to: firstAllowedRoute.to });
	}, [
		currentPath,
		hasAccess,
		firstAllowedRoute,
		navigate
	]);
	const { data: settings } = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.getGeneralSettings(),
		staleTime: 1e3 * 60 * 5
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen w-full bg-background text-foreground flex",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: cn("hidden md:flex flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border sticky top-0 h-screen transition-[width] duration-300 ease-out", collapsed ? "w-[76px]" : "w-[260px]"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "h-16 flex items-center gap-3 px-4 border-b border-sidebar-border overflow-hidden shrink-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-9 rounded-xl bg-sidebar-primary flex items-center justify-center shadow-[0_0_20px_-4px_var(--sidebar-primary)] shrink-0",
								children: settings?.logoUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: `${BASE_URL}${settings.logoUrl}`,
									alt: "Logo",
									className: "w-full h-full object-contain rounded-xl p-1"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-serif font-semibold text-sidebar-primary-foreground text-lg",
									children: settings?.name?.[0]?.toUpperCase() || "A"
								})
							}),
							!collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-serif text-lg leading-tight truncate",
									children: settings?.name || "Aurelia"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] uppercase tracking-[0.18em] text-sidebar-foreground/60 truncate",
									children: "Hospitality OS"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setCollapsed((c) => !c),
								className: "text-sidebar-foreground/60 hover:text-sidebar-primary transition",
								"aria-label": "Toggle sidebar",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: cn("size-4 transition-transform", collapsed && "rotate-180") })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex-1 overflow-y-auto py-4 px-3 space-y-1",
						children: NAV.filter((item) => {
							const key = item.to.replace("/", "");
							const permKey = key === "waitinglist" || key === "waitlist" ? "waitlist" : key;
							const roleConfig = roles.find((r) => r.name.toLowerCase() === user.role.toLowerCase());
							if (roleConfig) return !!roleConfig.permissions[permKey]?.access;
							return permissionService.hasPermission(user.role, permKey, "access");
						}).map((item) => {
							const active = pathname.startsWith(item.to);
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: cn("group relative flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all", active ? "bg-sidebar-accent text-sidebar-primary" : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/60"),
								children: [
									active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-full bg-sidebar-primary shadow-[0_0_10px_var(--sidebar-primary)]" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: cn("size-[18px] shrink-0 transition-transform group-hover:scale-110", active && "text-sidebar-primary") }),
									!collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: item.label
									})
								]
							}, item.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("border-t border-sidebar-border p-3", collapsed && "px-2"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("rounded-xl p-3 bg-sidebar-accent/60 overflow-hidden", collapsed && "hidden"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] uppercase tracking-widest text-sidebar-foreground/50",
									children: "Property"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-serif mt-0.5 truncate",
									children: settings?.name || "The Aurelia Grand"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-sidebar-foreground/60 mt-1 truncate",
									children: settings?.address || "Lisbon · Portugal"
								})
							]
						})
					})
				]
			}),
			mobileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:hidden fixed inset-0 z-50",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 bg-black/50 backdrop-blur-sm",
					onClick: () => setMobileOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "absolute left-0 top-0 h-full w-72 bg-sidebar text-sidebar-foreground p-4 animate-in slide-in-from-left duration-300",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between mb-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-9 rounded-xl bg-sidebar-primary flex items-center justify-center shrink-0",
								children: settings?.logoUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: `http://localhost:5157${settings.logoUrl}`,
									alt: "Logo",
									className: "w-full h-full object-contain rounded-xl p-1"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-serif font-semibold text-sidebar-primary-foreground text-lg",
									children: settings?.name?.[0]?.toUpperCase() || "A"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-serif text-lg truncate",
								children: settings?.name || "Aurelia"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setMobileOpen(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "space-y-1",
						children: NAV.filter((item) => {
							const key = item.to.replace("/", "");
							const permKey = key === "waitinglist" || key === "waitlist" ? "waitlist" : key;
							const roleConfig = roles.find((r) => r.name.toLowerCase() === user.role.toLowerCase());
							if (roleConfig) return !!roleConfig.permissions[permKey]?.access;
							return permissionService.hasPermission(user.role, permKey, "access");
						}).map((item) => {
							const Icon = item.icon;
							const active = pathname.startsWith(item.to);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								onClick: () => setMobileOpen(false),
								className: cn("flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm", active ? "bg-sidebar-accent text-sidebar-primary" : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-[18px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
							}, item.to);
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 flex flex-col min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopNav, { onOpenMobile: () => setMobileOpen(true) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						className: "flex-1 pb-20 md:pb-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 md:px-8 pt-6",
							children: [breadcrumbs && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mb-2 flex items-center gap-1.5",
								children: breadcrumbs.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1.5",
									children: [b.to ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: b.to,
										className: "hover:text-foreground",
										children: b.label
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: b.label }), i < breadcrumbs.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "opacity-40",
										children: "/"
									})]
								}, i))
							}), !hasAccess ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-center justify-center min-h-[60vh] text-center p-6 bg-background rounded-2xl border border-border/40 mt-6 max-w-lg mx-auto shadow-xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-16 rounded-2xl bg-destructive/10 text-destructive flex items-center justify-center mb-5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-8" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-serif text-2xl font-bold mb-2",
										children: "Access Denied"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-muted-foreground text-sm max-w-sm mb-6",
										children: [
											"You do not have permission to view the ",
											title || currentPath,
											" module. Please contact your administrator."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/dashboard",
										className: "text-primary hover:underline font-semibold text-sm",
										children: "Back to Dashboard"
									})
								]
							}) : children]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileBottomNav, {})
				]
			})
		]
	});
}
function TopNav({ onOpenMobile }) {
	const { theme, toggle } = useTheme();
	const getPhotoUrl = (path) => {
		if (!path) return void 0;
		if (path.startsWith("http")) return path;
		return `http://localhost:5157${path}`;
	};
	const userRaw = typeof window !== "undefined" ? localStorage.getItem("user") : null;
	const user = userRaw ? JSON.parse(userRaw) : {
		name: "Marcus Ellery",
		role: "Admin",
		email: "manager@aurelia.co",
		photoPath: void 0
	};
	const photoPath = user.photoPath || user.PhotoPath;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "h-16 px-4 md:px-6 flex items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "md:hidden p-2 -ml-2",
					onClick: onOpenMobile,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 max-w-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Search rooms, guests, bookings, orders…",
						className: "pl-9 h-10 rounded-xl bg-muted/50 border-transparent focus-visible:bg-background"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: toggle,
					"aria-label": "Toggle theme",
					className: "relative h-10 w-10 rounded-xl bg-muted/60 hover:bg-muted flex items-center justify-center transition-all group",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: cn("size-[18px] transition-all duration-500", theme === "dark" ? "rotate-90 scale-0 opacity-0" : "rotate-0 scale-100") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: cn("absolute size-[18px] transition-all duration-500", theme === "dark" ? "rotate-0 scale-100 text-primary" : "-rotate-90 scale-0 opacity-0") })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "flex items-center gap-3 pl-2 pr-1 h-10 rounded-xl hover:bg-muted/60 transition",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Avatar, {
								className: "size-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarImage, { src: getPhotoUrl(photoPath) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback, { children: user.name ? user.name[0] : "ME" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden sm:block text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium leading-none",
									children: user.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] uppercase tracking-widest text-muted-foreground mt-0.5",
									children: user.email
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "secondary",
								className: "hidden md:inline-flex text-[10px] bg-primary/10 text-primary border-primary/20",
								children: user.role
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
					align: "end",
					className: "w-56",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: "My Account" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, { children: "Profile" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, { children: "Preferences" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
							onSelect: async () => {
								try {
									await authService.logout();
								} catch (e) {
									console.error("Logout request failed", e);
								}
								localStorage.removeItem("user");
								window.location.href = "/";
							},
							className: "flex items-center gap-2 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), " Sign out"]
						})
					]
				})] })
			]
		})
	});
}
function MobileBottomNav() {
	const pathname = useRouterState({ select: (r) => r.location.pathname });
	const userRaw = typeof window !== "undefined" ? localStorage.getItem("user") : null;
	const user = userRaw ? JSON.parse(userRaw) : { role: "Admin" };
	const { data: roles = [] } = useQuery({
		queryKey: ["roles"],
		queryFn: () => permissionService.getRoles()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "md:hidden fixed bottom-0 inset-x-0 z-30 bg-background/90 backdrop-blur-xl border-t border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-5 h-16",
			children: NAV.filter((item) => {
				const key = item.to.replace("/", "");
				const permKey = key === "waitinglist" || key === "waitlist" ? "waitlist" : key;
				const roleConfig = roles.find((r) => r.name.toLowerCase() === user.role.toLowerCase());
				if (roleConfig) return !!roleConfig.permissions[permKey]?.access;
				return permissionService.hasPermission(user.role, permKey, "access");
			}).slice(0, 5).map((item) => {
				const Icon = item.icon;
				const active = pathname.startsWith(item.to);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					className: cn("flex flex-col items-center justify-center gap-1 text-[10px]", active ? "text-primary" : "text-muted-foreground"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label.split(" ")[0] })]
				}, item.to);
			})
		})
	});
}
function StatusBadge({ status, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium border", {
			Available: "bg-success/15 text-success border-success/30",
			Free: "bg-success/15 text-success border-success/30",
			"Ready/Clean": "bg-success/15 text-success border-success/30",
			Active: "bg-success/15 text-success border-success/30",
			"Checked-in": "bg-success/15 text-success border-success/30",
			Confirmed: "bg-info/15 text-info border-info/30",
			"In Progress": "bg-info/15 text-info border-info/30",
			Preparing: "bg-info/15 text-info border-info/30",
			Notified: "bg-info/15 text-info border-info/30",
			New: "bg-info/15 text-info border-info/30",
			Reserved: "bg-warning/15 text-warning-foreground [color:var(--warning)] border-warning/30",
			"Awaiting Inspection": "bg-warning/15 [color:var(--warning)] border-warning/30",
			Waiting: "bg-warning/15 [color:var(--warning)] border-warning/30",
			Pending: "bg-warning/15 [color:var(--warning)] border-warning/30",
			"No-Show Risk": "bg-warning/15 [color:var(--warning)] border-warning/30",
			"Needs Cleaning": "bg-warning/15 [color:var(--warning)] border-warning/30",
			"Inspection Pending": "bg-info/15 text-info border-info/30",
			"Cleaning In Progress": "bg-info/15 text-info border-info/30",
			Occupied: "bg-destructive/15 text-destructive border-destructive/30",
			Cancelled: "bg-destructive/15 text-destructive border-destructive/30",
			"No-Show": "bg-destructive/15 text-destructive border-destructive/30",
			Urgent: "bg-destructive/15 text-destructive border-destructive/30",
			High: "bg-destructive/15 text-destructive border-destructive/30",
			Ready: "bg-success/15 text-success border-success/30",
			Served: "bg-muted text-muted-foreground border-border",
			Merged: "bg-special/15 [color:var(--special)] border-special/30",
			Cleaning: "bg-muted text-muted-foreground border-border",
			Maintenance: "bg-muted text-muted-foreground border-border",
			Inactive: "bg-muted text-muted-foreground border-border",
			"On Leave": "bg-muted text-muted-foreground border-border"
		}[status] ?? "bg-muted text-muted-foreground border-border", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-current opacity-70" }), status]
	});
}
//#endregion
export { StatusBadge as a, AvatarImage as i, Avatar as n, permissionService as o, AvatarFallback as r, AppShell as t };
