import { n as apiClient } from "./settingsService-Dilksh94.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/authService-CTf_Ta8y.js
var authService = {
	login: (credentials) => apiClient.post("/api/Auth/login", credentials),
	logout: () => apiClient.post("/api/Auth/logout", {})
};
//#endregion
export { authService as t };
