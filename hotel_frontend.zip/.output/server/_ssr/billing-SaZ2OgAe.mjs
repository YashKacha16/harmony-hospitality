import { r as settingsService } from "./settingsService-Dilksh94.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { a as printViaIframe, n as Input, t as Button } from "./button-juXZH0rY.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { I as LoaderCircle, w as Printer } from "../_libs/lucide-react.mjs";
import { a as StatusBadge, t as AppShell } from "./app-shell-C6Y1qr1C.mjs";
import { t as Card } from "./card-DNWGqbqR.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CUQVyHA-.mjs";
import { t as billingService } from "./billingService-BDz7A2Pa.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billing-SaZ2OgAe.js
var import_jsx_runtime = require_jsx_runtime();
function BillingPage() {
	const queryClient = useQueryClient();
	const { data: bills, isLoading } = useQuery({
		queryKey: ["restaurantBills"],
		queryFn: () => billingService.getBills()
	});
	const { data: settings } = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.getGeneralSettings(),
		staleTime: 1e3 * 60 * 5
	});
	const currencySymbol = settings?.currency?.match(/\((.*?)\)/)?.[1] || settings?.currency || "$";
	const payBillMutation = useMutation({
		mutationFn: ({ id, method }) => billingService.payBill(id, method),
		onSuccess: () => {
			toast.success("Bill marked as paid");
			queryClient.invalidateQueries({ queryKey: ["restaurantBills"] });
		}
	});
	const updateBillMutation = useMutation({
		mutationFn: ({ id, data }) => billingService.updateBill(id, data),
		onSuccess: () => {
			toast.success("Bill updated successfully");
			queryClient.invalidateQueries({ queryKey: ["restaurantBills"] });
		},
		onError: (err) => {
			toast.error(err.message || "Failed to update bill");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Billing",
		breadcrumbs: [{
			label: "Home",
			to: "/dashboard"
		}, { label: "Billing" }],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-4",
			children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center p-8 text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-muted-foreground size-8 mx-auto" })
			}) : bills?.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center p-8 text-muted-foreground border border-dashed border-border rounded-2xl",
				children: "No restaurant bills generated yet."
			}) : bills?.map((bill) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-6 rounded-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-serif text-2xl",
							children: ["Invoice ", bill.billNumber]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground",
							children: [
								bill.order?.type === "DineIn" && `Table ${bill.order.tableName || "--"}`,
								bill.order?.type === "RoomService" && `Room ${bill.order.roomNumber || "--"}`,
								bill.order?.type === "Parcel" && (bill.order.parcelCode ? `Parcel (Code: ${bill.order.parcelCode})` : "Parcel")
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: bill.status })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-border mt-4 pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-medium mb-2",
								children: "Order Items"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "text-sm space-y-1",
								children: bill.order?.items.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										item.quantity,
										"× ",
										item.name,
										" ",
										item.status === "Cancelled" ? "(Cancelled)" : ""
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: item.status === "Cancelled" ? "line-through text-muted-foreground" : "",
										children: [currencySymbol, (item.priceAtOrder * item.quantity).toFixed(2)]
									})]
								}, idx))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 pt-3 border-t border-border w-72 ml-auto text-sm space-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										l: "Subtotal",
										v: `${currencySymbol}${bill.subtotal.toFixed(2)}`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										l: `Service charge (${bill.serviceChargePercent ?? 10}%)`,
										v: `${currencySymbol}${bill.serviceCharge.toFixed(2)}`
									}),
									bill.cgstPercent != null && bill.sgstPercent != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										l: `CGST (${bill.cgstPercent}%)`,
										v: `${currencySymbol}${(bill.taxAmount * bill.cgstPercent / (bill.taxPercent || 18)).toFixed(2)}`
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										l: `SGST (${bill.sgstPercent}%)`,
										v: `${currencySymbol}${(bill.taxAmount * bill.sgstPercent / (bill.taxPercent || 18)).toFixed(2)}`
									})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										l: `Tax (${bill.taxPercent ?? 18}%)`,
										v: `${currencySymbol}${bill.taxAmount.toFixed(2)}`
									}),
									bill.discount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										l: "Discount",
										v: `-${currencySymbol}${bill.discount.toFixed(2)}`,
										tone: "text-success"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "border-t border-border pt-2 mt-2 flex justify-between font-serif text-lg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total due" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-primary",
											children: [currencySymbol, bill.totalAmount.toFixed(2)]
										})]
									})
								]
							})
						]
					}),
					bill.status !== "Paid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 pt-4 border-t border-border flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-3 flex-wrap text-xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground font-medium",
									children: "Discount ($):"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									placeholder: "0",
									className: "w-20 h-8 rounded-lg text-xs",
									defaultValue: bill.discount || 0,
									onKeyDown: (e) => {
										if (e.key === "Enter") {
											const val = parseFloat(e.target.value) || 0;
											updateBillMutation.mutate({
												id: bill.id,
												data: { discount: val }
											});
										}
									},
									onBlur: (e) => {
										const val = parseFloat(e.target.value) || 0;
										if (val !== bill.discount) updateBillMutation.mutate({
											id: bill.id,
											data: { discount: val }
										});
									}
								})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-end items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									className: "rounded-lg",
									onClick: () => printViaIframe(`/print/${bill.id}`),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4 mr-1" }), " Print"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									defaultValue: "Card",
									onValueChange: (val) => {
										window[`payMethod_${bill.id}`] = val;
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "w-32 rounded-lg",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Card" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "Cash",
											children: "Cash"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "Card",
											children: "Card"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "UPI",
											children: "UPI"
										})
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "rounded-lg bg-primary text-primary-foreground copper-glow",
									onClick: () => {
										const method = window[`payMethod_${bill.id}`] || "Card";
										payBillMutation.mutate({
											id: bill.id,
											method
										});
									},
									disabled: payBillMutation.isPending,
									children: payBillMutation.isPending ? "Processing..." : "Mark as Paid"
								})
							]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 pt-4 border-t border-border flex justify-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							className: "rounded-lg",
							onClick: () => printViaIframe(`/print/${bill.id}`),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4 mr-1" }), " Print"]
						})
					})
				]
			}, bill.id))
		})
	});
}
function Row({ l, v, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: l
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: tone,
			children: v
		})]
	});
}
//#endregion
export { BillingPage as component };
