import { n as apiClient } from "./settingsService-Dilksh94.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billingService-BDz7A2Pa.js
var billingService = {
	getBills: async () => {
		return await apiClient.get("/api/billing");
	},
	getRoomBills: async () => {
		return await apiClient.get("/api/billing/room-bills");
	},
	getBill: async (id) => {
		return await apiClient.get(`/api/billing/${id}`);
	},
	generateBill: async (data) => {
		const payload = typeof data === "number" ? { orderId: data } : data;
		return await apiClient.post("/api/billing/generate", payload);
	},
	updateBill: async (id, data) => {
		return await apiClient.put(`/api/billing/${id}`, data);
	},
	payBill: async (id, paymentMethod) => {
		return await apiClient.post(`/api/billing/${id}/pay`, { paymentMethod });
	}
};
//#endregion
export { billingService as t };
