import { n as apiClient } from "./settingsService-Dilksh94.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bookingService-TCPCmwod.js
var bookingService = {
	getAll: async (status, propertyId) => {
		let url = "/api/Bookings";
		const params = new URLSearchParams();
		if (status) params.append("status", status);
		if (propertyId) params.append("propertyId", propertyId.toString());
		const qString = params.toString();
		if (qString) url += `?${qString}`;
		return apiClient.get(url);
	},
	getById: async (id) => {
		return apiClient.get(`/api/Bookings/${id}`);
	},
	create: async (data) => {
		return apiClient.post("/api/Bookings", data);
	},
	markNoShow: async (id) => {
		return apiClient.request(`/api/Bookings/${id}/mark-no-show`, { method: "PATCH" });
	},
	update: async (id, data) => {
		return apiClient.put(`/api/Bookings/${id}`, data);
	},
	getRoomBill: async (id) => {
		return apiClient.get(`/api/Bookings/${id}/bill`);
	},
	checkout: async (id, paymentMethod) => {
		return apiClient.post(`/api/Bookings/${id}/checkout`, { paymentMethod });
	}
};
//#endregion
export { bookingService as t };
