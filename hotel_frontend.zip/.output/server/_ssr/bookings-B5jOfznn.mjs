import { r as __toESM } from "../_runtime.mjs";
import { r as settingsService } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { a as printViaIframe, i as extractCurrencySymbol, n as Input, r as cn, t as Button } from "./button-juXZH0rY.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { I as LoaderCircle, P as LogOut, S as Receipt, T as Plus, Y as CircleCheckBig, a as UserCheck, ct as Ban, n as Utensils, nt as Check, o as Upload, s as TriangleAlert, w as Printer } from "../_libs/lucide-react.mjs";
import { o as permissionService, t as AppShell } from "./app-shell-C6Y1qr1C.mjs";
import { t as Card } from "./card-DNWGqbqR.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CUQVyHA-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-DDHupNVK.mjs";
import { t as bookingService } from "./bookingService-TCPCmwod.mjs";
import { a as SheetTitle, i as SheetHeader, n as SheetContent, o as SheetTrigger, t as Sheet } from "./sheet-DgrR67wC.mjs";
import { t as Label } from "./label-Bkz_RwW1.mjs";
import { t as roomService } from "./roomService-D1zUMbty.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, t as Dialog } from "./dialog-BtIFXM_M.mjs";
import { t as Textarea } from "./textarea-CiyhCZVs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bookings-B5jOfznn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReservationsTab({ bookings, onCancel, onNoShow, onCheckIn, canCheckIn = true, canCancel = true }) {
	const { data: settings } = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.getGeneralSettings()
	});
	const currencySymbol = settings?.currency ? settings.currency.match(/\(([^)]+)\)/)?.[1] || settings.currency : "₹";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "rounded-2xl overflow-hidden mt-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "bg-muted/40",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-left text-xs uppercase tracking-widest text-muted-foreground border-b",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Booking ID"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Guest"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Room"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Dates & Time"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Source"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Advance"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right",
								children: "Actions"
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [bookings.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 7,
					className: "px-4 py-8 text-center text-muted-foreground",
					children: "No upcoming reservations found."
				}) }), bookings.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b last:border-0 hover:bg-muted/10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-4 py-3 font-medium",
							children: ["#", b.bookingCode || b.id]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-medium",
								children: b.guestName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: b.phone
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: b.room ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-medium",
								children: ["Room ", b.room.number]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-muted-foreground",
								children: ["Cat ", b.room.categoryId]
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Unassigned"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								new Date(b.checkInDate).toLocaleDateString(),
								" → ",
								new Date(b.checkOutDate).toLocaleDateString()
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: b.checkInTime
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: b.source
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-4 py-3",
							children: [currencySymbol, b.advanceAmount]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 text-right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-end gap-1",
								children: [canCheckIn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									onClick: () => onCheckIn(b),
									className: "text-muted-foreground hover:text-emerald-500",
									title: "Check-in Guest",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-4" })
								}), canCancel && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									onClick: () => onCancel(b),
									className: "text-muted-foreground hover:text-destructive",
									title: "Cancel Booking",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									onClick: () => onNoShow(b),
									className: "text-muted-foreground hover:text-warning",
									title: "Mark No-Show",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4" })
								})] })]
							})
						})
					]
				}, b.id))] })]
			})
		})
	});
}
function CheckoutDrawer({ bookingId, open, onOpenChange, mode = "checkout" }) {
	const queryClient = useQueryClient();
	const [paymentMethod, setPaymentMethod] = (0, import_react.useState)("Credit Card");
	const { data: bill, isLoading } = useQuery({
		queryKey: ["booking-bill", bookingId],
		queryFn: () => bookingId ? bookingService.getRoomBill(bookingId) : Promise.reject(),
		enabled: !!bookingId && open
	});
	const { data: settings } = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.getGeneralSettings()
	});
	const currencySymbol = settings?.currency?.match(/\((.*?)\)/)?.[1] || settings?.currency || "$";
	const checkoutMutation = useMutation({
		mutationFn: () => {
			if (!bookingId) return Promise.reject("No booking ID");
			return bookingService.checkout(bookingId, paymentMethod);
		},
		onSuccess: () => {
			toast.success("Checkout successful!");
			queryClient.invalidateQueries({ queryKey: ["bookings"] });
			queryClient.invalidateQueries({ queryKey: ["rooms"] });
			onOpenChange(false);
		},
		onError: (err) => {
			toast.error(err?.response?.data?.message || "Failed to checkout.");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "sm:max-w-md overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
				className: "font-serif text-2xl flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-6 text-primary" }),
					" ",
					mode === "view" ? "Bill Overview" : "Checkout"
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center py-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-primary size-8" })
				}) : bill ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-muted p-4 rounded-xl space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Guest Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: bill.guestName
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Room"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: bill.roomNumber
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Stay"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-medium",
										children: [
											new Date(bill.checkInDateTime).toLocaleDateString(),
											" to ",
											new Date(bill.checkOutDateTime).toLocaleDateString()
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Billed Nights"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: bill.billedNights
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold text-lg",
									children: "Bill Breakdown"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between items-center text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"Room Charges (",
										bill.billedNights,
										" x ",
										currencySymbol,
										bill.roomPricePerNight,
										")"
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, bill.totalRoomAmount.toFixed(2)] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between items-center text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Restaurant & Room Service" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, bill.totalRestaurantAmount.toFixed(2)] })]
								}),
								bill.taxesAmount !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between items-center text-sm text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"Taxes (",
										bill.cgstPercent + bill.sgstPercent,
										"%)"
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, bill.taxesAmount.toFixed(2)] })]
								}),
								bill.serviceChargeAmount !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between items-center text-sm text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"Service Charge (",
										bill.serviceChargePercent,
										"%)"
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, bill.serviceChargeAmount.toFixed(2)] })]
								}),
								bill.restaurantOrders && bill.restaurantOrders.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pl-4 text-xs text-muted-foreground space-y-1 mt-1 border-l-2 border-primary/20",
									children: bill.restaurantOrders.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Order ", o.orderNumber] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, o.subtotal.toFixed(2)] })]
										}), o.items && o.items.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pl-3 space-y-0.5 border-l border-border/40 mt-1 mb-2",
											children: o.items.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between text-[11px] text-muted-foreground/80",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
													item.name,
													" x ",
													item.quantity
												] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, (item.priceAtOrder * item.quantity).toFixed(2)] })]
											}, `${o.id}-item-${idx}`))
										})]
									}, o.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-3 border-t flex justify-between font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total Amount" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, bill.totalAmount.toFixed(2)] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-emerald-600 font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Advance Paid" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"-",
										currencySymbol,
										bill.advanceAmount.toFixed(2)
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-3 border-t flex justify-between text-xl font-bold text-primary",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Amount Due" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, bill.dueAmount.toFixed(2)] })]
								})
							]
						}),
						mode !== "view" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-sm font-medium",
								children: "Payment Method"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: paymentMethod,
								onValueChange: setPaymentMethod,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select payment method" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "Credit Card",
										children: "Credit Card"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "Cash",
										children: "Cash"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "Debit Card",
										children: "Debit Card"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "UPI",
										children: "UPI"
									})
								] })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								className: mode === "view" ? "w-full h-12 text-lg rounded-xl" : "w-1/3 h-12 text-lg rounded-xl",
								onClick: () => printViaIframe(`/print-booking/${bookingId}`),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-5 mr-2" }), " Print"]
							}), mode !== "view" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								className: "flex-1 h-12 text-lg rounded-xl",
								onClick: () => checkoutMutation.mutate(),
								disabled: checkoutMutation.isPending,
								children: [checkoutMutation.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin size-5 mr-2" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "size-5 mr-2" }), "Confirm Checkout"]
							})]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center text-destructive py-10",
					children: "Failed to load bill information."
				})
			})]
		})
	});
}
function ActiveGuestsTab({ bookings }) {
	const navigate = useNavigate();
	const [checkoutBookingId, setCheckoutBookingId] = (0, import_react.useState)(null);
	const [viewBillBookingId, setViewBillBookingId] = (0, import_react.useState)(null);
	if (bookings.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-8 text-center text-muted-foreground",
		children: "No active guests right now."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4",
			children: bookings.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4 rounded-2xl flex flex-col justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between items-start mb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-serif text-xl",
							children: b.guestName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "bg-emerald-500/10 text-emerald-500 text-[10px] uppercase tracking-wider px-2 py-1 rounded-full font-medium",
							children: "Checked-in"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm font-medium mb-1",
						children: ["Room ", b.room ? b.room.number : "Unassigned"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted-foreground space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Out: ", new Date(b.checkOutDate).toLocaleDateString()] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Guests: ", b.guests] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Phone: ", b.phone] })
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 pt-4 border-t flex justify-between items-center text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "hover:text-primary",
							onClick: () => {
								if (b.room) navigate({
									to: "/orders",
									search: {
										tab: "room-service",
										roomNumber: b.room.number
									}
								});
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Utensils, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "hover:text-primary",
							onClick: () => setViewBillBookingId(b.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "hover:text-[color:var(--warning)]",
							onClick: () => setCheckoutBookingId(b.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" })
						})
					]
				})]
			}, b.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckoutDrawer, {
			bookingId: checkoutBookingId,
			open: checkoutBookingId !== null,
			onOpenChange: (open) => !open && setCheckoutBookingId(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckoutDrawer, {
			bookingId: viewBillBookingId,
			open: viewBillBookingId !== null,
			onOpenChange: (open) => !open && setViewBillBookingId(null),
			mode: "view"
		})
	] });
}
var REFUND_STATUSES = [
	{
		value: "Pending",
		label: "Pending",
		color: "bg-yellow-500/15 text-yellow-500"
	},
	{
		value: "Refunded",
		label: "Refunded",
		color: "bg-emerald-500/15 text-emerald-500"
	},
	{
		value: "No Refund",
		label: "No Refund",
		color: "bg-muted text-muted-foreground"
	},
	{
		value: "Processing",
		label: "Processing",
		color: "bg-blue-500/15 text-blue-500"
	},
	{
		value: "Failed",
		label: "Failed",
		color: "bg-destructive/15 text-destructive"
	}
];
function getStatusStyle(status) {
	return REFUND_STATUSES.find((s) => s.value === status)?.color ?? "bg-muted text-muted-foreground";
}
function RefundStatusCell({ bookingId, currentStatus }) {
	const queryClient = useQueryClient();
	const [open, setOpen] = (0, import_react.useState)(false);
	const mutation = useMutation({
		mutationFn: (newStatus) => bookingService.update(bookingId, { refundStatus: newStatus }),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["bookings", "Cancelled"] });
			toast.success("Refund status updated");
		},
		onError: () => toast.error("Failed to update refund status")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
		value: currentStatus,
		onValueChange: (val) => mutation.mutate(val),
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
			className: `h-7 w-36 border-0 rounded-full px-2.5 text-xs font-medium focus:ring-0 ${getStatusStyle(currentStatus)}`,
			children: mutation.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-3 w-3 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: REFUND_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
			value: s.value,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: `inline-flex items-center gap-1.5`,
				children: [s.value === currentStatus && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3 w-3" }), s.label]
			})
		}, s.value)) })]
	});
}
function CancellationsTab() {
	const { data: bookings = [] } = useQuery({
		queryKey: ["bookings", "Cancelled"],
		queryFn: () => bookingService.getAll("Cancelled")
	});
	const { data: settings } = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.getGeneralSettings()
	});
	const currencySymbol = settings?.currency ? settings.currency.match(/\(([^)]+)\)/)?.[1] || settings.currency : "₹";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "rounded-2xl overflow-hidden mt-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "bg-muted/40",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-left text-xs uppercase tracking-widest text-muted-foreground border-b",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Booking ID"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Guest"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Room"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Dates"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Advance"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Refund Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right",
								children: "Refund Amount"
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [bookings.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 7,
					className: "px-4 py-8 text-center text-muted-foreground",
					children: "No cancelled bookings found."
				}) }), bookings.map((b) => {
					const hasRefund = (b.refundAmount ?? 0) > 0;
					const statusText = b.refundStatus || (hasRefund ? "Refunded" : "No Refund");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b last:border-0 hover:bg-muted/10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3 font-medium",
								children: ["#", b.bookingCode || b.id]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: b.guestName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: b.room ? `Room ${b.room.number}` : "-"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: new Date(b.checkInDate).toLocaleDateString()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [currencySymbol, b.advanceAmount]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefundStatusCell, {
									bookingId: b.id,
									currentStatus: statusText
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-right font-medium text-emerald-500",
								children: b.refundAmount != null ? `${currencySymbol}${b.refundAmount.toLocaleString()}` : `${currencySymbol}0`
							})
						]
					}, b.id);
				})] })]
			})
		})
	});
}
function NoShowsTab() {
	const { data: bookings = [] } = useQuery({
		queryKey: ["bookings", "No-Show"],
		queryFn: () => bookingService.getAll("No-Show")
	});
	const { data: settings } = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.getGeneralSettings()
	});
	const currencySymbol = settings?.currency ? settings.currency.match(/\(([^)]+)\)/)?.[1] || settings.currency : "₹";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "rounded-2xl overflow-hidden mt-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "bg-muted/40",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-left text-xs uppercase tracking-widest text-muted-foreground border-b",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Booking ID"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Guest"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Room"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Expected Dates"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right",
								children: "Forfeited Revenue"
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [bookings.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 5,
					className: "px-4 py-8 text-center text-muted-foreground",
					children: "No no-shows found."
				}) }), bookings.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b last:border-0 hover:bg-muted/10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-4 py-3 font-medium",
							children: ["#", b.bookingCode || b.id]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: b.guestName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: b.room ? `Room ${b.room.number}` : "-"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: new Date(b.checkInDate).toLocaleDateString()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 text-right text-primary font-medium",
							children: b.forfeitedAmount != null ? `${currencySymbol}${b.forfeitedAmount}` : "-"
						})
					]
				}, b.id))] })]
			})
		})
	});
}
function NewCheckInDrawer() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const queryClient = useQueryClient();
	const todayStr = (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA");
	const [guestName, setGuestName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [idNumber, setIdNumber] = (0, import_react.useState)("");
	const [roomId, setRoomId] = (0, import_react.useState)(null);
	const [checkInDate, setCheckInDate] = (0, import_react.useState)("");
	const [checkInTime, setCheckInTime] = (0, import_react.useState)(() => {
		const now = /* @__PURE__ */ new Date();
		return `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
	});
	(0, import_react.useEffect)(() => {
		if (open) {
			const now = /* @__PURE__ */ new Date();
			setCheckInTime(`${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`);
		}
	}, [open]);
	const [checkOutDate, setCheckOutDate] = (0, import_react.useState)("");
	const [guests, setGuests] = (0, import_react.useState)("2");
	const [advanceAmount, setAdvanceAmount] = (0, import_react.useState)("");
	const [paymentMethod, setPaymentMethod] = (0, import_react.useState)("card");
	const [idProofFile, setIdProofFile] = (0, import_react.useState)(null);
	const { data: rooms = [] } = useQuery({
		queryKey: ["rooms"],
		queryFn: () => roomService.getAll()
	});
	const { data: settings } = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.getGeneralSettings()
	});
	const getNights = () => {
		if (!checkInDate || !checkOutDate) return 0;
		const start = new Date(checkInDate);
		const diffTime = new Date(checkOutDate).getTime() - start.getTime();
		if (diffTime <= 0) return 0;
		return Math.ceil(diffTime / (1e3 * 60 * 60 * 24));
	};
	const selectedRoom = rooms.find((r) => r.id === roomId);
	const nights = getNights() || 1;
	const totalPrice = selectedRoom ? selectedRoom.basePrice * nights : 0;
	const minAdvancePercent = settings?.minimumAdvancePercent || 0;
	const minAdvanceAmount = Math.round(totalPrice * (minAdvancePercent / 100));
	(0, import_react.useEffect)(() => {
		if (minAdvanceAmount > 0) setAdvanceAmount(minAdvanceAmount.toString());
		else setAdvanceAmount("");
	}, [minAdvanceAmount]);
	const createMutation = useMutation({
		mutationFn: async () => {
			if (!roomId) throw new Error("Please select a room.");
			const selectedRoom = rooms.find((r) => r.id === roomId);
			if (selectedRoom) {
				const parsedGuests = parseInt(guests) || 0;
				if (parsedGuests > selectedRoom.capacity) throw new Error(`The number of guests (${parsedGuests}) cannot exceed the room capacity (${selectedRoom.capacity}).`);
			}
			if (minAdvanceAmount > 0) {
				if ((parseFloat(advanceAmount) || 0) < minAdvanceAmount) throw new Error(`Minimum advance amount of ${minAdvanceAmount} (${minAdvancePercent}% of total) is required.`);
			}
			const formData = new FormData();
			formData.append("GuestName", guestName);
			formData.append("Phone", phone);
			formData.append("Email", email);
			formData.append("IdNumber", idNumber);
			formData.append("RoomId", roomId.toString());
			formData.append("CheckInDate", checkInDate);
			formData.append("CheckInTime", checkInTime);
			formData.append("CheckOutDate", checkOutDate);
			formData.append("Guests", guests);
			formData.append("AdvanceAmount", advanceAmount || "0");
			formData.append("PaymentMethod", paymentMethod);
			formData.append("Status", "Confirmed");
			formData.append("Source", "Walk-in");
			if (idProofFile) formData.append("idProofFile", idProofFile);
			return bookingService.create(formData);
		},
		onSuccess: () => {
			toast.success("Check-in confirmed");
			queryClient.invalidateQueries({ queryKey: ["bookings"] });
			setOpen(false);
			setGuestName("");
			setPhone("");
			setEmail("");
			setIdNumber("");
			setRoomId(null);
			setCheckInDate("");
			setCheckOutDate("");
			setAdvanceAmount("");
			setIdProofFile(null);
		},
		onError: (err) => {
			toast.error(err.message || "Failed to create booking");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "rounded-xl bg-primary text-primary-foreground copper-glow",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1" }), " New Booking"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "w-full sm:max-w-xl overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
				className: "font-serif text-2xl",
				children: "New Booking"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 space-y-4 px-4",
				onSubmit: (e) => {
					e.preventDefault();
					if (phone.length !== 10) {
						toast.error("Phone number must be exactly 10 digits.");
						return;
					}
					if (checkInDate && checkInDate < todayStr) {
						toast.error("Check-in date cannot be in the past.");
						return;
					}
					if (checkOutDate && checkOutDate < checkInDate) {
						toast.error("Check-out date cannot be before the check-in date.");
						return;
					}
					if (!roomId) {
						toast.error("Please select a room.");
						return;
					}
					const selectedRoom = rooms.find((r) => r.id === roomId);
					if (selectedRoom) {
						const parsedGuests = parseInt(guests) || 0;
						if (parsedGuests > selectedRoom.capacity) {
							toast.error(`The number of guests (${parsedGuests}) cannot exceed the room capacity (${selectedRoom.capacity}).`);
							return;
						}
					}
					if (minAdvanceAmount > 0) {
						if ((parseFloat(advanceAmount) || 0) < minAdvanceAmount) {
							toast.error(`Minimum advance amount of ${minAdvanceAmount} (${minAdvancePercent}% of total) is required.`);
							return;
						}
					}
					createMutation.mutate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Guest name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							className: "rounded-xl mt-1",
							placeholder: "Ava Sinclair",
							value: guestName,
							onChange: (e) => setGuestName(e.target.value)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Phone" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							type: "tel",
							className: "rounded-xl mt-1",
							placeholder: "10-digit phone number",
							value: phone,
							onChange: (e) => {
								const val = e.target.value.replace(/\D/g, "");
								if (val.length <= 10) setPhone(val);
							}
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "email",
							className: "rounded-xl mt-1",
							value: email,
							onChange: (e) => setEmail(e.target.value)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "ID number" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							className: "rounded-xl mt-1",
							placeholder: "P123456",
							value: idNumber,
							onChange: (e) => setIdNumber(e.target.value)
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "ID proof" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 relative h-16 rounded-xl border-2 border-dashed flex items-center justify-center gap-2 text-xs text-muted-foreground overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "image/*,.pdf",
								className: "absolute inset-0 opacity-0 cursor-pointer",
								onChange: (e) => {
									if (e.target.files && e.target.files.length > 0) setIdProofFile(e.target.files[0]);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }),
							idProofFile ? idProofFile.name : "Upload document"
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Select room" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 grid grid-cols-4 gap-2 max-h-40 overflow-y-auto",
						children: rooms.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								if (r.status === "Available") setRoomId(r.id);
							},
							className: cn("p-2 rounded-lg border text-left text-xs transition-colors", r.status === "Available" ? roomId === r.id ? "border-primary bg-primary/10 ring-1 ring-primary" : "border-success/30 bg-success/5 hover:bg-success/10 cursor-pointer" : "border-border opacity-50 cursor-not-allowed"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-medium",
								children: ["Room ", r.number]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] text-muted-foreground truncate",
								children: r.category?.name || "Cat"
							})]
						}, r.id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Check-in date" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								type: "date",
								className: "rounded-xl mt-1",
								min: todayStr,
								value: checkInDate,
								onChange: (e) => setCheckInDate(e.target.value)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Check-in time" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								type: "time",
								className: "rounded-xl mt-1",
								value: checkInTime,
								onChange: (e) => setCheckInTime(e.target.value)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Check-out" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								type: "date",
								className: "rounded-xl mt-1",
								min: checkInDate || todayStr,
								value: checkOutDate,
								onChange: (e) => setCheckOutDate(e.target.value)
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Guests" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								className: "rounded-xl mt-1",
								value: guests,
								onChange: (e) => setGuests(e.target.value)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: ["Advance ", minAdvancePercent > 0 ? `(${minAdvancePercent}%)` : ""] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								placeholder: minAdvanceAmount > 0 ? `${minAdvanceAmount}` : "0",
								className: "rounded-xl mt-1",
								value: advanceAmount,
								onChange: (e) => setAdvanceAmount(e.target.value)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Method" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: paymentMethod,
								onValueChange: setPaymentMethod,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "rounded-xl mt-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Card" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "cash",
										children: "Cash"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "card",
										children: "Card"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "upi",
										children: "UPI"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "online",
										children: "Online"
									})
								] })]
							})] })
						]
					}),
					minAdvancePercent > 0 && totalPrice > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[11px] text-muted-foreground bg-muted/40 p-2.5 rounded-xl space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							"Total room price for ",
							nights,
							" nights is ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
								settings?.currency || "INR",
								" ",
								totalPrice
							] }),
							"."
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							"Minimum advance required: ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
								className: "text-primary",
								children: [
									settings?.currency || "INR",
									" ",
									minAdvanceAmount
								]
							}),
							" (",
							minAdvancePercent,
							"%)."
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: createMutation.isPending,
						className: "w-full rounded-xl bg-primary text-primary-foreground copper-glow",
						children: createMutation.isPending ? "Confirming..." : "Confirm check-in"
					})
				]
			})]
		})]
	});
}
function BookingsPage() {
	const [activeTab, setActiveTab] = (0, import_react.useState)("reservations");
	const [cancelBooking, setCancelBooking] = (0, import_react.useState)(null);
	const [noShowBooking, setNoShowBooking] = (0, import_react.useState)(null);
	const userRaw = typeof window !== "undefined" ? localStorage.getItem("user") : null;
	const user = userRaw ? JSON.parse(userRaw) : { role: "Admin" };
	const canAdd = permissionService.hasPermission(user.role, "bookings", "add");
	const canDelete = permissionService.hasPermission(user.role, "bookings", "delete");
	const canEdit = permissionService.hasPermission(user.role, "bookings", "edit");
	const { data: settings } = useQuery({
		queryKey: ["settings"],
		queryFn: settingsService.getGeneralSettings
	});
	const currency = extractCurrencySymbol(settings?.currency);
	const queryClient = useQueryClient();
	const { data: upcomingBookings = [] } = useQuery({
		queryKey: ["bookings", "Confirmed"],
		queryFn: () => bookingService.getAll("Confirmed")
	});
	const { data: activeGuests = [] } = useQuery({
		queryKey: ["bookings", "Checked-in"],
		queryFn: () => bookingService.getAll("Checked-in")
	});
	const noShowMutation = useMutation({
		mutationFn: (id) => bookingService.markNoShow(id),
		onSuccess: () => {
			toast.success("Booking marked as No-Show.");
			queryClient.invalidateQueries({ queryKey: ["bookings"] });
			queryClient.invalidateQueries({ queryKey: ["rooms"] });
			setNoShowBooking(null);
		},
		onError: () => {
			toast.error("Failed to mark No-Show.");
		}
	});
	const cancelMutation = useMutation({
		mutationFn: async (args) => bookingService.update(args.id, args.data),
		onSuccess: () => {
			toast.success("Booking cancelled successfully.");
			queryClient.invalidateQueries({ queryKey: ["bookings"] });
			setCancelBooking(null);
		},
		onError: () => {
			toast.error("Failed to cancel booking.");
		}
	});
	const checkInMutation = useMutation({
		mutationFn: async (id) => bookingService.update(id, { status: "Checked-in" }),
		onSuccess: () => {
			toast.success("Guest checked in successfully.");
			queryClient.invalidateQueries({ queryKey: ["bookings"] });
			queryClient.invalidateQueries({ queryKey: ["rooms"] });
		},
		onError: () => {
			toast.error("Failed to check in guest.");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Bookings",
		breadcrumbs: [{
			label: "Home",
			to: "/"
		}, {
			label: "Bookings",
			to: "/bookings"
		}],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col h-[calc(100vh-130px)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
					value: activeTab,
					onValueChange: setActiveTab,
					className: "flex-1 flex flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
								className: "bg-card",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "reservations",
										className: "gap-2",
										children: ["Reservations", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "bg-primary/20 text-primary text-xs px-2 py-0.5 rounded-full",
											children: upcomingBookings.length
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "active",
										className: "gap-2",
										children: ["Active Guests", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "bg-emerald-500/20 text-emerald-500 text-xs px-2 py-0.5 rounded-full",
											children: activeGuests.length
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
										value: "cancellations",
										children: "Cancellations & Refunds"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
										value: "noshows",
										children: "No-Shows"
									})
								]
							}), canAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewCheckInDrawer, {})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "reservations",
							className: "flex-1 overflow-auto m-0 p-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReservationsTab, {
								bookings: upcomingBookings,
								onCancel: setCancelBooking,
								onNoShow: setNoShowBooking,
								onCheckIn: (b) => checkInMutation.mutate(b.id),
								canCheckIn: canEdit,
								canCancel: canDelete
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "active",
							className: "flex-1 overflow-auto m-0 p-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActiveGuestsTab, { bookings: activeGuests })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "cancellations",
							className: "flex-1 overflow-auto m-0 p-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CancellationsTab, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "noshows",
							className: "flex-1 overflow-auto m-0 p-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoShowsTab, {})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!noShowBooking,
				onOpenChange: (open) => !open && setNoShowBooking(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md rounded-2xl glass",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "font-serif text-2xl",
						children: [
							"Mark #",
							noShowBooking?.id,
							" as No-Show"
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-xl bg-destructive/5 border border-destructive/30",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: "Advance held"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-serif text-2xl text-destructive",
									children: ["$", noShowBooking?.advanceAmount]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground mt-1",
									children: "Per policy, advance is forfeited on no-show."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-end gap-2 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => setNoShowBooking(null),
								children: "Back"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90",
								disabled: noShowMutation.isPending,
								onClick: () => noShowBooking && noShowMutation.mutate(noShowBooking.id),
								children: noShowMutation.isPending ? "Processing..." : "Confirm no-show"
							})]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!cancelBooking,
				onOpenChange: (open) => !open && setCancelBooking(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md rounded-2xl glass",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "font-serif text-2xl",
						children: ["Cancel Booking #", cancelBooking?.id]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-4 rounded-xl bg-muted/40",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "Guest:"
											}),
											" ",
											cancelBooking?.guestName
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "Room:"
											}),
											" ",
											cancelBooking?.room?.number || "-"
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "Advance:"
											}),
											" ",
											currency,
											cancelBooking?.advanceAmount
										] })
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-sm font-medium",
									children: "Cancellation Reason"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									placeholder: "Reason for cancellation...",
									className: "rounded-xl"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									onClick: () => setCancelBooking(null),
									children: "Back"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90",
									disabled: cancelMutation.isPending,
									onClick: () => cancelBooking && cancelMutation.mutate({
										id: cancelBooking.id,
										data: {
											status: "Cancelled",
											refundAmount: cancelBooking.advanceAmount,
											refundMethod: "Original Payment Method",
											refundStatus: "Pending"
										}
									}),
									children: cancelMutation.isPending ? "Processing..." : "Confirm cancellation"
								})]
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { BookingsPage as component };
