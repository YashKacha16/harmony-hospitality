import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { r as cn, t as Button } from "./button-juXZH0rY.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { K as Clock, R as ListPlus, T as Plus, m as ShoppingBag, n as Utensils, p as Sparkles, q as ClipboardList, s as TriangleAlert, st as BedDouble } from "../_libs/lucide-react.mjs";
import { a as StatusBadge, t as AppShell } from "./app-shell-C6Y1qr1C.mjs";
import { t as Card } from "./card-DNWGqbqR.mjs";
import { t as bookingService } from "./bookingService-TCPCmwod.mjs";
import { t as roomService } from "./roomService-D1zUMbty.mjs";
import { t as tableService } from "./tableService-LRzUVk7o.mjs";
import { t as orderService } from "./orderService-CwnQmAjk.mjs";
import { t as waitlistService } from "./waitlistService-BB0IpGbl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-oj2k3fiV.js
var import_jsx_runtime = require_jsx_runtime();
function Stat({ label, value, icon: Icon, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "p-5 stat-gradient border-border/60 rounded-2xl relative overflow-hidden group",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3 relative z-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs uppercase tracking-widest text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-serif text-3xl mt-1.5",
				children: value
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("size-10 rounded-xl flex items-center justify-center", accent),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
			})]
		})
	});
}
function Dashboard() {
	const { data: rooms = [] } = useQuery({
		queryKey: ["rooms"],
		queryFn: () => roomService.getAll()
	});
	const { data: waitlist = [] } = useQuery({
		queryKey: ["waitlist"],
		queryFn: () => waitlistService.getAll()
	});
	const { data: tables = [] } = useQuery({
		queryKey: ["tables"],
		queryFn: () => tableService.getAll()
	});
	const { data: bookings = [] } = useQuery({
		queryKey: ["bookings"],
		queryFn: () => bookingService.getAll()
	});
	const { data: kanban = {
		new: [],
		preparing: [],
		ready: [],
		served: []
	} } = useQuery({
		queryKey: ["kanbanOrders", "All"],
		queryFn: () => orderService.getKanban("All")
	});
	const availableRooms = rooms.filter((r) => r.status === "Available" || r.status === "Clean").length;
	const occupiedRooms = rooms.filter((r) => r.status === "Occupied").length;
	const totalRooms = rooms.length || 1;
	const occupancyPercent = rooms.length === 0 ? 0 : Math.round(occupiedRooms / totalRooms * 100);
	const waitingGuests = waitlist.filter((w) => w.status === "Waiting").length;
	const occupiedTables = tables.filter((t) => t.status === "Occupied").length;
	const activeOrders = (kanban.new?.length || 0) + (kanban.preparing?.length || 0) + (kanban.ready?.length || 0) + (kanban.served?.length || 0);
	const pendingNoShows = bookings.filter((b) => b.status === "Pending" || b.status === "Confirmed").length;
	const recentOrders = [
		...kanban.new || [],
		...kanban.preparing || [],
		...kanban.ready || [],
		...kanban.served || []
	].sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()).slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumbs: [{ label: "Home" }, { label: "Dashboard" }],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between mb-6 flex-wrap gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-[0.24em] text-primary",
						children: "Good morning, Admin"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-serif text-4xl mt-1",
						children: "Property overview"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground mt-1",
						children: "A real-time snapshot of the property."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/bookings",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								className: "rounded-xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1" }), " New Booking"]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/waitlist",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								className: "rounded-xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListPlus, { className: "size-4 mr-1" }), " Waitlist"]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/orders",
							search: {
								tableId: void 0,
								mergeGroupId: void 0,
								editOrderId: void 0,
								tab: void 0,
								roomNumber: void 0
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								className: "rounded-xl bg-primary text-primary-foreground copper-glow",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-4 mr-1" }), " New Order"]
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Occupancy",
						value: `${occupancyPercent}%`,
						icon: BedDouble,
						accent: "bg-info/15 text-info"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Active Orders",
						value: activeOrders,
						icon: ClipboardList,
						accent: "bg-warning/15 [color:var(--warning)]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Guests Waiting",
						value: waitingGuests,
						icon: Clock,
						accent: "bg-special/15 [color:var(--special)]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Rooms Available",
						value: availableRooms,
						icon: Sparkles,
						accent: "bg-success/15 text-success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Tables Occupied",
						value: `${occupiedTables}/${tables.length}`,
						icon: Utensils,
						accent: "bg-destructive/15 text-destructive"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-3 gap-4 mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-4 lg:col-span-1 lg:col-start-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/bookings",
						className: "block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "p-5 rounded-2xl border-warning/40 bg-warning/5 hover:shadow-md transition cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs uppercase tracking-widest [color:var(--warning)]",
										children: "Pending Bookings"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-serif text-3xl mt-1",
										children: pendingNoShows
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground mt-1",
										children: "Bookings awaiting check-in"
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-8 [color:var(--warning)]" })]
							})
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-6 rounded-2xl lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-serif text-xl mb-4",
						children: "Live orders"
					}), recentOrders.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm text-muted-foreground flex items-center justify-center h-32 border border-dashed rounded-xl border-white/10",
						children: "No active orders at the moment."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: recentOrders.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-sm py-2 border-b border-border last:border-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-medium",
								children: [
									"Order #",
									o.id,
									" ",
									o.orderType ? `· ${o.orderType}` : ""
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-muted-foreground",
								children: [o.items?.length || 0, " items"]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: o.status })]
						}, o.id))
					})]
				})]
			})
		]
	});
}
//#endregion
export { Dashboard as component };
