import { r as __toESM } from "../_runtime.mjs";
import { n as apiClient } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { n as Input, t as Button } from "./button-juXZH0rY.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { E as Phone, T as Plus } from "../_libs/lucide-react.mjs";
import { a as StatusBadge, i as AvatarImage, n as Avatar, o as permissionService, r as AvatarFallback, t as AppShell } from "./app-shell-C6Y1qr1C.mjs";
import { t as Card } from "./card-DNWGqbqR.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CUQVyHA-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SheetTitle, i as SheetHeader, n as SheetContent, o as SheetTrigger, t as Sheet } from "./sheet-DgrR67wC.mjs";
import { t as Label } from "./label-Bkz_RwW1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employees-5iu4YDb_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var employeeService = {
	getAll: () => apiClient.get("/api/Employee"),
	getById: (id) => apiClient.get(`/api/Employee/${id}`),
	create: (employee) => apiClient.post("/api/Employee", employee),
	update: (id, employee) => apiClient.put(`/api/Employee/${id}`, employee),
	delete: (id) => apiClient.delete(`/api/Employee/${id}`),
	uploadPhoto: (id, file) => {
		const formData = new FormData();
		formData.append("photo", file);
		return apiClient.request(`/api/Employee/${id}/photo`, {
			method: "POST",
			body: formData,
			headers: { "Content-Type": void 0 }
		});
	}
};
var getPhotoUrl = (path) => {
	if (!path) return void 0;
	if (path.startsWith("http")) return path;
	return `http://localhost:5157${path}`;
};
function EmpPage() {
	const queryClient = useQueryClient();
	const userRaw = typeof window !== "undefined" ? localStorage.getItem("user") : null;
	const user = userRaw ? JSON.parse(userRaw) : { role: "Admin" };
	const { data: employees = [], isLoading } = useQuery({
		queryKey: ["employees"],
		queryFn: employeeService.getAll
	});
	const { data: dbRoles = [] } = useQuery({
		queryKey: ["roles"],
		queryFn: () => permissionService.getRoles()
	});
	const roleNames = dbRoles.length > 0 ? dbRoles.map((r) => r.name) : [
		"Admin",
		"Waiter",
		"Chef"
	];
	const currentRoleConfig = dbRoles.find((r) => r.name.toLowerCase() === user.role.toLowerCase());
	const canAdd = currentRoleConfig ? !!currentRoleConfig.permissions.employees?.add : permissionService.hasPermission(user.role, "employees", "add");
	const canEdit = currentRoleConfig ? !!currentRoleConfig.permissions.employees?.edit : permissionService.hasPermission(user.role, "employees", "edit");
	const updateMutation = useMutation({
		mutationFn: ({ id, employee }) => employeeService.update(id, employee),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["employees"] });
			toast.success("Employee updated successfully");
		},
		onError: () => toast.error("Failed to update employee")
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Employees",
		breadcrumbs: [{
			label: "Home",
			to: "/dashboard"
		}, { label: "Employees" }],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center justify-center h-64",
			children: "Loading employees..."
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Employees",
		breadcrumbs: [{
			label: "Home",
			to: "/dashboard"
		}, { label: "Employees" }],
		children: [canAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-end mb-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddEmpSheet, { roles: roleNames })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mt-2",
			children: employees.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5 rounded-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Avatar, {
								className: "size-14",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarImage, { src: getPhotoUrl(e.photoPath) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback, { children: e.name[0] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium truncate",
									children: e.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: e.role
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: e.status })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 space-y-1 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3" }),
								" ",
								e.email
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Joined: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground",
							children: e.joined
						})] })]
					}),
					canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							defaultValue: e.role,
							onValueChange: (val) => updateMutation.mutate({
								id: e.id,
								employee: {
									...e,
									role: val
								}
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "h-8 rounded-lg text-xs flex-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: roleNames.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: r,
								children: r
							}, r)) })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditEmpSheet, {
							employee: e,
							roles: roleNames
						})]
					})
				]
			}, e.id))
		})]
	});
}
function AddEmpSheet({ roles }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [role, setRole] = (0, import_react.useState)(roles[0] || "Waiter");
	const queryClient = useQueryClient();
	const createMutation = useMutation({
		mutationFn: (emp) => employeeService.create(emp),
		onError: () => toast.error("Failed to add employee")
	});
	const photoMutation = useMutation({
		mutationFn: ({ id, file }) => employeeService.uploadPhoto(id, file),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["employees"] });
		},
		onError: () => toast.error("Failed to upload employee photo")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "rounded-xl bg-primary text-primary-foreground copper-glow",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1" }), " Add employee"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "w-full sm:max-w-lg overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
				className: "font-serif text-2xl",
				children: "New employee"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 space-y-3 px-4",
				autoComplete: "off",
				onSubmit: async (e) => {
					e.preventDefault();
					const formData = new FormData(e.currentTarget);
					const newEmp = {
						name: formData.get("name"),
						email: formData.get("email"),
						password: formData.get("password") || "123456",
						role,
						status: "Active",
						joined: formData.get("joined") || (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
					};
					try {
						const created = await createMutation.mutateAsync(newEmp);
						const fileInput = formData.get("photo");
						if (fileInput && fileInput.size > 0 && created.id) await photoMutation.mutateAsync({
							id: created.id,
							file: fileInput
						});
						queryClient.invalidateQueries({ queryKey: ["employees"] });
						toast.success("Employee added successfully");
						setOpen(false);
					} catch (err) {}
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Photo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "photo",
						type: "file",
						accept: "image/*",
						className: "rounded-xl mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "name",
						className: "rounded-xl mt-1",
						required: true,
						autoComplete: "off"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "email",
							type: "email",
							className: "rounded-xl mt-1",
							required: true,
							autoComplete: "off"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Password" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "password",
							type: "password",
							className: "rounded-xl mt-1",
							required: true,
							autoComplete: "new-password"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Role" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: role,
							onValueChange: setRole,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "rounded-xl mt-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: roles[0] || "Waiter" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: roles.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: r,
								children: r
							}, r)) })]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Joining date" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "joined",
							type: "date",
							className: "rounded-xl mt-1"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full rounded-xl bg-primary text-primary-foreground copper-glow mt-4",
						children: "Add employee"
					})
				]
			})]
		})]
	});
}
function EditEmpSheet({ employee, roles }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const queryClient = useQueryClient();
	const updateMutation = useMutation({
		mutationFn: ({ id, emp }) => employeeService.update(id, emp),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["employees"] });
			toast.success("Employee updated successfully");
			setOpen(false);
		},
		onError: () => toast.error("Failed to update employee")
	});
	const photoMutation = useMutation({
		mutationFn: ({ id, file }) => employeeService.uploadPhoto(id, file),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["employees"] });
		},
		onError: () => toast.error("Failed to upload photo")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				size: "sm",
				className: "h-8 rounded-lg text-xs",
				children: "Edit"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "w-full sm:max-w-lg overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
				className: "font-serif text-2xl",
				children: "Edit employee"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 space-y-3 px-4",
				onSubmit: (e) => {
					e.preventDefault();
					const formData = new FormData(e.currentTarget);
					const fileInput = formData.get("photo");
					if (fileInput && fileInput.size > 0) photoMutation.mutate({
						id: employee.id,
						file: fileInput
					});
					const updatedEmp = {
						...employee,
						name: formData.get("name"),
						email: formData.get("email"),
						role: formData.get("role"),
						status: formData.get("status"),
						joined: formData.get("joined")
					};
					updateMutation.mutate({
						id: employee.id,
						emp: updatedEmp
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Photo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "photo",
						type: "file",
						accept: "image/*",
						className: "rounded-xl mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "name",
						defaultValue: employee.name,
						className: "rounded-xl mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "email",
						type: "email",
						defaultValue: employee.email,
						className: "rounded-xl mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Role" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							name: "role",
							defaultValue: employee.role,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "rounded-xl mt-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: roles.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: r,
								children: r
							}, r)) })]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Status" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							name: "status",
							defaultValue: employee.status || "Active",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "rounded-xl mt-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "Active",
									children: "Active"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "Inactive",
									children: "Inactive"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "On Leave",
									children: "On Leave"
								})
							] })]
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Joining date" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "joined",
						defaultValue: employee.joined,
						type: "date",
						className: "rounded-xl mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full rounded-xl bg-primary text-primary-foreground copper-glow mt-4",
						children: "Save changes"
					})
				]
			})]
		})]
	});
}
//#endregion
export { EmpPage as component };
