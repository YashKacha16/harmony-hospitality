import { r as __toESM } from "../_runtime.mjs";
import { n as apiClient, r as settingsService, t as BASE_URL } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { i as extractCurrencySymbol, n as Input, r as cn, t as Button } from "./button-juXZH0rY.mjs";
import { a as closestCenter, h as CSS, i as PointerSensor, m as useSensors, p as useSensor, r as KeyboardSensor, t as DndContext } from "../_libs/@dnd-kit/core+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { D as Pencil, T as Plus, V as GripVertical, c as Trash2, r as UtensilsCrossed } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-C6Y1qr1C.mjs";
import { t as Card } from "./card-DNWGqbqR.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SheetTitle, i as SheetHeader, n as SheetContent, t as Sheet } from "./sheet-DgrR67wC.mjs";
import { t as Label } from "./label-Bkz_RwW1.mjs";
import { t as Textarea } from "./textarea-CiyhCZVs.mjs";
import { t as menuService } from "./menuService-DxjzhlGj.mjs";
import { t as Switch } from "./switch-BIIbVvK-.mjs";
import { a as verticalListSortingStrategy, i as useSortable, n as arrayMove, r as sortableKeyboardCoordinates, t as SortableContext } from "../_libs/dnd-kit__sortable.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/menu-CgkjXIkK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var categoryService = {
	getAll: () => apiClient.get("/api/category"),
	getById: (id) => apiClient.get(`/api/category/${id}`),
	create: (category) => apiClient.post("/api/category", category),
	update: (id, category) => apiClient.put(`/api/category/${id}`, category),
	delete: (id) => apiClient.delete(`/api/category/${id}`),
	reorder: (positions) => apiClient.request("/api/category/reorder", {
		method: "PATCH",
		body: JSON.stringify(positions)
	})
};
function MenuPage() {
	const queryClient = useQueryClient();
	const [activeCategoryId, setActiveCategoryId] = (0, import_react.useState)(null);
	const [isAddCatOpen, setIsAddCatOpen] = (0, import_react.useState)(false);
	const [isReorderCatOpen, setIsReorderCatOpen] = (0, import_react.useState)(false);
	const [itemModal, setItemModal] = (0, import_react.useState)({
		isOpen: false,
		mode: "create",
		initialData: null
	});
	const userRaw = typeof window !== "undefined" ? localStorage.getItem("user") : null;
	const user = userRaw ? JSON.parse(userRaw) : { role: "Admin" };
	const { data: roles = [] } = useQuery({
		queryKey: ["roles"],
		queryFn: () => permissionService.getRoles()
	});
	const canAdd = (() => {
		const roleConfig = roles.find((r) => r.name.toLowerCase() === user.role.toLowerCase());
		return roleConfig ? !!roleConfig.permissions.menu?.add : permissionService.hasPermission(user.role, "menu", "add");
	})();
	const canEdit = (() => {
		const roleConfig = roles.find((r) => r.name.toLowerCase() === user.role.toLowerCase());
		return roleConfig ? !!roleConfig.permissions.menu?.edit : permissionService.hasPermission(user.role, "menu", "edit");
	})();
	const canDelete = (() => {
		const roleConfig = roles.find((r) => r.name.toLowerCase() === user.role.toLowerCase());
		return roleConfig ? !!roleConfig.permissions.menu?.delete : permissionService.hasPermission(user.role, "menu", "delete");
	})();
	const { data: menuData = [], isLoading } = useQuery({
		queryKey: ["groupedMenu"],
		queryFn: menuService.getGrouped
	});
	(0, import_react.useEffect)(() => {
		if (menuData.length > 0 && activeCategoryId === null) setActiveCategoryId(menuData[0].categoryId);
	}, [menuData, activeCategoryId]);
	const activeCategory = menuData.find((c) => c.categoryId === activeCategoryId) || menuData[0];
	const deleteCategoryMutation = useMutation({
		mutationFn: (id) => categoryService.delete(id),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["groupedMenu"] });
			toast.success("Category deleted successfully");
			setActiveCategoryId(null);
		},
		onError: (err) => {
			if (err.message?.includes("409") || err.status === 409) toast.error("Cannot delete category with items inside. Move or delete items first.");
			else toast.error("Cannot delete category with items inside. Move or delete items first.");
		}
	});
	const toggleAvailabilityMutation = useMutation({
		mutationFn: (id) => menuService.toggleAvailability(id),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["groupedMenu"] });
		},
		onError: (err) => {
			toast.error(err.message || "Failed to update availability");
		}
	});
	const deleteItemMutation = useMutation({
		mutationFn: (id) => menuService.delete(id),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["groupedMenu"] });
			toast.success("Menu item deleted");
		},
		onError: () => toast.error("Failed to delete item")
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Menu",
		breadcrumbs: [{
			label: "Home",
			to: "/dashboard"
		}, { label: "Menu" }],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-96 bg-muted/60 animate-pulse rounded-xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid sm:grid-cols-2 lg:grid-cols-3 gap-4",
				children: [
					1,
					2,
					3
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 bg-muted/60 animate-pulse rounded-2xl" }, i))
			})]
		})
	});
	if (menuData.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Menu",
		breadcrumbs: [{
			label: "Home",
			to: "/dashboard"
		}, { label: "Menu" }],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center justify-center py-20 bg-muted/20 border-2 border-dashed border-white/5 rounded-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { className: "size-12 text-muted-foreground mb-4" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-lg font-medium",
					children: "No categories yet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mt-1 mb-6",
					children: "Create a category to start building your menu."
				}),
				canAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setIsAddCatOpen(true),
					className: "rounded-xl bg-primary text-primary-foreground copper-glow",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1" }), " Add category"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddCategoryModal, {
					isOpen: isAddCatOpen,
					onClose: () => setIsAddCatOpen(false)
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Menu",
		breadcrumbs: [{
			label: "Home",
			to: "/dashboard"
		}, { label: "Menu" }],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between flex-wrap gap-4 mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryTabs, {
					data: menuData,
					activeCategoryId: activeCategoryId || menuData[0].categoryId,
					onSelect: setActiveCategoryId,
					onAddClick: () => setIsAddCatOpen(true),
					onReorderClick: () => setIsReorderCatOpen(true),
					onDeleteCategory: (id) => {
						if (confirm("Are you sure you want to delete this category?")) deleteCategoryMutation.mutate(id);
					},
					canAdd,
					canEdit,
					canDelete
				}), canAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setItemModal({
						isOpen: true,
						mode: "create",
						initialData: null
					}),
					className: "rounded-xl bg-primary text-primary-foreground copper-glow ml-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1" }), " Add item"]
				})]
			}),
			activeCategory && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuGrid, {
				items: activeCategory.items,
				onEdit: (item) => setItemModal({
					isOpen: true,
					mode: "edit",
					initialData: item
				}),
				onDelete: (id) => {
					if (confirm("Are you sure you want to delete this item?")) deleteItemMutation.mutate(id);
				},
				onToggle: (id) => toggleAvailabilityMutation.mutate(id),
				canEdit,
				canDelete
			}),
			canAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddCategoryModal, {
				isOpen: isAddCatOpen,
				onClose: () => setIsAddCatOpen(false)
			}),
			canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReorderCategoriesModal, {
				isOpen: isReorderCatOpen,
				categories: menuData,
				onClose: () => setIsReorderCatOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemFormModal, {
				isOpen: itemModal.isOpen,
				mode: itemModal.mode,
				categories: menuData,
				initialData: itemModal.initialData,
				onClose: () => setItemModal({
					isOpen: false,
					mode: "create",
					initialData: null
				})
			})
		]
	});
}
function CategoryTabs({ data, activeCategoryId, onSelect, onAddClick, onReorderClick, onDeleteCategory, canAdd = true, canEdit = true, canDelete = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 flex-wrap",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex bg-muted/50 p-1.5 rounded-xl border border-white/5 flex-wrap gap-1",
			children: [data.map((c) => {
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative group flex items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => onSelect(c.categoryId),
						className: cn("px-4 py-2 text-sm font-medium rounded-lg transition-all cursor-pointer", c.categoryId === activeCategoryId ? "bg-primary text-primary-foreground border border-primary/20 shadow-md shadow-primary/20" : "text-muted-foreground hover:text-foreground hover:bg-muted"),
						children: c.categoryName
					}), canDelete && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: (e) => {
							e.stopPropagation();
							onDeleteCategory(c.categoryId);
						},
						className: "opacity-0 group-hover:opacity-100 hover:text-destructive absolute -top-1 -right-1 bg-background size-5 rounded-full border border-border shadow flex items-center justify-center transition-all cursor-pointer text-[10px]",
						title: "Delete category",
						children: "×"
					})]
				}, c.categoryId);
			}), canAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onAddClick,
				className: "size-8 rounded-lg bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground cursor-pointer transition border border-dashed border-white/10",
				title: "Add Category",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
			})]
		}), canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			onClick: onReorderClick,
			variant: "ghost",
			size: "sm",
			className: "h-9 text-muted-foreground hover:text-foreground font-medium rounded-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, { className: "size-4 mr-1 text-muted-foreground" }), " Reorder categories"]
		})]
	});
}
function MenuGrid({ items, onEdit, onDelete, onToggle, canEdit = true, canDelete = true }) {
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center py-20 bg-muted/10 border border-white/5 rounded-2xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { className: "size-10 text-muted-foreground/50 mb-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "No items in this category yet"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mt-2",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItemCard, {
			item,
			onEdit,
			onDelete,
			onToggle,
			canEdit,
			canDelete
		}, item.id))
	});
}
function MenuItemCard({ item, onEdit, onDelete, onToggle, canEdit = true, canDelete = true }) {
	const { data: settings } = useQuery({
		queryKey: ["settings"],
		queryFn: settingsService.getGeneralSettings
	});
	const currency = extractCurrencySymbol(settings?.currency);
	const [localAvailable, setLocalAvailable] = (0, import_react.useState)(item.available);
	(0, import_react.useEffect)(() => {
		setLocalAvailable(item.available);
	}, [item.available]);
	const handleToggle = () => {
		if (!canEdit) return;
		setLocalAvailable(!localAvailable);
		onToggle(item.id);
	};
	const getFoodImage = (imagePath) => {
		if (!imagePath) return void 0;
		if (imagePath.startsWith("http")) return imagePath;
		return `${BASE_URL}${imagePath}`;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: cn("p-0 rounded-2xl overflow-hidden border border-white/10 flex flex-col transition-all duration-300", !localAvailable && "opacity-60"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "h-40 overflow-hidden bg-muted/40 relative flex items-center justify-center",
			children: [item.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: getFoodImage(item.image),
				alt: item.name,
				className: "w-full h-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { className: "size-12 text-muted-foreground opacity-30" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute right-3 top-3 bg-black/50 backdrop-blur-md px-2 py-0.5 rounded-full flex items-center gap-1.5 border border-white/5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-full", item.veg ? "bg-success" : "bg-destructive") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] font-semibold text-white uppercase tracking-wider",
					children: item.veg ? "Veg" : "Non-Veg"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-4 flex-1 flex flex-col justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "font-semibold text-base line-clamp-1",
					children: item.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-primary font-bold text-base leading-none mt-0.5",
					children: [currency, item.price]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground mt-1 line-clamp-2 min-h-[32px]",
				children: item.description
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 pt-3 border-t border-white/5 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: cn("flex items-center gap-2 text-xs font-medium", canEdit ? "cursor-pointer" : "cursor-not-allowed opacity-70"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: localAvailable,
						onCheckedChange: handleToggle,
						disabled: !canEdit
					}), "Available"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						className: "size-8 p-0 hover:bg-muted text-muted-foreground hover:text-foreground cursor-pointer",
						onClick: () => onEdit(item),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" })
					}), canDelete && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						className: "size-8 p-0 text-destructive/80 hover:text-destructive hover:bg-destructive/10 cursor-pointer",
						onClick: () => onDelete(item.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
					})]
				})]
			})]
		})]
	});
}
function AddCategoryModal({ isOpen, onClose }) {
	const queryClient = useQueryClient();
	const createCategoryMutation = useMutation({
		mutationFn: (name) => categoryService.create({
			name,
			isActive: true
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["groupedMenu"] });
			toast.success("Category created successfully");
			onClose();
		},
		onError: (err) => {
			toast.error(err.message || "Failed to create category");
		}
	});
	if (!isOpen) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: isOpen,
		onOpenChange: (val) => !val && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "w-full sm:max-w-md overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
				className: "font-serif text-2xl",
				children: "New Category"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 space-y-4 px-4",
				onSubmit: (e) => {
					e.preventDefault();
					const name = new FormData(e.currentTarget).get("name");
					if (name?.trim()) createCategoryMutation.mutate(name.trim());
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "cat-name",
					children: "Category Name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "cat-name",
					name: "name",
					className: "rounded-xl mt-1.5",
					placeholder: "e.g. Desserts, Main Course",
					required: true
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3 justify-end pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						className: "rounded-xl",
						onClick: onClose,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "rounded-xl bg-primary text-primary-foreground copper-glow",
						children: "Create Category"
					})]
				})]
			})]
		})
	});
}
function ReorderCategoriesModal({ isOpen, categories, onClose }) {
	const queryClient = useQueryClient();
	const [items, setItems] = (0, import_react.useState)(categories);
	(0, import_react.useEffect)(() => {
		setItems(categories);
	}, [categories]);
	const reorderMutation = useMutation({
		mutationFn: (positions) => categoryService.reorder(positions),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["groupedMenu"] });
			toast.success("Categories reordered successfully");
			onClose();
		},
		onError: () => {
			toast.error("Failed to reorder categories");
		}
	});
	const sensors = useSensors(useSensor(PointerSensor), useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }));
	if (!isOpen) return null;
	const handleDragEnd = (event) => {
		const { active, over } = event;
		if (over && active.id !== over.id) setItems((prev) => {
			return arrayMove(prev, prev.findIndex((c) => c.categoryId === active.id), prev.findIndex((c) => c.categoryId === over.id));
		});
	};
	const handleSave = () => {
		const payload = items.map((item, index) => ({
			id: item.categoryId,
			position: index
		}));
		reorderMutation.mutate(payload);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: isOpen,
		onOpenChange: (val) => !val && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "w-full sm:max-w-md overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
				className: "font-serif text-2xl",
				children: "Reorder Categories"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 px-4 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DndContext, {
					sensors,
					collisionDetection: closestCenter,
					onDragEnd: handleDragEnd,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableContext, {
						items: items.map((c) => c.categoryId),
						strategy: verticalListSortingStrategy,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2 max-h-[400px] overflow-y-auto pr-1",
							children: items.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableCategoryItem, {
								id: c.categoryId,
								name: c.categoryName
							}, c.categoryId))
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3 justify-end pt-4 border-t border-white/5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "rounded-xl",
						onClick: onClose,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "rounded-xl bg-primary text-primary-foreground copper-glow",
						onClick: handleSave,
						children: "Save Order"
					})]
				})]
			})]
		})
	});
}
function SortableCategoryItem({ id, name }) {
	const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: setNodeRef,
		style: {
			transform: CSS.Transform.toString(transform),
			transition,
			opacity: isDragging ? .6 : 1
		},
		...attributes,
		...listeners,
		className: "p-3 bg-muted/60 hover:bg-muted border border-white/5 rounded-xl flex items-center justify-between cursor-grab active:cursor-grabbing text-sm font-medium transition",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, { className: "size-4 text-muted-foreground" })]
	});
}
function ItemFormModal({ isOpen, mode, categories, initialData, onClose }) {
	const queryClient = useQueryClient();
	const { data: settings } = useQuery({
		queryKey: ["settings"],
		queryFn: settingsService.getGeneralSettings
	});
	const currency = extractCurrencySymbol(settings?.currency);
	const [veg, setVeg] = (0, import_react.useState)(true);
	const [available, setAvailable] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		if (mode === "edit" && initialData) {
			setVeg(initialData.veg);
			setAvailable(initialData.available);
		} else {
			setVeg(true);
			setAvailable(true);
		}
	}, [
		mode,
		initialData,
		isOpen
	]);
	const createItemMutation = useMutation({
		mutationFn: (item) => menuService.create(item),
		onError: () => toast.error("Failed to create menu item")
	});
	const updateItemMutation = useMutation({
		mutationFn: ({ id, item }) => menuService.update(id, item),
		onError: () => toast.error("Failed to update menu item")
	});
	const uploadImageMutation = useMutation({
		mutationFn: ({ id, file }) => menuService.uploadImage(id, file),
		onError: () => toast.error("Failed to upload menu item image")
	});
	if (!isOpen) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: isOpen,
		onOpenChange: (val) => !val && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "w-full sm:max-w-lg overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
				className: "font-serif text-2xl",
				children: mode === "create" ? "New Menu Item" : "Edit Menu Item"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 space-y-4 px-4",
				onSubmit: async (e) => {
					e.preventDefault();
					const formData = new FormData(e.currentTarget);
					const fileInput = formData.get("imageFile");
					const price = parseFloat(formData.get("price"));
					if (isNaN(price) || price <= 0) {
						toast.error("Price must be greater than 0");
						return;
					}
					const categoryId = parseInt(formData.get("categoryId"));
					if (isNaN(categoryId)) {
						toast.error("Please select a valid category");
						return;
					}
					const itemData = {
						name: formData.get("name"),
						description: formData.get("description"),
						price,
						categoryId,
						veg,
						available
					};
					if (mode === "edit" && initialData) itemData.image = initialData.image;
					try {
						let itemId = initialData?.id;
						if (mode === "create") itemId = (await createItemMutation.mutateAsync(itemData)).id;
						else if (mode === "edit" && itemId) await updateItemMutation.mutateAsync({
							id: itemId,
							item: {
								...initialData,
								...itemData
							}
						});
						if (fileInput && fileInput.size > 0 && itemId) try {
							await uploadImageMutation.mutateAsync({
								id: itemId,
								file: fileInput
							});
						} catch (uploadErr) {
							console.error("Failed to upload image:", uploadErr);
						}
						queryClient.invalidateQueries({ queryKey: ["groupedMenu"] });
						toast.success(mode === "create" ? "Menu item created successfully" : "Menu item updated successfully");
						onClose();
					} catch (err) {
						console.error("Submit error:", err);
						toast.error(err?.message || "Failed to save menu item changes");
					}
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "item-name",
						children: "Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "item-name",
						name: "name",
						defaultValue: initialData?.name,
						className: "rounded-xl mt-1.5",
						required: true,
						placeholder: "e.g. Spicy Garlic Edamame"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "item-category",
							children: "Category"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "item-category",
							name: "categoryId",
							defaultValue: initialData?.categoryId || categories[0]?.categoryId,
							className: "w-full border border-white/10 rounded-xl h-10 px-3 mt-1.5 bg-background text-sm text-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
							required: true,
							children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c.categoryId,
								children: c.categoryName
							}, c.categoryId))
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "item-price",
							children: "Price"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "item-price",
							name: "price",
							type: "number",
							step: "0.01",
							min: "0.01",
							defaultValue: initialData?.price,
							className: "rounded-xl mt-1.5",
							placeholder: `${currency}0.00`,
							required: true
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "item-desc",
						children: "Description"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "item-desc",
						name: "description",
						defaultValue: initialData?.description,
						className: "rounded-xl mt-1.5",
						placeholder: "Describe the flavors, ingredients, sides..."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "item-image",
						children: "Image File"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "item-image",
						name: "imageFile",
						type: "file",
						accept: "image/*",
						className: "rounded-xl mt-1.5"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-6 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm font-medium cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: veg,
								onCheckedChange: setVeg
							}), "Vegetarian (Veg)"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm font-medium cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: available,
								onCheckedChange: setAvailable
							}), "Available"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3 justify-end pt-4 border-t border-white/5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "rounded-xl",
							onClick: onClose,
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "rounded-xl bg-primary text-primary-foreground copper-glow",
							children: mode === "create" ? "Create Item" : "Save Changes"
						})]
					})
				]
			})]
		})
	});
}
//#endregion
export { MenuPage as component };
