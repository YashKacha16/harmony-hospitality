import { n as apiClient } from "./settingsService-Dilksh94.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/menuService-DxjzhlGj.js
var menuService = {
	getAll: (categoryId) => apiClient.get(`/api/Menu${categoryId ? `?categoryId=${categoryId}` : ""}`),
	getGrouped: () => apiClient.get("/api/Menu/grouped"),
	getById: (id) => apiClient.get(`/api/Menu/${id}`),
	create: (menuItem) => apiClient.post("/api/Menu", menuItem),
	update: (id, menuItem) => apiClient.put(`/api/Menu/${id}`, menuItem),
	delete: (id) => apiClient.delete(`/api/Menu/${id}`),
	toggleAvailability: (id) => apiClient.request(`/api/Menu/${id}/availability`, { method: "PATCH" }),
	reorder: (positions) => apiClient.request("/api/Menu/reorder", {
		method: "PATCH",
		body: JSON.stringify(positions)
	}),
	uploadImage: (id, file) => {
		const formData = new FormData();
		formData.append("image", file);
		return apiClient.request(`/api/Menu/${id}/image`, {
			method: "POST",
			body: formData,
			headers: { "Content-Type": void 0 }
		});
	}
};
//#endregion
export { menuService as t };
