import { r as __toESM } from "../_runtime.mjs";
import { r as settingsService, t as BASE_URL } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { n as Input, r as cn, t as Button } from "./button-juXZH0rY.mjs";
import { t as HubConnectionBuilder } from "../_libs/microsoft__signalr+unenv.mjs";
import { n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { K as Clock, T as Plus, Y as CircleCheckBig, g as ShieldCheck, j as Minus, m as ShoppingBag, s as TriangleAlert, tt as ChefHat } from "../_libs/lucide-react.mjs";
import { t as Card } from "./card-DNWGqbqR.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-DDHupNVK.mjs";
import { a as SheetTitle, i as SheetHeader, n as SheetContent, o as SheetTrigger, t as Sheet } from "./sheet-DgrR67wC.mjs";
import { t as tableService } from "./tableService-LRzUVk7o.mjs";
import { t as orderService } from "./orderService-CwnQmAjk.mjs";
import { t as menuService } from "./menuService-DxjzhlGj.mjs";
import { t as Route } from "./order._token-DzNTblqg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order._token-DLtzoLXC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CustomerOrderingPage() {
	const { token } = Route.useParams();
	const [activeMenuCat, setActiveMenuCat] = (0, import_react.useState)(null);
	const [cart, setCart] = (0, import_react.useState)([]);
	const [specialInstructions, setSpecialInstructions] = (0, import_react.useState)("");
	const [isOrdered, setIsOrdered] = (0, import_react.useState)(false);
	const [placedOrderNumber, setPlacedOrderNumber] = (0, import_react.useState)("");
	const [placedOrderId, setPlacedOrderId] = (0, import_react.useState)(null);
	const [orderStatus, setOrderStatus] = (0, import_react.useState)("New");
	const [isCartOpen, setIsCartOpen] = (0, import_react.useState)(false);
	const { data: table, isLoading: isTableLoading, isError: isTableError, error: tableError } = useQuery({
		queryKey: ["resolveTable", token],
		queryFn: () => tableService.resolveByQrToken(token),
		retry: false
	});
	(0, import_react.useEffect)(() => {
		if (table?.activeOrderId) {
			setPlacedOrderId(table.activeOrderId);
			setPlacedOrderNumber(table.activeOrderNumber || "");
			setOrderStatus(table.activeOrderStatus || "New");
			setIsOrdered(true);
		}
	}, [table]);
	const { data: menuGrouped = [], isLoading: isMenuLoading } = useQuery({
		queryKey: ["menuGroupedCustomer"],
		queryFn: menuService.getGrouped
	});
	const { data: settings } = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.getGeneralSettings(),
		staleTime: 1e3 * 60 * 5
	});
	const currencyStr = settings?.currency || "$";
	const currencySymbolMatch = currencyStr.match(/\(([^)]+)\)/);
	const displayCurrency = currencySymbolMatch ? currencySymbolMatch[1] : currencyStr;
	(0, import_react.useEffect)(() => {
		if (menuGrouped.length > 0 && activeMenuCat === null) setActiveMenuCat(menuGrouped[0].categoryId);
	}, [menuGrouped, activeMenuCat]);
	const placeOrderMutation = useMutation({
		mutationFn: (order) => orderService.create(order),
		onSuccess: (data) => {
			setPlacedOrderNumber(data.orderNumber);
			setPlacedOrderId(data.id);
			setOrderStatus(data.status || "New");
			setIsOrdered(true);
			setCart([]);
			setIsCartOpen(false);
			toast.success("Order received! The kitchen is now preparing your food.");
		},
		onError: (err) => {
			toast.error(err.message || "Failed to submit order. Please ask a server.");
		}
	});
	(0, import_react.useEffect)(() => {
		if (!placedOrderId) return;
		const conn = new HubConnectionBuilder().withUrl(`${BASE_URL}/kitchenHub`).withAutomaticReconnect().build();
		conn.start().catch((err) => console.error("SignalR Customer Order Error: ", err));
		conn.on("OrderStatusChanged", (id, status) => {
			if (id === placedOrderId) {
				setOrderStatus(status);
				if (status === "Ready") toast.success("Your food is ready!");
				else if (status === "Served") toast.success("Your food has been served. Enjoy!");
			}
		});
		conn.on("OrderUpdated", (order) => {
			if (order.id === placedOrderId) setOrderStatus(order.status);
		});
		return () => {
			conn.stop();
		};
	}, [placedOrderId]);
	if (isTableLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#070e17] text-foreground flex flex-col items-center justify-center p-6 gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChefHat, { className: "size-12 text-primary animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold tracking-wide text-muted-foreground animate-pulse",
			children: "Locating your table..."
		})]
	});
	if (isTableError || !table) {
		const err = tableError;
		const isConflict = err?.status === 409 || err?.message?.includes("bill") || err?.message?.includes("unavailable");
		const errorMessage = err?.message || "We couldn't resolve this table's QR code. Please scan the QR code located on your table again.";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-screen bg-[#070e17] text-foreground flex flex-col items-center justify-center p-6 text-center gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "size-16 rounded-full bg-destructive/10 border border-destructive/20 flex items-center justify-center text-destructive",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-8" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-2xl font-bold text-foreground",
					children: isConflict ? "Table Unavailable" : "Invalid Table Code"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground max-w-sm",
					children: errorMessage
				})]
			})]
		});
	}
	const getTableNames = () => {
		if (table.isMerged && table.mergeGroupId) return table.name;
		return table.name;
	};
	const addToCart = (item) => {
		setCart((prev) => {
			if (prev.find((i) => i.menuItemId === item.id)) return prev.map((i) => i.menuItemId === item.id ? {
				...i,
				qty: i.qty + 1
			} : i);
			return [...prev, {
				menuItemId: item.id,
				name: item.name,
				qty: 1,
				price: item.price
			}];
		});
		toast.success(`${item.name} added to cart`);
	};
	const handlePlaceOrder = () => {
		if (cart.length === 0) return;
		const payload = {
			type: "DineIn",
			tableId: table.mergeGroupId ? null : table.id,
			mergeGroupId: table.mergeGroupId || null,
			isPriority: false,
			specialInstructions: specialInstructions.trim() || null,
			items: cart.map((i) => ({
				menuItemId: i.menuItemId,
				name: i.name,
				quantity: i.qty,
				priceAtOrder: i.price,
				isAddOn: false
			}))
		};
		placeOrderMutation.mutate(payload);
	};
	const totalItemsCount = cart.reduce((sum, i) => sum + i.qty, 0);
	const subtotal = cart.reduce((sum, i) => sum + i.qty * i.price, 0);
	if (isOrdered) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#070e17] text-foreground flex flex-col items-center justify-center p-6 text-center gap-5 max-w-md mx-auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "size-16 text-success animate-bounce" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-3xl font-bold",
					children: "Order Received!"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						"Order ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold text-foreground",
							children: placedOrderNumber
						}),
						" has been sent to the kitchen."
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4 bg-sidebar/20 border-border/50 w-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-center gap-2 text-xs font-bold uppercase text-primary tracking-wider",
					children: [
						orderStatus === "New" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4 animate-spin text-orange-500" }),
						orderStatus === "Preparing" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChefHat, { className: "size-4 text-orange-500 animate-pulse" }),
						(orderStatus === "Ready" || orderStatus === "Served") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "size-4 text-success" }),
						orderStatus === "New" && "Order Received",
						orderStatus === "Preparing" && "Kitchen is preparing your food",
						orderStatus === "Ready" && "Your food is ready!",
						orderStatus === "Served" && "Your food has been served"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground mt-2",
					children: [
						orderStatus === "New" && "Your order is in the queue.",
						orderStatus === "Preparing" && "Please sit back and relax. Your meal will be served shortly.",
						orderStatus === "Ready" && `A server will bring your food to Table ${getTableNames()} momentarily.`,
						orderStatus === "Served" && "Enjoy your meal! You can order more items anytime."
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "rounded-xl w-full py-3 bg-primary text-primary-foreground font-bold",
				onClick: () => setIsOrdered(false),
				children: "Order More Items"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#070e17] text-foreground pb-24 flex flex-col max-w-md mx-auto border-x border-border/20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "p-5 border-b border-border/30 sticky top-0 bg-[#070e17]/95 backdrop-blur-md z-40 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-1",
					children: [settings?.logoUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: settings.logoUrl.startsWith("http") ? settings.logoUrl : `http://localhost:5157${settings.logoUrl}`,
						alt: "Logo",
						className: "h-6 object-contain"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-serif text-2xl font-bold text-foreground",
						children: settings?.name || "Aurelia"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground font-semibold flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 text-success fill-success/10" }),
						"Ordering from Table ",
						getTableNames()
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border border-success/30 bg-success/10 text-success",
					children: "Live Order"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "p-4 flex-1",
				children: isMenuLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center py-12 text-muted-foreground text-sm",
					children: "Loading Menu..."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
					value: activeMenuCat?.toString(),
					onValueChange: (v) => setActiveMenuCat(Number(v)),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto scrollbar-none pb-2 border-b border-border/25",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, {
							className: "flex gap-1.5 h-auto bg-transparent p-0",
							children: menuGrouped.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: cat.categoryId.toString(),
								className: "rounded-xl px-4 py-2 text-xs font-bold border border-border/40 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground",
								children: cat.categoryName
							}, cat.categoryId))
						})
					}), menuGrouped.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: cat.categoryId.toString(),
						className: "space-y-3 mt-4 animate-in fade-in duration-200",
						children: cat.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 rounded-2xl border-border/40 bg-sidebar/20 flex gap-3.5 items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-3 items-center min-w-0 flex-1",
								children: [item.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "size-16 rounded-xl overflow-hidden relative flex-shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: item.image.startsWith("http") ? item.image : `${BASE_URL}${item.image}`,
										alt: item.name,
										className: "w-full h-full object-cover"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("absolute top-1 left-1 size-3 rounded-full border bg-background/90 flex items-center justify-center border-border", item.veg ? "border-success" : "border-destructive"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("block size-1.5 rounded-full", item.veg ? "bg-success" : "bg-destructive") })
									})]
								}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: "text-[13px] font-bold truncate text-foreground flex items-center gap-1.5",
											children: [!item.image && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: cn("size-3 rounded-full border flex-shrink-0 flex items-center justify-center bg-transparent", item.veg ? "border-success" : "border-destructive"),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("block size-1.5 rounded-full", item.veg ? "bg-success" : "bg-destructive") })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] text-muted-foreground line-clamp-1 mt-0.5",
											children: item.description
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs font-extrabold text-foreground block mt-1.5",
											children: [displayCurrency, item.price]
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								className: "size-8 p-0 rounded-xl border hover:bg-primary hover:text-white",
								onClick: () => addToCart({
									id: item.id,
									name: item.name,
									price: item.price
								}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
							})]
						}, item.id))
					}, cat.categoryId))]
				})
			}),
			cart.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed bottom-0 left-0 right-0 max-w-md mx-auto p-4 bg-background/95 backdrop-blur-md border-t border-border/30 z-40",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
					open: isCartOpen,
					onOpenChange: setIsCartOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "w-full py-6 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold flex justify-between px-5 shadow-lg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-4.5" }),
									"View Cart (",
									totalItemsCount,
									")"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm font-extrabold",
								children: [displayCurrency, subtotal]
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
						side: "bottom",
						className: "max-w-md mx-auto rounded-t-3xl p-6 bg-background border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
								className: "font-serif text-xl font-bold flex items-center justify-between text-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Your Selection" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground font-sans font-normal",
									children: [totalItemsCount, " items"]
								})]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-3.5 my-4 max-h-64 overflow-y-auto pr-1",
								children: cart.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-sm pb-2 border-b border-muted last:border-0 last:pb-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 min-w-0 pr-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-foreground truncate block",
											children: item.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs text-muted-foreground font-semibold",
											children: [
												displayCurrency,
												item.price,
												" each"
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												className: "size-7 rounded-lg bg-muted flex items-center justify-center text-foreground font-bold",
												onClick: () => setCart((c) => c.map((x, xi) => xi === idx ? {
													...x,
													qty: Math.max(1, x.qty - 1)
												} : x)),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "w-5 text-center font-bold text-foreground",
												children: item.qty
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												className: "size-7 rounded-lg bg-muted flex items-center justify-center text-foreground font-bold",
												onClick: () => setCart((c) => c.map((x, xi) => xi === idx ? {
													...x,
													qty: x.qty + 1
												} : x)),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												className: "size-7 text-destructive ml-1",
												onClick: () => setCart((c) => c.filter((_, xi) => xi !== idx)),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4 text-destructive" })
											})
										]
									})]
								}, idx))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4 pt-3 border-t border-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "Any special instructions for the chef?",
										value: specialInstructions,
										onChange: (e) => setSpecialInstructions(e.target.value),
										className: "rounded-xl font-medium"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between text-base font-bold text-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [displayCurrency, subtotal] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "w-full rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold py-3.5 shadow-md",
										onClick: handlePlaceOrder,
										disabled: placeOrderMutation.isPending,
										children: placeOrderMutation.isPending ? "Submitting order..." : "Confirm & Send to Kitchen"
									})
								]
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { CustomerOrderingPage as component };
