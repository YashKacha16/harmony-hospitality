import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order._token-DzNTblqg.js
var $$splitComponentImporter = () => import("./order._token-DLtzoLXC.mjs");
var Route = createFileRoute("/order/$token")({
	head: ({ params }) => ({ meta: [{ title: `Table Ordering — Aurelia` }, {
		name: "description",
		content: "Self-order menu from your table."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
