import { n as apiClient } from "./settingsService-Dilksh94.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orderService-CwnQmAjk.js
var orderService = {
	getKanban: (type) => apiClient.get(`/api/orders/kanban?type=${type}`),
	create: (order) => apiClient.post("/api/orders", order),
	updateStatus: (id, status) => apiClient.request(`/api/orders/${id}/status`, {
		method: "PATCH",
		body: JSON.stringify({ status })
	}),
	acknowledgeAddOns: (id) => apiClient.post(`/api/orders/${id}/acknowledge-addons`, {}),
	updateItems: (id, items) => apiClient.put(`/api/orders/${id}/items`, items),
	cancel: (id) => apiClient.post(`/api/orders/${id}/cancel`, {})
};
//#endregion
export { orderService as t };
