import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders-CXuSkCTI.js
var $$splitComponentImporter = () => import("./orders-isfY4pLo.mjs");
var Route = createFileRoute("/orders")({
	validateSearch: (search) => {
		return {
			tableId: search.tableId ? Number(search.tableId) : void 0,
			mergeGroupId: search.mergeGroupId ? Number(search.mergeGroupId) : void 0,
			editOrderId: search.editOrderId ? Number(search.editOrderId) : void 0,
			tab: search.tab ? String(search.tab) : void 0,
			roomNumber: search.roomNumber ? String(search.roomNumber) : void 0
		};
	},
	head: () => ({ meta: [{ title: "Orders — Aurelia" }, {
		name: "description",
		content: "Dine-in, room service and parcel orders with a live kitchen board."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
