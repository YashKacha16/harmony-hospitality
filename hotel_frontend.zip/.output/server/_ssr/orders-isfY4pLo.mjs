import { r as __toESM } from "../_runtime.mjs";
import { r as settingsService, t as BASE_URL } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { n as Input, r as cn, t as Button } from "./button-juXZH0rY.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as HubConnectionBuilder } from "../_libs/microsoft__signalr+unenv.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { H as Flag, K as Clock, O as Pen, T as Plus, X as CircleAlert, c as Trash2, j as Minus, t as X, tt as ChefHat, y as Send } from "../_libs/lucide-react.mjs";
import { o as permissionService, t as AppShell } from "./app-shell-C6Y1qr1C.mjs";
import { t as Card } from "./card-DNWGqbqR.mjs";
import { t as billingService } from "./billingService-BDz7A2Pa.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-DDHupNVK.mjs";
import { t as Label } from "./label-Bkz_RwW1.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogFooter, t as Dialog } from "./dialog-BtIFXM_M.mjs";
import { t as tableService } from "./tableService-LRzUVk7o.mjs";
import { t as orderService } from "./orderService-CwnQmAjk.mjs";
import { t as menuService } from "./menuService-DxjzhlGj.mjs";
import { t as Switch } from "./switch-BIIbVvK-.mjs";
import { t as Route } from "./orders-CXuSkCTI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders-isfY4pLo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var columns = [
	"New",
	"Preparing",
	"Ready",
	"Served"
];
function OrdersPage() {
	const queryClient = useQueryClient();
	const search = Route.useSearch();
	const navigate = useNavigate();
	const userRaw = typeof window !== "undefined" ? localStorage.getItem("user") : null;
	const user = userRaw ? JSON.parse(userRaw) : { role: "Admin" };
	const hasWaiterSide = permissionService.hasPermission(user.role, "orders", "waiterSide");
	const hasKitchenSide = permissionService.hasPermission(user.role, "orders", "kitchenSide");
	const [kds, setKds] = (0, import_react.useState)(() => {
		if (hasKitchenSide && !hasWaiterSide) return true;
		return false;
	});
	const [sourceTab, setSourceTab] = (0, import_react.useState)("Dine-in");
	const [activeMenuCat, setActiveMenuCat] = (0, import_react.useState)(null);
	const [cart, setCart] = (0, import_react.useState)([]);
	const [editingOrderItems, setEditingOrderItems] = (0, import_react.useState)([]);
	const [specialInstructions, setSpecialInstructions] = (0, import_react.useState)("");
	const [isPriorityOrder, setIsPriorityOrder] = (0, import_react.useState)(false);
	const [selectedTableOption, setSelectedTableOption] = (0, import_react.useState)(null);
	const [roomNumber, setRoomNumber] = (0, import_react.useState)("");
	const [customerName, setCustomerName] = (0, import_react.useState)("");
	const [editingOrder, setEditingOrder] = (0, import_react.useState)(null);
	const [editModalOpen, setEditModalOpen] = (0, import_react.useState)(false);
	const [editCartAdditions, setEditCartAdditions] = (0, import_react.useState)([]);
	const connectionRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (search.tab === "room-service") setSourceTab("Room Service");
		if (search.roomNumber) setRoomNumber(search.roomNumber);
	}, [search.tab, search.roomNumber]);
	const mappedOrderType = (tab) => {
		if (tab === "Dine-in") return "DineIn";
		if (tab === "Room Service") return "RoomService";
		return "Parcel";
	};
	const { data: kanbanData = {
		new: [],
		preparing: [],
		ready: [],
		served: []
	}, isLoading: isKanbanLoading } = useQuery({
		queryKey: ["kanbanOrders", sourceTab],
		queryFn: () => orderService.getKanban(mappedOrderType(sourceTab))
	});
	const { data: menuGrouped = [], isLoading: isMenuLoading } = useQuery({
		queryKey: ["menuGrouped"],
		queryFn: menuService.getGrouped
	});
	const { data: settings } = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.getGeneralSettings(),
		staleTime: 1e3 * 60 * 5
	});
	const currencySymbol = settings?.currency?.match(/\((.*?)\)/)?.[1] || settings?.currency || "$";
	const { data: tables = [] } = useQuery({
		queryKey: ["allTables"],
		queryFn: tableService.getAll
	});
	const allActiveOrdersForEdit = kanbanData ? [
		...kanbanData.new || [],
		...kanbanData.preparing || [],
		...kanbanData.ready || [],
		...kanbanData.served || []
	] : [];
	const activeOrder = (() => {
		if (sourceTab === "Dine-in" && selectedTableOption) return allActiveOrdersForEdit.find((o) => (selectedTableOption.mergeGroupId ? o.mergeGroupId === selectedTableOption.mergeGroupId : o.tableId === selectedTableOption.tableId) && !o.billId);
		if (sourceTab === "Room Service" && roomNumber.trim()) return allActiveOrdersForEdit.find((o) => o.type === "RoomService" && o.roomNumber === roomNumber.trim() && !o.billId);
		return null;
	})();
	(0, import_react.useEffect)(() => {
		if (activeOrder) {
			setEditingOrderItems(activeOrder.items);
			setSpecialInstructions(activeOrder.specialInstructions || "");
			setIsPriorityOrder(activeOrder.isPriority);
		} else {
			setEditingOrderItems([]);
			setSpecialInstructions("");
			setIsPriorityOrder(false);
		}
	}, [activeOrder?.id]);
	(0, import_react.useEffect)(() => {
		if (tables.length > 0) {
			if (search.mergeGroupId) {
				const siblings = tables.filter((s) => s.mergeGroupId === search.mergeGroupId);
				if (siblings.length > 0) {
					const names = siblings.map((s) => s.name).sort((a, b) => a.localeCompare(b)).join("+");
					setSelectedTableOption({
						label: `Table ${names}`,
						mergeGroupId: search.mergeGroupId
					});
					setSourceTab("Dine-in");
				}
			} else if (search.tableId) {
				const table = tables.find((t) => t.id === search.tableId);
				if (table) {
					setSelectedTableOption({
						label: `Table ${table.name}`,
						tableId: search.tableId
					});
					setSourceTab("Dine-in");
				}
			}
		}
	}, [
		search.tableId,
		search.mergeGroupId,
		tables
	]);
	(0, import_react.useEffect)(() => {
		if (search.editOrderId && kanbanData && tables.length > 0) {
			const match = [
				...kanbanData.new || [],
				...kanbanData.preparing || [],
				...kanbanData.ready || [],
				...kanbanData.served || []
			].find((o) => o.id === search.editOrderId);
			if (match && match.type === "DineIn") {
				setSourceTab("Dine-in");
				if (match.mergeGroupId) {
					const names = tables.filter((s) => s.mergeGroupId === match.mergeGroupId).map((s) => s.name).sort((a, b) => a.localeCompare(b)).join("+");
					setSelectedTableOption({
						label: `Table ${names}`,
						mergeGroupId: match.mergeGroupId
					});
				} else if (match.tableId) {
					const table = tables.find((t) => t.id === match.tableId);
					if (table) setSelectedTableOption({
						label: `Table ${table.name}`,
						tableId: match.tableId
					});
				}
			}
		}
	}, [
		search.editOrderId,
		kanbanData,
		tables
	]);
	(0, import_react.useEffect)(() => {
		const conn = new HubConnectionBuilder().withUrl(`${BASE_URL}/hubs/kitchen`).withAutomaticReconnect().build();
		conn.on("NewOrder", () => {
			queryClient.invalidateQueries({ queryKey: ["kanbanOrders"] });
		});
		conn.on("OrderStatusChanged", () => {
			queryClient.invalidateQueries({ queryKey: ["kanbanOrders"] });
		});
		conn.on("OrderUpdated", () => {
			queryClient.invalidateQueries({ queryKey: ["kanbanOrders"] });
		});
		conn.start().then(() => {
			conn.invoke("JoinKitchenGroup");
		}).catch((err) => console.error("SignalR Connection Error: ", err));
		connectionRef.current = conn;
		return () => {
			if (connectionRef.current) connectionRef.current.invoke("LeaveKitchenGroup").then(() => connectionRef.current?.stop()).catch((err) => console.error(err));
		};
	}, [queryClient]);
	(0, import_react.useEffect)(() => {
		if (menuGrouped.length > 0 && activeMenuCat === null) setActiveMenuCat(menuGrouped[0].categoryId);
	}, [menuGrouped, activeMenuCat]);
	const getTableOptions = () => {
		const options = [];
		const processedMergeGroups = /* @__PURE__ */ new Set();
		tables.forEach((t) => {
			if (t.isMerged && t.mergeGroupId) {
				if (!processedMergeGroups.has(t.mergeGroupId)) {
					processedMergeGroups.add(t.mergeGroupId);
					const names = tables.filter((s) => s.mergeGroupId === t.mergeGroupId).map((s) => s.name).sort((a, b) => a.localeCompare(b)).join("+");
					options.push({
						label: `Table ${names}`,
						mergeGroupId: t.mergeGroupId
					});
				}
			} else if (!t.isMerged) options.push({
				label: `Table ${t.name}`,
				tableId: t.id
			});
		});
		return options.sort((a, b) => a.label.localeCompare(b.label));
	};
	const createOrderMutation = useMutation({
		mutationFn: (order) => orderService.create(order),
		onSuccess: () => {
			toast.success("Order sent to kitchen successfully");
			setCart([]);
			setSpecialInstructions("");
			setIsPriorityOrder(false);
			setSelectedTableOption(null);
			setRoomNumber("");
			setCustomerName("");
			queryClient.invalidateQueries({ queryKey: ["kanbanOrders"] });
		},
		onError: (err) => {
			toast.error(err.message || "Failed to submit order");
		}
	});
	const updateStatusMutation = useMutation({
		mutationFn: ({ id, status }) => orderService.updateStatus(id, status),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["kanbanOrders"] });
		},
		onError: (err) => {
			toast.error(err.message || "Failed to update order status");
		}
	});
	const acknowledgeAddOnsMutation = useMutation({
		mutationFn: (id) => orderService.acknowledgeAddOns(id),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["kanbanOrders"] });
		},
		onError: (err) => {
			toast.error(err.message || "Failed to acknowledge items");
		}
	});
	const editOrderItemsMutation = useMutation({
		mutationFn: ({ id, items }) => orderService.updateItems(id, items),
		onSuccess: () => {
			toast.success("Order updated successfully");
			setCart([]);
			if (search.editOrderId) navigate({
				to: "/orders",
				search: {
					...search,
					editOrderId: void 0
				}
			});
			queryClient.invalidateQueries({ queryKey: ["kanbanOrders"] });
		},
		onError: (err) => {
			toast.error(err.message || "Failed to update order");
		}
	});
	const cancelOrderMutation = useMutation({
		mutationFn: (id) => orderService.cancel(id),
		onSuccess: () => {
			toast.success("Order cancelled successfully");
			queryClient.invalidateQueries({ queryKey: ["kanbanOrders"] });
		},
		onError: (err) => {
			toast.error(err.message || "Failed to cancel order");
		}
	});
	const generateBillMutation = useMutation({
		mutationFn: (id) => {
			return billingService.generateBill({
				orderId: id,
				serviceChargePercent: settings?.serviceChargePercent || 0,
				taxPercent: (settings?.cgstPercent || 0) + (settings?.sgstPercent || 0),
				cgstPercent: settings?.cgstPercent || 0,
				sgstPercent: settings?.sgstPercent || 0
			});
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["kanbanOrders"] });
			queryClient.invalidateQueries({ queryKey: ["bills"] });
			setSelectedTableOption(null);
			setCart([]);
			toast.success("Bill generated successfully! Check the Billing page.");
		},
		onError: (err) => {
			toast.error(err.message || "Failed to generate bill");
		}
	});
	const addToCart = (item) => {
		setCart((prev) => {
			if (prev.find((i) => i.menuItemId === item.id)) return prev.map((i) => i.menuItemId === item.id ? {
				...i,
				qty: i.qty + 1
			} : i);
			return [...prev, {
				menuItemId: item.id,
				name: item.name,
				qty: 1,
				price: item.price
			}];
		});
	};
	const handleSendToKitchen = () => {
		if (activeOrder) {
			if (cart.length === 0 && JSON.stringify(editingOrderItems) === JSON.stringify(activeOrder.items)) return toast.error("No changes made to update.");
			const payloadItems = [...editingOrderItems.map((i) => ({
				id: i.id,
				menuItemId: i.menuItemId,
				name: i.name,
				quantity: i.quantity,
				priceAtOrder: i.priceAtOrder,
				status: i.status,
				isAddOn: i.isAddOn
			})), ...cart.map((i) => ({
				menuItemId: i.menuItemId,
				name: i.name,
				quantity: i.qty,
				priceAtOrder: i.price,
				status: "Active",
				isAddOn: true
			}))];
			editOrderItemsMutation.mutate({
				id: activeOrder.id,
				items: payloadItems
			});
		} else {
			if (cart.length === 0) return toast.error("Your cart is empty.");
			const payload = {
				type: mappedOrderType(sourceTab),
				isPriority: isPriorityOrder,
				specialInstructions: specialInstructions.trim() || null,
				items: cart.map((i) => ({
					menuItemId: i.menuItemId,
					name: i.name,
					quantity: i.qty,
					priceAtOrder: i.price,
					isAddOn: false
				}))
			};
			if (sourceTab === "Dine-in") {
				if (!selectedTableOption) return toast.error("Please select a table option.");
				payload.tableId = selectedTableOption.tableId || null;
				payload.mergeGroupId = selectedTableOption.mergeGroupId || null;
			} else if (sourceTab === "Room Service") {
				if (!roomNumber.trim()) return toast.error("Please enter a room number.");
				payload.roomNumber = roomNumber.trim();
			} else {
				if (!customerName.trim()) return toast.error("Please enter customer name.");
				payload.customerName = customerName.trim();
			}
			createOrderMutation.mutate(payload);
		}
	};
	cart.reduce((s, i) => s + i.qty * i.price, 0);
	const handleOpenEdit = (order) => {
		navigate({
			to: "/orders",
			search: {
				...search,
				editOrderId: order.id
			}
		});
	};
	const handleCloseEditModal = () => {
		setEditModalOpen(false);
		setEditingOrder(null);
		setEditCartAdditions([]);
		if (search.editOrderId) navigate({
			to: "/orders",
			search: {
				...search,
				editOrderId: void 0
			}
		});
	};
	const handleSaveEdit = () => {
		if (!editingOrder) return;
		const payloadItems = [...editingOrder.items.map((i) => ({
			id: i.id,
			menuItemId: i.menuItemId,
			name: i.name,
			quantity: i.quantity,
			priceAtOrder: i.priceAtOrder,
			status: i.status,
			isAddOn: i.isAddOn
		})), ...editCartAdditions.map((i) => ({
			menuItemId: i.menuItemId,
			name: i.name,
			quantity: i.qty,
			priceAtOrder: i.price,
			status: "Active",
			isAddOn: true
		}))];
		editOrderItemsMutation.mutate({
			id: editingOrder.id,
			items: payloadItems
		});
	};
	const handleCancelItemInEdit = (itemId) => {
		if (!editingOrder) return;
		setEditingOrder({
			...editingOrder,
			items: editingOrder.items.map((i) => i.id === itemId ? {
				...i,
				status: "Cancelled"
			} : i)
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: kds ? "Kitchen display" : "Orders",
		breadcrumbs: [{
			label: "Home",
			to: "/dashboard"
		}, { label: "Orders" }],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mb-6 flex-wrap gap-4 border-b border-muted pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
					value: sourceTab,
					onValueChange: (v) => {
						setSourceTab(v);
						setCart([]);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "rounded-xl bg-muted/50 p-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "Dine-in",
								className: "rounded-lg px-4 py-2 font-medium",
								children: "Dine-in"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "Room Service",
								className: "rounded-lg px-4 py-2 font-medium",
								children: "Room service"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "Parcel",
								className: "rounded-lg px-4 py-2 font-medium",
								children: "Parcel"
							})
						]
					})
				}), hasWaiterSide && hasKitchenSide && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2.5 text-sm font-semibold select-none cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: kds,
						onCheckedChange: setKds
					}), "Kitchen display mode"]
				})]
			}),
			!kds && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-[1fr_380px] gap-6 mb-8 animate-in fade-in duration-300",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "p-6 rounded-2xl bg-sidebar/30 border border-border/40",
					children: isMenuLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-center py-12 text-muted-foreground",
						children: "Loading menu..."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
						value: activeMenuCat?.toString(),
						onValueChange: (v) => setActiveMenuCat(Number(v)),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, {
							className: "rounded-xl flex-wrap h-auto bg-muted/30 p-1 mb-4 gap-1",
							children: menuGrouped.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: cat.categoryId.toString(),
								className: "rounded-lg",
								children: cat.categoryName
							}, cat.categoryId))
						}), menuGrouped.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: cat.categoryId.toString(),
							className: "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 mt-2",
							children: cat.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "p-0 rounded-2xl overflow-hidden border border-border/40 bg-background/50 hover:border-primary/50 transition-colors flex flex-col",
								children: [item.image && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "h-28 overflow-hidden relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: item.image.startsWith("http") ? item.image : `http://localhost:5157${item.image}`,
										alt: item.name,
										className: "w-full h-full object-cover group-hover:scale-105 transition-transform"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("absolute top-2 left-2 size-4.5 rounded-full border bg-background/90 flex items-center justify-center border-border", item.veg ? "border-success" : "border-destructive"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("block size-2 rounded-full", item.veg ? "bg-success" : "bg-destructive") })
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 flex-1 flex flex-col justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [!item.image && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: cn("size-4.5 shrink-0 rounded-full border flex items-center justify-center border-border", item.veg ? "border-success" : "border-destructive"),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("block size-2 rounded-full", item.veg ? "bg-success" : "bg-destructive") })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-semibold leading-snug line-clamp-1 text-foreground",
											children: item.name
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground line-clamp-1 mt-1",
										children: item.description
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mt-3 pt-2 border-t border-muted/50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-sm font-bold text-foreground",
											children: [currencySymbol, item.price]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "ghost",
											className: "size-8 p-0 rounded-xl hover:bg-primary hover:text-white transition-colors border border-border",
											onClick: () => addToCart({
												id: item.id,
												name: item.name,
												price: item.price
											}),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
										})]
									})]
								})]
							}, item.id))
						}, cat.categoryId))]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-6 rounded-2xl border border-border/40 bg-sidebar/30 flex flex-col h-fit sticky top-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-serif text-xl font-bold flex items-center justify-between text-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Cart" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-sans font-normal text-muted-foreground",
								children: [cart.length, " items"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-3.5 border-b border-muted pb-4 mb-4",
							children: [
								sourceTab === "Dine-in" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "dineinTable",
										children: "Select Table"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: "dineinTable",
										className: "w-full rounded-xl border border-input bg-background px-3 py-2 text-sm focus-visible:ring-2 font-medium",
										value: selectedTableOption ? selectedTableOption.mergeGroupId ? `group-${selectedTableOption.mergeGroupId}` : `table-${selectedTableOption.tableId}` : "",
										onChange: (e) => {
											const val = e.target.value;
											if (!val) setSelectedTableOption(null);
											else if (val.startsWith("group-")) {
												const groupId = Number(val.replace("group-", ""));
												const opt = getTableOptions().find((o) => o.mergeGroupId === groupId);
												setSelectedTableOption(opt || null);
											} else {
												const tableId = Number(val.replace("table-", ""));
												const opt = getTableOptions().find((o) => o.tableId === tableId);
												setSelectedTableOption(opt || null);
											}
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "-- Choose Table --"
										}), getTableOptions().map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: opt.mergeGroupId ? `group-${opt.mergeGroupId}` : `table-${opt.tableId}`,
											children: opt.label
										}, i))]
									})]
								}),
								sourceTab === "Room Service" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "roomNum",
										children: "Room Number"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "roomNum",
										placeholder: "e.g. 305",
										value: roomNumber,
										onChange: (e) => setRoomNumber(e.target.value),
										className: "rounded-xl font-medium"
									})]
								}),
								sourceTab === "Parcel" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "custName",
										children: "Customer Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "custName",
										placeholder: "Enter customer name",
										value: customerName,
										onChange: (e) => setCustomerName(e.target.value),
										className: "rounded-xl font-medium"
									})]
								})
							]
						}),
						activeOrder && editingOrderItems.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 border-b border-muted pb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs font-semibold text-orange-600 mb-2 uppercase tracking-wider flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Placed Items (",
									activeOrder.orderNumber,
									")"
								] }), activeOrder.status === "New" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-[10px] text-muted-foreground hover:text-foreground font-semibold normal-case underline",
									onClick: () => {
										setSelectedTableOption(null);
										setCart([]);
										if (search.editOrderId) navigate({
											to: "/orders",
											search: {
												...search,
												editOrderId: void 0
											}
										});
									},
									children: "Deselect"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-3 max-h-48 overflow-y-auto pr-1",
								children: editingOrderItems.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-sm pb-2 border-b border-muted/30 last:border-0 last:pb-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 min-w-0 pr-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: cn("font-semibold text-foreground truncate", item.status === "Cancelled" && "line-through text-destructive"),
											children: [
												item.quantity,
												"× ",
												item.name,
												item.isAddOn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "ml-1 text-[9px] px-1 py-0.2 rounded-md bg-orange-600/15 text-orange-600 font-extrabold uppercase",
													children: "Add-on"
												}),
												item.status === "Cancelled" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "ml-1 text-[9px] px-1 py-0.2 rounded-md bg-destructive/15 text-destructive font-extrabold uppercase",
													children: "Cancelled"
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs text-muted-foreground font-medium",
											children: [
												currencySymbol,
												item.priceAtOrder,
												" each"
											]
										})]
									}), item.status === "Active" && activeOrder.status === "New" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "size-7 rounded-lg hover:bg-destructive/10 text-destructive flex items-center justify-center transition-colors",
										onClick: () => {
											setEditingOrderItems((prev) => prev.map((x) => x.id === item.id ? {
												...x,
												status: "Cancelled"
											} : x));
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
									})]
								}, idx))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wider",
							children: activeOrder ? "Add New Items" : "Items in Cart"
						}),
						cart.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center py-6 text-muted-foreground text-sm flex flex-col items-center justify-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChefHat, { className: "size-8 opacity-40 animate-bounce" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: activeOrder ? "Add menu items above." : "Your cart is empty." })]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3 max-h-64 overflow-y-auto pr-1 mb-4",
							children: cart.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-sm pb-2 border-b border-muted/50 last:border-0 last:pb-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 min-w-0 pr-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-semibold text-foreground truncate",
										children: item.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground font-medium",
										children: [
											currencySymbol,
											item.price,
											" each"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											className: "size-7 rounded-lg bg-muted hover:bg-muted/80 text-foreground flex items-center justify-center transition-colors",
											onClick: () => setCart((c) => c.map((x, xi) => xi === idx ? {
												...x,
												qty: Math.max(1, x.qty - 1)
											} : x)),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-5 text-center font-bold text-foreground",
											children: item.qty
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											className: "size-7 rounded-lg bg-muted hover:bg-muted/80 text-foreground flex items-center justify-center transition-colors",
											onClick: () => setCart((c) => c.map((x, xi) => xi === idx ? {
												...x,
												qty: x.qty + 1
											} : x)),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											className: "size-7 rounded-lg hover:bg-destructive/10 text-destructive flex items-center justify-center transition-colors",
											onClick: () => setCart((c) => c.filter((_, xi) => xi !== idx)),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
										})
									]
								})]
							}, idx))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4 pt-4 border-t border-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "Special instructions…",
									value: specialInstructions,
									onChange: (e) => setSpecialInstructions(e.target.value),
									className: "rounded-xl font-medium"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-xs font-semibold select-none cursor-pointer text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: isPriorityOrder,
										onChange: (e) => setIsPriorityOrder(e.target.checked),
										className: "rounded border-border text-primary focus:ring-primary size-4"
									}), "Mark as high-priority order"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5 text-xs text-muted-foreground border-t border-muted/50 pt-3",
									children: [activeOrder && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Placed Items" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, editingOrderItems.filter((i) => i.status !== "Cancelled").reduce((s, i) => s + i.quantity * i.priceAtOrder, 0)] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "New Additions" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, cart.reduce((s, i) => s + i.qty * i.price, 0)] })]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between text-base font-bold text-foreground pt-1.5 border-t border-dashed border-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: activeOrder ? "New Total" : "Subtotal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, activeOrder ? editingOrderItems.filter((i) => i.status !== "Cancelled").reduce((s, i) => s + i.quantity * i.priceAtOrder, 0) + cart.reduce((s, i) => s + i.qty * i.price, 0) : cart.reduce((s, i) => s + i.qty * i.price, 0)] })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									className: "w-full rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 shadow-md",
									onClick: handleSendToKitchen,
									disabled: activeOrder ? editOrderItemsMutation.isPending || cart.length === 0 && JSON.stringify(editingOrderItems) === JSON.stringify(activeOrder.items) : createOrderMutation.isPending || cart.length === 0,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4 mr-1.5" }),
										" ",
										activeOrder ? "Update order" : "Send to kitchen"
									]
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("grid gap-5", kds ? "grid-cols-1 md:grid-cols-2 xl:grid-cols-4" : "grid-cols-1 md:grid-cols-2 xl:grid-cols-4"),
				children: columns.map((col) => {
					const key = col.toLowerCase();
					let items = kanbanData[key] || [];
					if (col === "Served") items = [...items].sort((a, b) => {
						const getPriority = (o) => {
							if (o.billStatus === "Paid") return 2;
							if (o.billId && o.billStatus === "Pending") return 1;
							return 0;
						};
						return getPriority(a) - getPriority(b);
					});
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b pb-2 border-muted/80",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("font-serif tracking-widest uppercase font-bold text-foreground/95", kds ? "text-lg" : "text-sm"),
								children: col
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs bg-muted text-muted-foreground font-sans px-2.5 py-0.5 rounded-full font-bold",
								children: items.length
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4 max-h-[600px] overflow-y-auto pr-1",
							children: [items.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
								o,
								kds,
								onEdit: handleOpenEdit,
								onCancel: () => cancelOrderMutation.mutate(o.id),
								onStatusChange: (status) => updateStatusMutation.mutate({
									id: o.id,
									status
								}),
								onAcknowledge: () => acknowledgeAddOnsMutation.mutate(o.id),
								onGenerateBill: () => generateBillMutation.mutate(o.id),
								isPending: updateStatusMutation.isPending || cancelOrderMutation.isPending,
								currencySymbol
							}, o.id)), items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-dashed border-border/60 p-8 text-center text-xs text-muted-foreground bg-sidebar/5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChefHat, { className: "size-7 mx-auto opacity-40 mb-2.5" }),
									"No ",
									col.toLowerCase(),
									" orders"
								]
							})]
						})]
					}, col);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: editModalOpen,
				onOpenChange: (open) => {
					if (!open) handleCloseEditModal();
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-xl rounded-2xl p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "font-serif text-2xl",
							children: ["Edit Order ", editingOrder?.orderNumber]
						}) }),
						editingOrder && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5 mt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Current Items" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "border border-muted rounded-xl p-3 bg-muted/10 space-y-2 max-h-48 overflow-y-auto",
										children: editingOrder.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-sm py-1 border-b last:border-b-0 border-muted/50",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: cn("font-medium", item.status === "Cancelled" && "line-through text-destructive"),
												children: [
													item.quantity,
													"× ",
													item.name,
													item.isAddOn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "ml-2 text-[10px] px-1.5 py-0.5 rounded-full bg-orange-600/10 text-orange-600 border border-orange-600/20 font-semibold",
														children: "Add-on"
													}),
													item.status === "Cancelled" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "ml-2 text-[10px] px-1.5 py-0.5 rounded-full bg-destructive/15 text-destructive font-semibold",
														children: "Cancelled"
													})
												]
											}), item.status === "Active" && editingOrder.status === "New" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "ghost",
												className: "size-7 p-0 rounded-lg text-destructive hover:bg-destructive/10",
												onClick: () => handleCancelItemInEdit(item.id),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4.5" })
											})]
										}, item.id))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2 pt-2 border-t border-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Add More Items (Add-ons)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-2 gap-3 max-h-40 overflow-y-auto p-1",
										children: menuGrouped.flatMap((c) => c.items).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between p-2 rounded-lg border text-xs bg-background",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-foreground truncate pr-1",
												children: item.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "outline",
												className: "size-6 p-0 rounded",
												onClick: () => {
													setEditCartAdditions((prev) => {
														if (prev.find((i) => i.menuItemId === item.id)) return prev.map((i) => i.menuItemId === item.id ? {
															...i,
															qty: i.qty + 1
														} : i);
														return [...prev, {
															menuItemId: item.id,
															name: item.name,
															qty: 1,
															price: item.price
														}];
													});
												},
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" })
											})]
										}, item.id))
									})]
								}),
								editCartAdditions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Pending Add-ons" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "border border-primary/20 rounded-xl p-3 bg-primary/5 space-y-2",
										children: editCartAdditions.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-medium text-foreground",
												children: [
													item.qty,
													"× ",
													item.name,
													" (",
													currencySymbol,
													item.price,
													" each)"
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														className: "size-5 rounded bg-muted flex items-center justify-center text-foreground",
														onClick: () => setEditCartAdditions((c) => c.map((x, xi) => xi === idx ? {
															...x,
															qty: Math.max(1, x.qty - 1)
														} : x)),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "w-4 text-center font-bold",
														children: item.qty
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														className: "size-5 rounded bg-muted flex items-center justify-center text-foreground",
														onClick: () => setEditCartAdditions((c) => c.map((x, xi) => xi === idx ? {
															...x,
															qty: x.qty + 1
														} : x)),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														className: "size-5 text-destructive ml-1",
														onClick: () => setEditCartAdditions((c) => c.filter((_, xi) => xi !== idx)),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
													})
												]
											})]
										}, idx))
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "mt-6 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								className: "rounded-xl",
								onClick: handleCloseEditModal,
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold",
								onClick: handleSaveEdit,
								disabled: editOrderItemsMutation.isPending,
								children: editOrderItemsMutation.isPending ? "Saving..." : "Save Changes"
							})]
						})
					]
				})
			})
		]
	});
}
function OrderCard({ o, kds, onEdit, onCancel, onStatusChange, onAcknowledge, onGenerateBill, isPending, currencySymbol }) {
	const getElapsedMinutes = (createdAtStr) => {
		const dateStr = createdAtStr.endsWith("Z") ? createdAtStr : `${createdAtStr}Z`;
		const elapsed = Math.max(0, Date.now() - new Date(dateStr).getTime());
		return `${Math.floor(elapsed / 6e4)}m`;
	};
	const [timeStr, setTimeStr] = (0, import_react.useState)(getElapsedMinutes(o.createdAt));
	(0, import_react.useEffect)(() => {
		const timer = setInterval(() => {
			setTimeStr(getElapsedMinutes(o.createdAt));
		}, 3e4);
		return () => clearInterval(timer);
	}, [o.createdAt]);
	const locationLabel = () => {
		if (o.type === "DineIn") return o.tableName || "Table --";
		if (o.type === "RoomService") return `Room ${o.roomNumber}`;
		return o.parcelCode || "Parcel";
	};
	const statusPillColor = (status) => {
		if (status === "New") return "bg-blue-600/20 border-blue-600 text-blue-500";
		if (status === "Preparing") return "bg-warning/20 border-warning text-warning";
		if (status === "Ready") return "bg-success/20 border-success text-success";
		return "bg-muted border-muted-foreground/30 text-muted-foreground";
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: cn("rounded-2xl p-5 border relative bg-background/50 backdrop-blur-xs flex flex-col justify-between transition-shadow shadow-sm hover:shadow-md", o.isPriority ? "border-destructive/40 bg-destructive/5" : "border-border/60", o.hasNewAddOns && "ring-2 ring-orange-500 animate-pulse border-orange-500"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("font-serif font-bold text-foreground", kds ? "text-2xl" : "text-lg"),
					children: o.orderNumber
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-muted-foreground mt-1 flex items-center gap-1.5 font-medium",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "capitalize",
							children: o.type === "DineIn" ? "Dine-in" : o.type === "RoomService" ? "Room Service" : "Parcel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: locationLabel() })
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-end gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border", statusPillColor(o.status)),
							children: o.status
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1 text-xs text-muted-foreground font-semibold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
								" ",
								timeStr
							]
						}),
						o.isPriority && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1 text-[10px] text-destructive uppercase tracking-wider font-extrabold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "size-3 fill-destructive" }), " Priority"]
						})
					]
				})]
			}),
			o.hasNewAddOns && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: onAcknowledge,
				className: "mt-3 w-full bg-orange-600/10 border border-orange-600/20 text-orange-600 hover:bg-orange-600/20 transition-colors text-[10px] font-extrabold uppercase py-1.5 px-3 rounded-lg flex items-center justify-center gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-3.5" }), "New items added (Tap to Acknowledge)"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 space-y-2 border-t border-muted/50 pt-3",
				children: o.items.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("flex justify-between text-sm", item.status === "Cancelled" && "line-through text-destructive/70"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5 font-medium text-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								item.quantity,
								"× ",
								item.name
							] }),
							item.isAddOn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] px-1.5 py-0.5 rounded-full border border-orange-600/20 bg-orange-600/10 text-orange-600 font-extrabold uppercase",
								children: "Add-on"
							}),
							item.status === "Cancelled" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] px-1.5 py-0.5 rounded-full bg-destructive/15 text-destructive font-extrabold uppercase",
								children: "Cancelled"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground font-semibold",
						children: [currencySymbol, item.priceAtOrder]
					})]
				}, idx))
			}),
			o.specialInstructions && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 text-xs italic text-muted-foreground bg-muted/10 p-2 rounded-lg border border-border/20",
				children: ["Note: ", o.specialInstructions]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 pt-3 border-t border-muted/50",
			children: kds ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-2",
				children: [
					o.status === "New" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							className: "rounded-xl text-xs font-bold border-muted",
							onClick: () => onStatusChange("Preparing"),
							disabled: isPending,
							children: "Start preparing"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							className: "rounded-xl text-xs font-bold bg-success text-white hover:bg-success/95",
							onClick: () => onStatusChange("Ready"),
							disabled: isPending,
							children: "Mark ready"
						})]
					}),
					o.status === "Preparing" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						className: "rounded-xl text-xs font-bold bg-success text-white hover:bg-success/95 w-full",
						onClick: () => onStatusChange("Ready"),
						disabled: isPending,
						children: "Mark ready"
					}),
					o.status === "Ready" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						className: "rounded-xl text-xs font-bold bg-primary text-primary-foreground w-full",
						onClick: () => onStatusChange("Served"),
						disabled: isPending,
						children: "Mark served"
					}),
					o.status === "Served" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-col gap-2",
						children: (() => {
							if (o.billStatus === "Paid") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-success text-center font-bold uppercase tracking-wider",
								children: "Paid & Completed"
							});
							if (o.billId && o.billStatus === "Pending") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-warning text-center font-bold uppercase tracking-wider py-2",
								children: "Bill is generated"
							});
							if (o.type === "RoomService") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-blue-500 text-center font-bold uppercase tracking-wider py-2",
								children: "Added to Room Bill"
							});
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								className: "rounded-xl text-xs font-bold border-primary text-primary w-full hover:bg-primary/10",
								onClick: onGenerateBill,
								disabled: isPending,
								children: "Generate Bill"
							});
						})()
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [o.status === "Served" && (() => {
					if (o.billStatus === "Paid") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-success text-center font-bold uppercase tracking-wider py-1.5",
						children: "Paid & Completed"
					});
					if (o.billId && o.billStatus === "Pending") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-warning text-center font-bold uppercase tracking-wider py-1.5",
						children: "Bill is generated"
					});
					if (o.type === "RoomService") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-blue-500 text-center font-bold uppercase tracking-wider py-1.5",
						children: "Added to Room Bill"
					});
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						className: "rounded-xl text-xs font-bold border-primary text-primary w-full hover:bg-primary/10",
						onClick: onGenerateBill,
						disabled: isPending,
						children: "Generate Bill"
					});
				})(), !o.billId && o.billStatus !== "Paid" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						className: "rounded-lg flex-1 text-xs font-bold border-muted hover:bg-muted",
						onClick: () => onEdit(o),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pen, { className: "size-3 mr-1" }), " Edit"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						className: "rounded-lg text-destructive hover:bg-destructive/10 text-xs font-bold",
						onClick: onCancel,
						disabled: o.status !== "New" || isPending,
						children: "Cancel"
					})]
				})]
			})
		})]
	});
}
//#endregion
export { OrdersPage as component };
