import { r as __toESM } from "../_runtime.mjs";
import { r as settingsService } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as bookingService } from "./bookingService-TCPCmwod.mjs";
import { t as Route } from "./print-booking._bookingId-BppNEzIj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/print-booking._bookingId-BQfy30vP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PrintBookingBillPage() {
	const { bookingId } = Route.useParams();
	const id = Number(bookingId);
	const { data: bill, isLoading: isLoadingBill } = useQuery({
		queryKey: ["booking-bill", id],
		queryFn: () => bookingService.getRoomBill(id)
	});
	const { data: settings, isLoading: isLoadingSettings } = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.getGeneralSettings()
	});
	const currencySymbol = settings?.currency?.match(/\((.*?)\)/)?.[1] || settings?.currency || "$";
	(0, import_react.useEffect)(() => {
		if (!isLoadingBill && !isLoadingSettings && bill && settings) setTimeout(() => {
			window.print();
		}, 500);
	}, [
		isLoadingBill,
		isLoadingSettings,
		bill,
		settings
	]);
	if (isLoadingBill || isLoadingSettings) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-8 text-center text-black bg-white min-h-screen",
		children: "Loading bill..."
	});
	if (!bill) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-8 text-center text-red-500 bg-white min-h-screen",
		children: "Bill not found"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "bg-white text-black min-h-screen p-8 font-sans",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-3xl mx-auto border border-gray-200 p-10 shadow-sm print:shadow-none print:border-none print:p-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between items-start border-b-2 border-gray-800 pb-6 mb-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-3xl font-bold uppercase tracking-wider",
							children: settings?.name || "Hotel"
						}),
						settings?.address && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-gray-600 mt-2 whitespace-pre-wrap leading-tight max-w-xs",
							children: settings.address
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-gray-600 mt-1",
							children: [
								settings?.phone && `Tel: ${settings.phone}`,
								settings?.phone && settings?.email && " | ",
								settings?.email && `${settings.email}`
							]
						})
					] }), settings?.logoUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: settings.logoUrl.startsWith("http") ? settings.logoUrl : `http://localhost:5157${settings.logoUrl}`,
						alt: "Logo",
						className: "h-20 object-contain print:grayscale"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center mb-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-serif font-semibold text-gray-800 uppercase tracking-widest",
						children: "Invoice"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between mb-8 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-gray-700 w-24 inline-block",
								children: "Guest Name:"
							}),
							" ",
							bill.guestName
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-gray-700 w-24 inline-block",
								children: "Room No:"
							}),
							" ",
							bill.roomNumber
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1 text-right",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-gray-700 mr-2",
									children: "Check-in:"
								}),
								" ",
								new Date(bill.checkInDateTime).toLocaleDateString()
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-gray-700 mr-2",
									children: "Check-out:"
								}),
								" ",
								new Date(bill.checkOutDateTime).toLocaleDateString()
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-gray-700 mr-2",
									children: "Nights:"
								}),
								" ",
								bill.billedNights
							] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm mb-8 border-collapse",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "bg-gray-100 border-y border-gray-300 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-3 px-4 font-semibold text-gray-700",
							children: "Description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-3 px-4 font-semibold text-gray-700 text-right",
							children: "Amount"
						})]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-gray-200",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "py-4 px-4 text-gray-800",
							children: ["Room Charges ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-gray-500 text-xs ml-1",
								children: [
									"(",
									bill.billedNights,
									" nights × ",
									currencySymbol,
									bill.roomPricePerNight,
									")"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "py-4 px-4 text-right text-gray-800 font-medium",
							children: [currencySymbol, bill.totalRoomAmount.toFixed(2)]
						})]
					}), bill.restaurantOrders && bill.restaurantOrders.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
							className: "border-b border-gray-200 bg-gray-50",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 2,
								className: "py-2 px-4 font-medium text-gray-700",
								children: "Restaurant & Room Service"
							})
						}),
						bill.restaurantOrders.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-gray-100",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2 px-8 text-gray-800 font-medium",
								children: ["Order #", o.orderNumber]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2 px-4 text-right text-gray-800 font-medium",
								children: [currencySymbol, o.subtotal.toFixed(2)]
							})]
						}), o.items && o.items.length > 0 && o.items.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-gray-50/50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-1 px-12 text-gray-500 text-sm",
								children: [
									item.name,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs ml-1",
										children: ["x ", item.quantity]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-1 px-4 text-right text-gray-500 text-sm",
								children: [currencySymbol, (item.priceAtOrder * item.quantity).toFixed(2)]
							})]
						}, `${o.id}-item-${idx}`))] }, o.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-gray-200",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 px-4 text-gray-700 text-right font-medium",
								children: "Restaurant Total:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-3 px-4 text-right text-gray-800 font-medium",
								children: [currencySymbol, bill.totalRestaurantAmount.toFixed(2)]
							})]
						})
					] })] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-80 space-y-3 text-sm",
						children: [
							bill.taxesAmount !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-gray-700 px-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Taxes (",
									bill.cgstPercent + bill.sgstPercent,
									"%)"
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium",
									children: [currencySymbol, bill.taxesAmount.toFixed(2)]
								})]
							}),
							bill.serviceChargeAmount !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-gray-700 px-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Service Charge (",
									bill.serviceChargePercent,
									"%)"
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium",
									children: [currencySymbol, bill.serviceChargeAmount.toFixed(2)]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-gray-700 px-4 pt-2 border-t border-gray-200",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total Amount" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium",
									children: [currencySymbol, bill.totalAmount.toFixed(2)]
								})]
							}),
							bill.advanceAmount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-emerald-600 px-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Advance Paid" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium",
									children: [
										"-",
										currencySymbol,
										bill.advanceAmount.toFixed(2)
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-lg font-bold text-gray-900 px-4 py-3 bg-gray-100 rounded border border-gray-200",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Amount Due" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, bill.dueAmount.toFixed(2)] })]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-16 pt-8 border-t border-gray-300 text-center text-sm text-gray-600",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: "Thank you for staying with us!"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1",
						children: "We hope to welcome you back soon."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex justify-center gap-4 print:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => window.close(),
						className: "px-6 py-2 bg-gray-200 rounded-lg font-bold text-gray-700 hover:bg-gray-300",
						children: "Close"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => window.print(),
						className: "px-6 py-2 bg-primary text-primary-foreground rounded-lg font-bold hover:bg-primary/90",
						children: "Print Again"
					})]
				})
			]
		})
	});
}
//#endregion
export { PrintBookingBillPage as component };
