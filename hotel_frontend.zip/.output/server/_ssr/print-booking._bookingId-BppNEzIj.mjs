import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/print-booking._bookingId-BppNEzIj.js
var $$splitComponentImporter = () => import("./print-booking._bookingId-BQfy30vP.mjs");
var Route = createFileRoute("/print-booking/$bookingId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
