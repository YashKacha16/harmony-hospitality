import { r as __toESM } from "../_runtime.mjs";
import { r as settingsService } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as billingService } from "./billingService-BDz7A2Pa.mjs";
import { t as Route } from "./print._billId-DSVDBiTc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/print._billId-Bml_5Eie.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PrintBillPage() {
	const { billId } = Route.useParams();
	const id = Number(billId);
	const { data: bills, isLoading: isLoadingBill } = useQuery({
		queryKey: ["restaurantBills"],
		queryFn: () => billingService.getBills()
	});
	const { data: settings, isLoading: isLoadingSettings } = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.getGeneralSettings()
	});
	const bill = bills?.find((b) => b.id === id);
	const currencySymbol = settings?.currency?.match(/\((.*?)\)/)?.[1] || settings?.currency || "$";
	(0, import_react.useEffect)(() => {
		if (!isLoadingBill && !isLoadingSettings && bill && settings) setTimeout(() => {
			window.print();
		}, 500);
	}, [
		isLoadingBill,
		isLoadingSettings,
		bill,
		settings
	]);
	if (isLoadingBill || isLoadingSettings) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-8 text-center text-black bg-white min-h-screen",
		children: "Loading receipt..."
	});
	if (!bill) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-8 text-center text-red-500 bg-white min-h-screen",
		children: "Bill not found"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "bg-white text-black min-h-screen p-8 font-sans",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md mx-auto border border-gray-200 p-6 shadow-sm print:shadow-none print:border-none print:p-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center mb-6",
					children: [
						settings?.logoUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: settings.logoUrl.startsWith("http") ? settings.logoUrl : `http://localhost:5157${settings.logoUrl}`,
							alt: "Logo",
							className: "h-16 mx-auto mb-3 object-contain print:grayscale"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-bold uppercase tracking-wider",
							children: settings?.name || "Restaurant"
						}),
						settings?.address && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-gray-600 mt-1 whitespace-pre-wrap leading-tight",
							children: settings.address
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-gray-600 mt-1",
							children: [
								settings?.phone && `Tel: ${settings.phone}`,
								settings?.phone && settings?.email && " | ",
								settings?.email && `${settings.email}`
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-b border-black py-3 mb-4 text-sm flex justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Invoice:" }),
						" ",
						bill.billNumber
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Date:" }),
						" ",
						new Date(bill.createdAt || Date.now()).toLocaleString()
					] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-semibold",
							children: [
								bill.order?.type === "DineIn" && `Table ${bill.order.tableName || "--"}`,
								bill.order?.type === "RoomService" && `Room ${bill.order.roomNumber || "--"}`,
								bill.order?.type === "Parcel" && (bill.order.parcelCode ? `Parcel (Code: ${bill.order.parcelCode})` : "Parcel")
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-gray-600 text-xs mt-1",
							children: bill.status === "Paid" ? "PAID" : "PENDING"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-black text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 w-3/5",
								children: "Item"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-center w-1/5",
								children: "Qty"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right w-1/5",
								children: "Total"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: bill.order?.items.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: `border-b border-gray-100 ${item.status === "Cancelled" ? "text-gray-400 line-through" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2 pr-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium",
									children: item.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-gray-500",
									children: [
										currencySymbol,
										item.priceAtOrder.toFixed(2),
										" each"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-center font-bold",
								children: item.quantity
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2 text-right",
								children: [currencySymbol, (item.priceAtOrder * item.quantity).toFixed(2)]
							})
						]
					}, idx)) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-end text-sm mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-48 space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-gray-600",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, bill.subtotal.toFixed(2)] })]
							}),
							bill.serviceChargePercent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-gray-600",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Service (",
									bill.serviceChargePercent,
									"%):"
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, bill.serviceCharge.toFixed(2)] })]
							}) : null,
							bill.cgstPercent != null && bill.sgstPercent != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-gray-600",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"CGST (",
									bill.cgstPercent,
									"%):"
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, (bill.taxAmount * bill.cgstPercent / (bill.taxPercent || 18)).toFixed(2)] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-gray-600",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"SGST (",
									bill.sgstPercent,
									"%):"
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, (bill.taxAmount * bill.sgstPercent / (bill.taxPercent || 18)).toFixed(2)] })]
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-gray-600",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Tax (",
									bill.taxPercent,
									"%):"
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, bill.taxAmount.toFixed(2)] })]
							}),
							bill.discount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-red-600",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Discount:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"-",
									currencySymbol,
									bill.discount.toFixed(2)
								] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between font-bold text-lg pt-2 border-t-2 border-black mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currencySymbol, bill.totalAmount.toFixed(2)] })]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 pt-4 border-t border-dashed border-gray-400 text-center text-sm text-gray-600 font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Thank you for your visit!" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1",
						children: "Have a wonderful day."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex justify-center gap-4 print:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => window.close(),
						className: "px-6 py-2 bg-gray-200 rounded-lg font-bold",
						children: "Close Window"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => window.print(),
						className: "px-6 py-2 bg-blue-600 text-white rounded-lg font-bold",
						children: "Print Invoice"
					})]
				})
			]
		})
	});
}
//#endregion
export { PrintBillPage as component };
