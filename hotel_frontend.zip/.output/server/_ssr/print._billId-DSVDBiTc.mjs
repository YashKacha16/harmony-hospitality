import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/print._billId-DSVDBiTc.js
var $$splitComponentImporter = () => import("./print._billId-Bml_5Eie.mjs");
var Route = createFileRoute("/print/$billId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
