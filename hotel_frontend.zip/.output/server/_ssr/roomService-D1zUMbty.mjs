import { n as apiClient } from "./settingsService-Dilksh94.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/roomService-D1zUMbty.js
var roomService = {
	getAll: async (params) => {
		let url = "/api/Rooms";
		if (params) {
			const q = new URLSearchParams();
			if (params.categoryId) q.append("categoryId", params.categoryId.toString());
			if (params.status) q.append("status", params.status);
			if (params.floor) q.append("floor", params.floor);
			const qString = q.toString();
			if (qString) url += `?${qString}`;
		}
		return apiClient.get(url);
	},
	getById: async (id) => {
		return apiClient.get(`/api/Rooms/${id}`);
	},
	create: async (data) => {
		return apiClient.post("/api/Rooms", data);
	},
	update: async (id, data) => {
		return apiClient.put(`/api/Rooms/${id}`, data);
	},
	delete: async (id) => {
		return apiClient.delete(`/api/Rooms/${id}`);
	}
};
//#endregion
export { roomService as t };
