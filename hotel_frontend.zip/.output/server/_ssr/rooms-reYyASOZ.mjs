import { r as __toESM } from "../_runtime.mjs";
import { n as apiClient, r as settingsService } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { n as Input, t as Button } from "./button-juXZH0rY.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { D as Pencil, I as LoaderCircle, L as List, T as Plus, c as Trash2, i as Users, o as Upload, ot as Bed, rt as Calendar, t as X, z as LayoutGrid } from "../_libs/lucide-react.mjs";
import { a as StatusBadge, t as AppShell } from "./app-shell-C6Y1qr1C.mjs";
import { t as Card } from "./card-DNWGqbqR.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CUQVyHA-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-DDHupNVK.mjs";
import { a as SheetTitle, i as SheetHeader, n as SheetContent, o as SheetTrigger, r as SheetDescription, t as Sheet } from "./sheet-DgrR67wC.mjs";
import { t as Label } from "./label-Bkz_RwW1.mjs";
import { t as roomService } from "./roomService-D1zUMbty.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, t as Dialog } from "./dialog-BtIFXM_M.mjs";
import { t as Textarea } from "./textarea-CiyhCZVs.mjs";
import { t as Switch } from "./switch-BIIbVvK-.mjs";
import { t as Checkbox } from "./checkbox-Dn_H0WlM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rooms-reYyASOZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var roomCategoryService = {
	getAll: () => apiClient.get("/api/RoomCategories"),
	getById: (id) => apiClient.get(`/api/RoomCategories/${id}`),
	create: (dto) => apiClient.post("/api/RoomCategories", dto),
	update: (id, dto) => apiClient.put(`/api/RoomCategories/${id}`, dto),
	delete: (id) => apiClient.delete(`/api/RoomCategories/${id}`),
	getSeasonalRules: (categoryId) => apiClient.get(`/api/RoomCategories/${categoryId}/seasonal-rules`),
	createSeasonalRule: (categoryId, dto) => apiClient.post(`/api/RoomCategories/${categoryId}/seasonal-rules`, dto),
	updateSeasonalRule: (categoryId, ruleId, dto) => apiClient.put(`/api/RoomCategories/${categoryId}/seasonal-rules/${ruleId}`, dto),
	deleteSeasonalRule: (categoryId, ruleId) => apiClient.delete(`/api/RoomCategories/${categoryId}/seasonal-rules/${ruleId}`)
};
function RoomsPage() {
	const [view, setView] = (0, import_react.useState)("grid");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Rooms",
		breadcrumbs: [{
			label: "Home",
			to: "/dashboard"
		}, { label: "Rooms" }],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			defaultValue: "inventory",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 flex-wrap mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "rounded-xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "inventory",
							className: "rounded-lg",
							children: "Inventory"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "categories",
							className: "rounded-lg",
							children: "Categories & Pricing"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-muted p-1 flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setView("grid"),
								className: `p-1.5 rounded-lg ${view === "grid" ? "bg-background shadow-sm" : ""}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setView("table"),
								className: `p-1.5 rounded-lg ${view === "table" ? "bg-background shadow-sm" : ""}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { className: "size-4" })
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddRoomSheet, {})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "inventory",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InventoryTab, { view })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "categories",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoriesTab, {})
				})
			]
		})
	});
}
function CategoriesTab() {
	const queryClient = useQueryClient();
	const [editCategory, setEditCategory] = (0, import_react.useState)(null);
	const [rulesCategory, setRulesCategory] = (0, import_react.useState)(null);
	const [createOpen, setCreateOpen] = (0, import_react.useState)(false);
	const { data: settings } = useQuery({
		queryKey: ["settings", "general"],
		queryFn: () => settingsService.getGeneralSettings()
	});
	const { data: categories = [], isFetching } = useQuery({
		queryKey: ["roomCategories"],
		queryFn: () => roomCategoryService.getAll()
	});
	const currencySymbol = settings?.currency?.includes("₹") ? "₹" : settings?.currency?.includes("$") ? "$" : settings?.currency || "₹";
	const deleteMutation = useMutation({
		mutationFn: (id) => roomCategoryService.delete(id),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["roomCategories"] });
			toast.success("Category deleted");
		},
		onError: (err) => toast.error(err.message || "Failed to delete")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-end mb-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "rounded-xl bg-primary text-primary-foreground copper-glow",
				onClick: () => setCreateOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1" }), " Add category"]
			})
		}),
		isFetching && categories.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "py-12 text-center text-muted-foreground animate-pulse flex items-center justify-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" }), " Loading categories..."]
		}),
		categories.length === 0 && !isFetching && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "py-12 text-center text-muted-foreground border border-dashed border-border/50 rounded-2xl glass",
			children: "No room categories yet. Click \"Add category\" to create one."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid md:grid-cols-2 gap-4",
			children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5 rounded-2xl hover:border-primary/30 transition-colors",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-serif text-xl",
							children: c.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c.isActive ? "Active" : "Inactive" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: "Base price"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-medium",
							children: [
								currencySymbol,
								c.basePrice,
								"/night"
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: "Seasonal pricing"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-medium flex items-center gap-2",
							children: [c.seasonalPricingEnabled ? "Enabled" : "Disabled", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2 rounded-full ${c.seasonalPricingEnabled ? "bg-success" : "bg-muted-foreground/40"}` })]
						})] })]
					}),
					c.capacity && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 text-xs text-muted-foreground flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3" }),
							" Capacity: ",
							c.capacity,
							" guests"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								className: "rounded-lg",
								onClick: () => setEditCategory(c),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5 mr-1" }), " Edit"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								className: "rounded-lg",
								onClick: () => setRulesCategory(c),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 mr-1" }),
									" Seasonal rules",
									c.seasonalRuleCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-1.5 px-1.5 py-0.5 rounded-full bg-primary/15 text-primary text-[10px] font-bold",
										children: c.seasonalRuleCount
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								className: "rounded-lg text-destructive hover:text-destructive ml-auto",
								onClick: () => {
									if (confirm(`Delete category "${c.name}"?`)) deleteMutation.mutate(c.id);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
							})
						]
					})
				]
			}, c.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditCategoryDialog, {
			category: editCategory,
			onClose: () => setEditCategory(null),
			currencySymbol
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeasonalRulesDialog, {
			category: rulesCategory,
			onClose: () => setRulesCategory(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateCategoryDialog, {
			open: createOpen,
			onClose: () => setCreateOpen(false),
			currencySymbol
		})
	] });
}
function EditCategoryDialog({ category, onClose, currencySymbol }) {
	const queryClient = useQueryClient();
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		basePrice: 0,
		currency: "INR",
		seasonalPricingEnabled: false,
		isActive: true,
		capacity: void 0,
		amenities: ""
	});
	const [lastId, setLastId] = (0, import_react.useState)(null);
	if (category && category.id !== lastId) {
		setLastId(category.id);
		setForm({
			name: category.name,
			basePrice: category.basePrice,
			currency: category.currency,
			seasonalPricingEnabled: category.seasonalPricingEnabled,
			isActive: category.isActive,
			capacity: category.capacity ?? void 0,
			amenities: category.amenities ?? ""
		});
	}
	if (!category && lastId !== null) setLastId(null);
	const updateMutation = useMutation({
		mutationFn: () => roomCategoryService.update(category.id, form),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["roomCategories"] });
			toast.success("Category updated");
			onClose();
		},
		onError: (err) => toast.error(err.message || "Failed to update")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!category,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md rounded-2xl glass",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-serif text-2xl",
				children: "Edit category"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-3",
				onSubmit: (e) => {
					e.preventDefault();
					updateMutation.mutate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Category name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.name,
						onChange: (e) => setForm((f) => ({
							...f,
							name: e.target.value
						})),
						className: "rounded-xl mt-1",
						required: true
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: [
							"Base price (",
							currencySymbol,
							"/night)"
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							step: "0.01",
							value: form.basePrice,
							onChange: (e) => setForm((f) => ({
								...f,
								basePrice: parseFloat(e.target.value) || 0
							})),
							className: "rounded-xl mt-1"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Capacity" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 1,
							value: form.capacity ?? "",
							onChange: (e) => setForm((f) => ({
								...f,
								capacity: parseInt(e.target.value) || void 0
							})),
							className: "rounded-xl mt-1",
							placeholder: "e.g. 2"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Amenities" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2 mt-2",
						children: [
							"WiFi",
							"AC",
							"TV",
							"Balcony",
							"Minibar",
							"Bathtub"
						].map((a) => {
							const currentAmenities = form.amenities.split(",").map((s) => s.trim()).filter(Boolean);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: currentAmenities.includes(a),
									onCheckedChange: (checked) => {
										let newAmenities = [...currentAmenities];
										if (checked) {
											if (!newAmenities.includes(a)) newAmenities.push(a);
										} else newAmenities = newAmenities.filter((item) => item !== a);
										setForm((f) => ({
											...f,
											amenities: newAmenities.join(", ")
										}));
									}
								}), a]
							}, a);
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-sm",
							children: "Seasonal pricing"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: form.seasonalPricingEnabled,
							onCheckedChange: (v) => setForm((f) => ({
								...f,
								seasonalPricingEnabled: v
							}))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-sm",
							children: "Active"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: form.isActive,
							onCheckedChange: (v) => setForm((f) => ({
								...f,
								isActive: v
							}))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: updateMutation.isPending,
						className: "w-full rounded-xl bg-primary text-primary-foreground copper-glow",
						children: updateMutation.isPending ? "Saving..." : "Save changes"
					})
				]
			})]
		})
	});
}
function CreateCategoryDialog({ open, onClose, currencySymbol }) {
	const queryClient = useQueryClient();
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		basePrice: 0,
		currency: "INR",
		seasonalPricingEnabled: false,
		isActive: true,
		capacity: void 0,
		amenities: ""
	});
	const createMutation = useMutation({
		mutationFn: () => roomCategoryService.create(form),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["roomCategories"] });
			toast.success("Category created");
			onClose();
			setForm({
				name: "",
				basePrice: 0,
				currency: "INR",
				seasonalPricingEnabled: false,
				isActive: true,
				capacity: void 0,
				amenities: ""
			});
		},
		onError: (err) => toast.error(err.message || "Failed to create")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md rounded-2xl glass",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-serif text-2xl",
				children: "New room category"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-3",
				onSubmit: (e) => {
					e.preventDefault();
					createMutation.mutate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Category name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.name,
						onChange: (e) => setForm((f) => ({
							...f,
							name: e.target.value
						})),
						className: "rounded-xl mt-1",
						required: true,
						placeholder: "e.g. Deluxe"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: [
							"Base price (",
							currencySymbol,
							"/night)"
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							step: "0.01",
							value: form.basePrice || "",
							onChange: (e) => setForm((f) => ({
								...f,
								basePrice: parseFloat(e.target.value) || 0
							})),
							className: "rounded-xl mt-1"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Capacity" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 1,
							value: form.capacity ?? "",
							onChange: (e) => setForm((f) => ({
								...f,
								capacity: parseInt(e.target.value) || void 0
							})),
							className: "rounded-xl mt-1",
							placeholder: "e.g. 2"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Amenities" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2 mt-2",
						children: [
							"WiFi",
							"AC",
							"TV",
							"Balcony",
							"Minibar",
							"Bathtub"
						].map((a) => {
							const currentAmenities = form.amenities.split(",").map((s) => s.trim()).filter(Boolean);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: currentAmenities.includes(a),
									onCheckedChange: (checked) => {
										let newAmenities = [...currentAmenities];
										if (checked) {
											if (!newAmenities.includes(a)) newAmenities.push(a);
										} else newAmenities = newAmenities.filter((item) => item !== a);
										setForm((f) => ({
											...f,
											amenities: newAmenities.join(", ")
										}));
									}
								}), a]
							}, a);
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-sm",
							children: "Seasonal pricing"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: form.seasonalPricingEnabled,
							onCheckedChange: (v) => setForm((f) => ({
								...f,
								seasonalPricingEnabled: v
							}))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-sm",
							children: "Active"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: form.isActive,
							onCheckedChange: (v) => setForm((f) => ({
								...f,
								isActive: v
							}))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: createMutation.isPending,
						className: "w-full rounded-xl bg-primary text-primary-foreground copper-glow",
						children: createMutation.isPending ? "Creating..." : "Create category"
					})
				]
			})]
		})
	});
}
function SeasonalRulesDialog({ category, onClose }) {
	const queryClient = useQueryClient();
	const [addingRule, setAddingRule] = (0, import_react.useState)(false);
	const [editingRule, setEditingRule] = (0, import_react.useState)(null);
	const { data: rules = [], isFetching } = useQuery({
		queryKey: ["seasonalRules", category?.id],
		queryFn: () => roomCategoryService.getSeasonalRules(category.id),
		enabled: !!category
	});
	const deleteMutation = useMutation({
		mutationFn: (ruleId) => roomCategoryService.deleteSeasonalRule(category.id, ruleId),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["seasonalRules", category?.id] });
			queryClient.invalidateQueries({ queryKey: ["roomCategories"] });
			toast.success("Rule deleted");
		},
		onError: (err) => toast.error(err.message || "Failed to delete rule")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!category,
		onOpenChange: (o) => {
			if (!o) {
				onClose();
				setAddingRule(false);
				setEditingRule(null);
			}
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg rounded-2xl glass max-h-[85vh] overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
					className: "font-serif text-2xl",
					children: ["Seasonal rules — ", category?.name]
				}) }),
				isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-8 text-center text-muted-foreground animate-pulse flex items-center justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), " Loading rules..."]
				}) : rules.length === 0 && !addingRule ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-8 text-center text-muted-foreground border border-dashed rounded-xl",
					children: "No seasonal rules defined yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: rules.map((rule) => editingRule?.id === rule.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleForm, {
						categoryId: category.id,
						rule,
						onDone: () => setEditingRule(null)
					}, rule.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3 border rounded-xl flex items-start justify-between gap-3 hover:bg-muted/20 transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-medium text-sm",
										children: rule.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2 rounded-full ${rule.isActive ? "bg-success" : "bg-muted-foreground/40"}` })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: rule.isRecurring ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Every ", rule.daysOfWeek] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										rule.startDate ? new Date(rule.startDate).toLocaleDateString() : "—",
										" → ",
										rule.endDate ? new Date(rule.endDate).toLocaleDateString() : "—"
									] })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `text-sm font-bold mt-1 ${rule.priceModifierPercent >= 0 ? "text-destructive" : "text-success"}`,
									children: [
										rule.priceModifierPercent >= 0 ? "+" : "",
										rule.priceModifierPercent,
										"%"
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1 shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								className: "h-7 w-7 p-0 rounded-lg",
								onClick: () => setEditingRule(rule),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								className: "h-7 w-7 p-0 rounded-lg text-destructive hover:text-destructive",
								onClick: () => deleteMutation.mutate(rule.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
							})]
						})]
					}, rule.id))
				}),
				addingRule ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleForm, {
					categoryId: category.id,
					onDone: () => setAddingRule(false)
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					className: "w-full rounded-xl mt-2",
					onClick: () => setAddingRule(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1" }), " Add rule"]
				})
			]
		})
	});
}
function RuleForm({ categoryId, rule, onDone }) {
	const queryClient = useQueryClient();
	const isEditing = !!rule;
	const [form, setForm] = (0, import_react.useState)({
		name: rule?.name ?? "",
		startDate: rule?.startDate ? rule.startDate.split("T")[0] : "",
		endDate: rule?.endDate ? rule.endDate.split("T")[0] : "",
		isRecurring: rule?.isRecurring ?? false,
		daysOfWeek: rule?.daysOfWeek ?? "",
		priceModifierPercent: rule?.priceModifierPercent ?? 0,
		isActive: rule?.isActive ?? true
	});
	const saveMutation = useMutation({
		mutationFn: () => {
			const dto = {
				...form,
				startDate: form.startDate || void 0,
				endDate: form.endDate || void 0,
				daysOfWeek: form.daysOfWeek || void 0
			};
			return isEditing ? roomCategoryService.updateSeasonalRule(categoryId, rule.id, dto) : roomCategoryService.createSeasonalRule(categoryId, dto);
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["seasonalRules", categoryId] });
			queryClient.invalidateQueries({ queryKey: ["roomCategories"] });
			toast.success(isEditing ? "Rule updated" : "Rule created");
			onDone();
		},
		onError: (err) => toast.error(err.message || "Failed to save rule")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-3 border border-primary/30 rounded-xl bg-muted/10 space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs font-bold uppercase tracking-wider text-primary",
					children: isEditing ? "Edit rule" : "New rule"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					className: "h-6 w-6 p-0 rounded",
					onClick: onDone,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				placeholder: "Rule name (e.g. Winter Peak)",
				value: form.name,
				onChange: (e) => setForm((f) => ({
					...f,
					name: e.target.value
				})),
				className: "rounded-lg h-8 text-sm",
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs whitespace-nowrap",
					children: "Recurring?"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: form.isRecurring,
					onCheckedChange: (v) => setForm((f) => ({
						...f,
						isRecurring: v
					}))
				})]
			}),
			form.isRecurring ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				placeholder: "Days (e.g. Saturday,Sunday)",
				value: form.daysOfWeek,
				onChange: (e) => setForm((f) => ({
					...f,
					daysOfWeek: e.target.value
				})),
				className: "rounded-lg h-8 text-sm"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					value: form.startDate,
					onChange: (e) => setForm((f) => ({
						...f,
						startDate: e.target.value
					})),
					className: "rounded-lg h-8 text-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					value: form.endDate,
					onChange: (e) => setForm((f) => ({
						...f,
						endDate: e.target.value
					})),
					className: "rounded-lg h-8 text-sm"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Price modifier %"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						value: form.priceModifierPercent,
						onChange: (e) => setForm((f) => ({
							...f,
							priceModifierPercent: parseFloat(e.target.value) || 0
						})),
						className: "rounded-lg h-8 text-sm mt-0.5",
						placeholder: "+30 or -10"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Active"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: form.isActive,
						onCheckedChange: (v) => setForm((f) => ({
							...f,
							isActive: v
						}))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				className: "w-full rounded-lg bg-primary text-primary-foreground",
				disabled: saveMutation.isPending || !form.name,
				onClick: () => saveMutation.mutate(),
				children: saveMutation.isPending ? "Saving..." : isEditing ? "Update rule" : "Add rule"
			})
		]
	});
}
function AddRoomSheet() {
	const queryClient = useQueryClient();
	const [open, setOpen] = (0, import_react.useState)(false);
	const { data: categories = [], isFetching } = useQuery({
		queryKey: ["roomCategories"],
		queryFn: () => roomCategoryService.getAll()
	});
	const [number, setNumber] = (0, import_react.useState)("");
	const [floor, setFloor] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("Available");
	const [selectedCategoryName, setSelectedCategoryName] = (0, import_react.useState)("");
	const selectedCategory = categories.find((c) => c.name === selectedCategoryName);
	const maxCapacity = selectedCategory?.capacity;
	const [selectedAmenities, setSelectedAmenities] = (0, import_react.useState)([
		"WiFi",
		"AC",
		"TV",
		"Balcony",
		"Minibar",
		"Bathtub"
	]);
	const [capacity, setCapacity] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("");
	const [imageFile, setImageFile] = (0, import_react.useState)(null);
	const [imageBase64, setImageBase64] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!open) {
			setNumber("");
			setFloor("");
			setDescription("");
			setStatus("Available");
			setSelectedCategoryName("");
			setSelectedAmenities([
				"WiFi",
				"AC",
				"TV",
				"Balcony",
				"Minibar",
				"Bathtub"
			]);
			setCapacity("");
			setPrice("");
			setImageFile(null);
			setImageBase64(null);
		}
	}, [open]);
	(0, import_react.useEffect)(() => {
		if (selectedCategory) {
			setSelectedAmenities((selectedCategory.amenities || "").split(",").map((s) => s.trim()).filter(Boolean));
			if (selectedCategory.capacity) setCapacity(selectedCategory.capacity.toString());
			if (selectedCategory.basePrice !== void 0) setPrice(selectedCategory.basePrice.toString());
		}
	}, [selectedCategory]);
	const createMutation = useMutation({
		mutationFn: () => roomService.create({
			number,
			categoryId: selectedCategory?.id || 0,
			floor,
			capacity: parseInt(capacity) || 2,
			basePrice: parseFloat(price) || 0,
			status,
			amenities: selectedAmenities,
			images: imageBase64 ? [imageBase64] : [],
			description
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["rooms"] });
			toast.success("Room created");
			setOpen(false);
			setNumber("");
			setFloor("");
			setDescription("");
		},
		onError: (err) => toast.error(err.message || "Failed to create")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "rounded-xl bg-primary text-primary-foreground copper-glow",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1" }), " Add room"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "w-full sm:max-w-lg overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
				className: "font-serif text-2xl",
				children: "New room"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, { children: "Add a room to the inventory." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-4 mt-6 px-4",
				onSubmit: (e) => {
					e.preventDefault();
					if (!selectedCategory) return toast.error("Please select a category");
					createMutation.mutate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Room number" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							value: number,
							onChange: (e) => setNumber(e.target.value),
							placeholder: "308",
							className: "rounded-xl mt-1"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Floor" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: floor,
							onChange: (e) => setFloor(e.target.value),
							placeholder: "3",
							className: "rounded-xl mt-1"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							disabled: isFetching,
							value: selectedCategoryName,
							onValueChange: setSelectedCategoryName,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "rounded-xl mt-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: isFetching ? "Loading..." : "Select" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: c.name,
								children: c.name
							}, c.id)) })]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Capacity" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: capacity,
							onChange: (e) => setCapacity(e.target.value),
							min: 1,
							max: maxCapacity || void 0,
							placeholder: maxCapacity ? `Max ${maxCapacity}` : "2",
							className: "rounded-xl mt-1"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Price / night" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						value: price,
						onChange: (e) => setPrice(e.target.value),
						placeholder: "220",
						className: "rounded-xl mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Amenities" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2 mt-2",
						children: [
							"WiFi",
							"AC",
							"TV",
							"Balcony",
							"Minibar",
							"Bathtub"
						].map((a) => {
							const categoryAmenities = selectedCategory ? (selectedCategory.amenities || "").split(",").map((s) => s.trim()).filter(Boolean) : null;
							const isAvailable = categoryAmenities === null || categoryAmenities.includes(a);
							const isChecked = selectedAmenities.includes(a);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: `flex items-center gap-2 text-sm ${!isAvailable ? "opacity-50" : ""}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: isChecked && isAvailable,
									disabled: !isAvailable,
									onCheckedChange: (checked) => {
										if (checked) setSelectedAmenities((prev) => [...prev, a]);
										else setSelectedAmenities((prev) => prev.filter((item) => item !== a));
									}
								}), a]
							}, a);
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Image" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-1 h-24 rounded-xl border-2 border-dashed border-border flex items-center justify-center text-xs text-muted-foreground gap-2 cursor-pointer hover:bg-muted/20 transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							className: "hidden",
							onClick: (e) => {
								e.target.value = "";
							},
							onChange: (e) => {
								if (e.target.files && e.target.files.length > 0) {
									const file = e.target.files[0];
									setImageFile(file);
									const reader = new FileReader();
									reader.onloadend = () => setImageBase64(reader.result);
									reader.readAsDataURL(file);
								}
							}
						}), imageFile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative w-full h-full rounded-xl overflow-hidden group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: URL.createObjectURL(imageFile),
								alt: "preview",
								className: "w-full h-full object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-0 bg-black/50 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-white font-medium truncate max-w-[200px]",
									children: imageFile.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-white/70 text-[10px]",
									children: "Click to change"
								})]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), " Click or drop image here"] })]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: description,
						onChange: (e) => setDescription(e.target.value),
						placeholder: "Notes about the room…",
						className: "rounded-xl mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: createMutation.isPending,
						className: "w-full rounded-xl bg-primary text-primary-foreground copper-glow",
						children: createMutation.isPending ? "Creating..." : "Create room"
					})
				]
			})]
		})]
	});
}
function InventoryTab({ view }) {
	const queryClient = useQueryClient();
	const { data: settings } = useQuery({
		queryKey: ["settings", "general"],
		queryFn: () => settingsService.getGeneralSettings()
	});
	const currencySymbol = settings?.currency?.includes("₹") ? "₹" : settings?.currency?.includes("$") ? "$" : settings?.currency || "₹";
	const [categoryFilter, setCategoryFilter] = (0, import_react.useState)("all");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("all");
	const [search, setSearch] = (0, import_react.useState)("");
	const { data: categories = [] } = useQuery({
		queryKey: ["roomCategories"],
		queryFn: () => roomCategoryService.getAll()
	});
	const { data: rooms = [], isFetching } = useQuery({
		queryKey: [
			"rooms",
			categoryFilter,
			statusFilter
		],
		queryFn: () => roomService.getAll({
			categoryId: categoryFilter !== "all" ? categoryFilter : void 0,
			status: statusFilter !== "all" ? statusFilter : void 0
		})
	});
	const filteredRooms = rooms.filter((r) => r.number.toLowerCase().includes(search.toLowerCase()));
	const deleteMutation = useMutation({
		mutationFn: (id) => roomService.delete(id),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["rooms"] });
			toast.success("Room deleted");
		},
		onError: (err) => toast.error(err.message || "Failed to delete")
	});
	const [editRoom, setEditRoom] = (0, import_react.useState)(null);
	const getStatusColor = (s) => {
		switch (s.toLowerCase()) {
			case "available": return "bg-success text-success-foreground border-success/30";
			case "occupied": return "bg-destructive/10 text-destructive border-destructive/30";
			case "maintenance": return "bg-warning/20 text-warning border-warning/30";
			default: return "bg-muted text-muted-foreground border-border";
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col sm:flex-row gap-3 mb-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Search room number...",
					value: search,
					onChange: (e) => setSearch(e.target.value),
					className: "w-full sm:w-64 rounded-xl"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: categoryFilter.toString(),
					onValueChange: (v) => setCategoryFilter(v === "all" ? "all" : parseInt(v)),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "w-full sm:w-48 rounded-xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Category" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "all",
						children: "All categories"
					}), categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: c.id.toString(),
						children: c.name
					}, c.id))] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: statusFilter,
					onValueChange: setStatusFilter,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "w-full sm:w-48 rounded-xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Status" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: "All statuses"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Available",
							children: "Available"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Occupied",
							children: "Occupied"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Maintenance",
							children: "Maintenance"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Out of service",
							children: "Out of service"
						})
					] })]
				})
			]
		}),
		isFetching && rooms.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "py-12 text-center text-muted-foreground animate-pulse",
			children: "Loading rooms..."
		}),
		!isFetching && filteredRooms.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "py-16 text-center border border-dashed border-border/50 rounded-2xl glass",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bed, { className: "size-10 mx-auto text-muted-foreground/40 mb-3" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-serif text-xl text-muted-foreground",
					children: "No rooms found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground/70 mt-1",
					children: "Try adjusting your filters or adding a new room."
				})
			]
		}),
		filteredRooms.length > 0 && view === "grid" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4",
			children: filteredRooms.map((r) => {
				console.log("Room", r.number, "images:", r.images ? r.images.length : 0, r.images && r.images.length > 0 ? r.images[0].substring(0, 50) : "none");
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4 rounded-2xl hover:border-primary/30 transition-colors flex flex-col overflow-hidden",
					children: [
						r.images && r.images.length > 0 && r.images[0].startsWith("data:") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-32 -mx-4 -mt-4 mb-3 bg-muted flex items-center justify-center overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: r.images[0],
								alt: r.number,
								className: "w-full h-full object-cover"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between items-start mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-serif text-2xl font-bold",
								children: r.number
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground bg-muted inline-flex px-2 py-0.5 rounded-full mt-1",
								children: r.category?.name || "Unknown"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${getStatusColor(r.status)}`,
								children: r.status
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm mt-2 flex-grow",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between py-1 border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Price"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										currencySymbol,
										r.basePrice,
										"/night"
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between py-1 border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Capacity"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3 inline mr-1" }), r.capacity] })]
								}),
								r.floor && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between py-1 border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Floor"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r.floor })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								className: "flex-1 rounded-lg",
								onClick: () => setEditRoom(r),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5 mr-1" }), " Edit"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								className: "rounded-lg text-destructive hover:text-destructive",
								onClick: () => {
									if (confirm(`Delete room ${r.number}?`)) deleteMutation.mutate(r.id);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
							})]
						})
					]
				}, r.id);
			})
		}),
		filteredRooms.length > 0 && view === "table" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-2xl border border-border/50 overflow-hidden bg-card/30",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "bg-muted/50 text-muted-foreground text-xs uppercase",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Room"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Category"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Price"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Capacity"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right font-medium",
							children: "Actions"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
					className: "divide-y divide-border/50",
					children: filteredRooms.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "hover:bg-muted/30 transition-colors",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 font-medium",
								children: r.number
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-muted-foreground",
								children: r.category?.name || "Unknown"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${getStatusColor(r.status)}`,
									children: r.status
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [currencySymbol, r.basePrice]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: r.capacity
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									variant: "ghost",
									className: "size-8 rounded-lg",
									onClick: () => setEditRoom(r),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									variant: "ghost",
									className: "size-8 rounded-lg text-destructive hover:text-destructive ml-1",
									onClick: () => {
										if (confirm(`Delete room ${r.number}?`)) deleteMutation.mutate(r.id);
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
								})]
							})
						]
					}, r.id))
				})]
			})
		}),
		editRoom && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditRoomSheet, {
			room: editRoom,
			onClose: () => setEditRoom(null)
		})
	] });
}
function EditRoomSheet({ room, onClose }) {
	const queryClient = useQueryClient();
	const { data: categories = [] } = useQuery({
		queryKey: ["roomCategories"],
		queryFn: () => roomCategoryService.getAll()
	});
	const [number, setNumber] = (0, import_react.useState)(room.number);
	const [floor, setFloor] = (0, import_react.useState)(room.floor || "");
	const [description, setDescription] = (0, import_react.useState)(room.description || "");
	const [status, setStatus] = (0, import_react.useState)(room.status);
	const [capacity, setCapacity] = (0, import_react.useState)(room.capacity.toString());
	const [price, setPrice] = (0, import_react.useState)(room.basePrice.toString());
	const [selectedCategoryName, setSelectedCategoryName] = (0, import_react.useState)(room.category?.name || "");
	const selectedCategory = categories.find((c) => c.name === selectedCategoryName);
	const maxCapacity = selectedCategory?.capacity;
	const [selectedAmenities, setSelectedAmenities] = (0, import_react.useState)(room.amenities || []);
	const [imageFile, setImageFile] = (0, import_react.useState)(null);
	const [imageBase64, setImageBase64] = (0, import_react.useState)(null);
	const updateMutation = useMutation({
		mutationFn: () => roomService.update(room.id, {
			number,
			categoryId: selectedCategory?.id || room.categoryId,
			floor,
			capacity: parseInt(capacity) || 2,
			basePrice: parseFloat(price) || 0,
			status,
			amenities: selectedAmenities,
			images: imageBase64 ? [imageBase64] : room.images,
			description
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["rooms"] });
			toast.success("Room updated");
			onClose();
		},
		onError: (err) => toast.error(err.message || "Failed to update")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "w-full sm:max-w-lg overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
				className: "font-serif text-2xl",
				children: ["Edit room ", room.number]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-4 mt-6 px-4",
				onSubmit: (e) => {
					e.preventDefault();
					if (!selectedCategory && !room.categoryId) return toast.error("Please select a category");
					updateMutation.mutate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Room number" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							value: number,
							onChange: (e) => setNumber(e.target.value),
							className: "rounded-xl mt-1"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Floor" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: floor,
							onChange: (e) => setFloor(e.target.value),
							className: "rounded-xl mt-1"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: selectedCategoryName,
							onValueChange: setSelectedCategoryName,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "rounded-xl mt-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: c.name,
								children: c.name
							}, c.id)) })]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Capacity" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: capacity,
							onChange: (e) => setCapacity(e.target.value),
							min: 1,
							max: maxCapacity || void 0,
							className: "rounded-xl mt-1"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Price / night" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: price,
							onChange: (e) => setPrice(e.target.value),
							className: "rounded-xl mt-1"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Status" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: status,
							onValueChange: setStatus,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "rounded-xl mt-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Status" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "Available",
									children: "Available"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "Occupied",
									children: "Occupied"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "Maintenance",
									children: "Maintenance"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "Out of service",
									children: "Out of service"
								})
							] })]
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Amenities" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2 mt-2",
						children: [
							"WiFi",
							"AC",
							"TV",
							"Balcony",
							"Minibar",
							"Bathtub"
						].map((a) => {
							const categoryAmenities = (selectedCategory ? selectedCategory.amenities || "" : room.category?.amenities || "").split(",").map((s) => s.trim()).filter(Boolean);
							const isAvailable = categoryAmenities.length === 0 || categoryAmenities.includes(a);
							const isChecked = selectedAmenities.includes(a);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: `flex items-center gap-2 text-sm ${!isAvailable ? "opacity-50" : ""}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: isChecked && isAvailable,
									disabled: !isAvailable,
									onCheckedChange: (checked) => {
										if (checked) setSelectedAmenities((prev) => [...prev, a]);
										else setSelectedAmenities((prev) => prev.filter((item) => item !== a));
									}
								}), a]
							}, a);
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Image" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-1 h-24 rounded-xl border-2 border-dashed border-border flex items-center justify-center text-xs text-muted-foreground gap-2 cursor-pointer hover:bg-muted/20 transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							className: "hidden",
							onClick: (e) => {
								e.target.value = "";
							},
							onChange: (e) => {
								if (e.target.files && e.target.files.length > 0) {
									const file = e.target.files[0];
									setImageFile(file);
									const reader = new FileReader();
									reader.onloadend = () => setImageBase64(reader.result);
									reader.readAsDataURL(file);
								}
							}
						}), imageFile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative w-full h-full rounded-xl overflow-hidden group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: URL.createObjectURL(imageFile),
								alt: "preview",
								className: "w-full h-full object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-0 bg-black/50 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-white font-medium truncate max-w-[200px]",
									children: imageFile.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-white/70 text-[10px]",
									children: "Click to change"
								})]
							})]
						}) : room.images && room.images.length > 0 && room.images[0].startsWith("data:") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative w-full h-full rounded-xl overflow-hidden group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: room.images[0],
								alt: "preview",
								className: "w-full h-full object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0 bg-black/50 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-white/70 text-[10px]",
									children: "Click to change"
								})
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), " Click or drop image here"] })]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: description,
						onChange: (e) => setDescription(e.target.value),
						className: "rounded-xl mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: updateMutation.isPending,
						className: "w-full rounded-xl bg-primary text-primary-foreground copper-glow",
						children: updateMutation.isPending ? "Saving..." : "Save changes"
					})
				]
			})]
		})
	});
}
//#endregion
export { RoomsPage as component };
