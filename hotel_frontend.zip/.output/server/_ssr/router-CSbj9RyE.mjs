import { r as __toESM } from "../_runtime.mjs";
import { r as settingsService } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { t as ThemeProvider } from "./theme-G0Ttq5RK.mjs";
import { c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { n as useQuery, r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as Route$12 } from "./order._token-DzNTblqg.mjs";
import { t as Route$13 } from "./orders-CXuSkCTI.mjs";
import { t as Route$14 } from "./print-booking._bookingId-BppNEzIj.mjs";
import { t as Route$15 } from "./print._billId-DSVDBiTc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CSbj9RyE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-CFHGwT_D.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	window.__lovableReportRuntimeError?.({
		message,
		stack: error instanceof Error ? error.stack : void 0,
		filename: window.location.pathname
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-serif font-semibold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$11 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Hotel & Restaurant Management" },
			{
				name: "description",
				content: "A premium hotel and restaurant management platform: bookings, housekeeping, restaurant floor, orders, billing and revenue in one place."
			},
			{
				name: "author",
				content: "Hotel"
			},
			{
				property: "og:title",
				content: "Hotel & Restaurant Management"
			},
			{
				property: "og:description",
				content: "Boutique-grade operations for modern hospitality: bookings, housekeeping, restaurant, and revenue."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1 1\"></svg>",
				type: "image/svg+xml"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function TitleManager() {
	const { data: settings } = useQuery({
		queryKey: ["settings", "general"],
		queryFn: () => settingsService.getGeneralSettings(),
		staleTime: 1e3 * 60 * 5
	});
	(0, import_react.useEffect)(() => {
		if (!settings?.name) return;
		const realName = settings.name;
		const updateTitle = () => {
			if (/Aurelia Hospitality OS/gi.test(document.title)) document.title = document.title.replace(/Aurelia Hospitality OS/gi, realName);
			else if (/Aurelia/gi.test(document.title)) document.title = document.title.replace(/Aurelia/gi, realName);
			else if (!document.title.toLowerCase().includes(realName.toLowerCase())) document.title = `${document.title.split("—")[0].trim()} — ${realName}`;
		};
		updateTitle();
		const titleEl = document.querySelector("title");
		if (!titleEl) return;
		const observer = new MutationObserver(() => {
			updateTitle();
		});
		observer.observe(titleEl, {
			childList: true,
			characterData: true,
			subtree: true
		});
		return () => observer.disconnect();
	}, [settings?.name]);
	return null;
}
function RootComponent() {
	const { queryClient } = Route$11.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ThemeProvider, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleManager, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
				richColors: true,
				position: "top-right"
			})
		] })
	});
}
var $$splitComponentImporter$10 = () => import("./routes-6sql5d94.mjs");
var Route$10 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Sign in — Aurelia Hospitality OS" },
		{
			name: "description",
			content: "Sign in to Aurelia, the boutique hotel and restaurant operations platform."
		},
		{
			property: "og:title",
			content: "Sign in — Aurelia"
		},
		{
			property: "og:description",
			content: "The operations platform for modern hospitality brands."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./billing-SaZ2OgAe.mjs");
var Route$9 = createFileRoute("/billing")({
	head: () => ({ meta: [{ title: "Billing — Aurelia" }, {
		name: "description",
		content: "Room and restaurant invoices with tax breakdown, split bills and payment tracking."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./bookings-B5jOfznn.mjs");
var Route$8 = createFileRoute("/bookings")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./clients-BfU1uz-2.mjs");
var Route$7 = createFileRoute("/clients")({
	head: () => ({ meta: [{ title: "Clients — Aurelia" }, {
		name: "description",
		content: "Client directory, contact info, total revenue contribution and booking history."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./dashboard-oj2k3fiV.mjs");
var Route$6 = createFileRoute("/dashboard")({
	head: () => ({ meta: [{ title: "Dashboard — Aurelia" }, {
		name: "description",
		content: "Property command center: occupancy, revenue, orders and alerts at a glance."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./employees-5iu4YDb_.mjs");
var Route$5 = createFileRoute("/employees")({
	head: () => ({ meta: [{ title: "Employees — Aurelia" }, {
		name: "description",
		content: "Team directory, roles, shifts and attendance for hotel & restaurant staff."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./menu-CgkjXIkK.mjs");
var Route$4 = createFileRoute("/menu")({
	head: () => ({ meta: [{ title: "Menu — Aurelia" }, {
		name: "description",
		content: "Curate the culinary offering: categories, seasonal items, images and availability."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./rooms-reYyASOZ.mjs");
var Route$3 = createFileRoute("/rooms")({
	head: () => ({ meta: [{ title: "Rooms — Aurelia" }, {
		name: "description",
		content: "Inventory, live status and categories for every room in the property."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./settings-c3WDZ6Z8.mjs");
var Route$2 = createFileRoute("/settings")({
	head: () => ({ meta: [{ title: "Settings — Aurelia" }, {
		name: "description",
		content: "Property configuration: branding, taxes, cancellation tiers, notifications and theme."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./tables-CH98uD5B.mjs");
var Route$1 = createFileRoute("/tables")({
	head: () => ({ meta: [{ title: "Tables — Aurelia" }, {
		name: "description",
		content: "Interactive restaurant floor plan with merge, split and zone management."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./waitlist-DjUA58Pb.mjs");
var Route = createFileRoute("/waitlist")({
	head: () => ({ meta: [{ title: "Waiting list — Aurelia" }, {
		name: "description",
		content: "Live queue for the restaurant with token numbers, wait times and instant notify."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$10.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$11
	}),
	BillingRoute: Route$9.update({
		id: "/billing",
		path: "/billing",
		getParentRoute: () => Route$11
	}),
	BookingsRoute: Route$8.update({
		id: "/bookings",
		path: "/bookings",
		getParentRoute: () => Route$11
	}),
	ClientsRoute: Route$7.update({
		id: "/clients",
		path: "/clients",
		getParentRoute: () => Route$11
	}),
	DashboardRoute: Route$6.update({
		id: "/dashboard",
		path: "/dashboard",
		getParentRoute: () => Route$11
	}),
	EmployeesRoute: Route$5.update({
		id: "/employees",
		path: "/employees",
		getParentRoute: () => Route$11
	}),
	MenuRoute: Route$4.update({
		id: "/menu",
		path: "/menu",
		getParentRoute: () => Route$11
	}),
	OrdersRoute: Route$13.update({
		id: "/orders",
		path: "/orders",
		getParentRoute: () => Route$11
	}),
	RoomsRoute: Route$3.update({
		id: "/rooms",
		path: "/rooms",
		getParentRoute: () => Route$11
	}),
	SettingsRoute: Route$2.update({
		id: "/settings",
		path: "/settings",
		getParentRoute: () => Route$11
	}),
	TablesRoute: Route$1.update({
		id: "/tables",
		path: "/tables",
		getParentRoute: () => Route$11
	}),
	WaitlistRoute: Route.update({
		id: "/waitlist",
		path: "/waitlist",
		getParentRoute: () => Route$11
	}),
	OrderTokenRoute: Route$12.update({
		id: "/order/$token",
		path: "/order/$token",
		getParentRoute: () => Route$11
	}),
	PrintBookingBookingIdRoute: Route$14.update({
		id: "/print-booking/$bookingId",
		path: "/print-booking/$bookingId",
		getParentRoute: () => Route$11
	}),
	PrintBillIdRoute: Route$15.update({
		id: "/print/$billId",
		path: "/print/$billId",
		getParentRoute: () => Route$11
	})
};
var routeTree = Route$11._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
