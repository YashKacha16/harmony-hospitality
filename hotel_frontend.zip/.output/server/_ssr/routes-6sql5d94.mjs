import { r as __toESM } from "../_runtime.mjs";
import { r as settingsService, t as BASE_URL } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { n as useTheme } from "./theme-G0Ttq5RK.mjs";
import { n as Input, t as Button } from "./button-juXZH0rY.mjs";
import { t as authService } from "./authService-CTf_Ta8y.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { A as Moon, lt as ArrowRight, u as Sun } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Label } from "./label-Bkz_RwW1.mjs";
import { t as Checkbox } from "./checkbox-Dn_H0WlM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-6sql5d94.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const nav = useNavigate();
	const { theme, toggle } = useTheme();
	const [email, setEmail] = (0, import_react.useState)("");
	const [pw, setPw] = (0, import_react.useState)("");
	const [rememberMe, setRememberMe] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const savedEmail = localStorage.getItem("rememberedEmail");
		const savedPw = localStorage.getItem("rememberedPw");
		if (savedEmail && savedPw) {
			setEmail(savedEmail);
			setPw(savedPw);
			setRememberMe(true);
		}
	}, []);
	const { data: settings } = useQuery({
		queryKey: ["settings", "general"],
		queryFn: () => settingsService.getGeneralSettings()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen grid lg:grid-cols-2 bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative hidden lg:flex flex-col justify-between p-12 overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1400&q=80",
					alt: "The Aurelia Grand, Lisbon",
					className: "absolute inset-0 w-full h-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-br from-[oklch(0.18_0.03_265)]/85 via-[oklch(0.18_0.03_265)]/60 to-[oklch(0.3_0.1_55)]/40" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-700",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-11 rounded-2xl bg-primary flex items-center justify-center copper-glow overflow-hidden",
						children: settings?.logoUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: settings.logoUrl.startsWith("http") ? settings.logoUrl : `${BASE_URL}${settings.logoUrl}`,
							alt: "Logo",
							className: "w-full h-full object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-serif text-primary-foreground text-xl",
							children: settings?.name?.[0]?.toUpperCase() || "A"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-serif text-white text-2xl leading-none",
						children: settings?.name || "Hotel"
					}) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 text-white max-w-lg animate-in fade-in slide-in-from-bottom-6 duration-1000",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-serif text-5xl leading-[1.05] text-white",
						children: ["Welcome to ", settings?.name || "Hotel"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-white/70 text-lg",
						children: "Please sign in to access your dashboard."
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col p-6 lg:p-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end lg:hidden mb-6 items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-9 rounded-xl bg-primary flex items-center justify-center overflow-hidden",
							children: settings?.logoUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: settings.logoUrl.startsWith("http") ? settings.logoUrl : `${BASE_URL}${settings.logoUrl}`,
								alt: "Logo",
								className: "w-full h-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-serif text-primary-foreground",
								children: settings?.name?.[0]?.toUpperCase() || "A"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-serif text-xl",
							children: settings?.name || "Aurelia"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: toggle,
						className: "size-10 rounded-xl bg-muted flex items-center justify-center",
						children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden lg:flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: toggle,
						className: "size-10 rounded-xl bg-muted hover:bg-accent flex items-center justify-center transition",
						children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 flex items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full max-w-md mx-auto animate-in fade-in slide-in-from-right-6 duration-700",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-[0.24em] text-primary mb-3",
								children: "Welcome back"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-serif text-4xl mb-2",
								children: ["Sign in to ", settings?.name || "Hotel"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground mb-8",
								children: "Enter your credentials to continue."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: async (e) => {
									e.preventDefault();
									setLoading(true);
									try {
										if (rememberMe) {
											localStorage.setItem("rememberedEmail", email);
											localStorage.setItem("rememberedPw", pw);
										} else {
											localStorage.removeItem("rememberedEmail");
											localStorage.removeItem("rememberedPw");
										}
										const res = await authService.login({
											email,
											password: pw
										});
										localStorage.setItem("user", JSON.stringify(res.employee));
										toast.success("Welcome back, " + res.employee.name);
										nav({ to: "/dashboard" });
									} catch (err) {
										toast.error(err.message || "Invalid credentials");
									} finally {
										setLoading(false);
									}
								},
								className: "space-y-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "email",
											children: "Email"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "email",
											type: "email",
											value: email,
											onChange: (e) => setEmail(e.target.value),
											className: "h-12 rounded-xl",
											required: true
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between items-center",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												htmlFor: "pw",
												children: "Password"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: "#",
												className: "text-xs text-primary hover:underline",
												children: "Forgot password?"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "pw",
											type: "password",
											value: pw,
											onChange: (e) => setPw(e.target.value),
											className: "h-12 rounded-xl",
											required: true
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center space-x-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
											id: "remember",
											checked: rememberMe,
											onCheckedChange: (checked) => setRememberMe(checked)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											htmlFor: "remember",
											className: "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-muted-foreground",
											children: "Remember me"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "submit",
										disabled: loading,
										className: "w-full h-12 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 group copper-glow",
										children: [loading ? "Signing in..." : "Enter workspace", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 ml-1 transition-transform group-hover:translate-x-0.5" })]
									})
								]
							})
						]
					})
				})
			]
		})]
	});
}
//#endregion
export { LoginPage as component };
