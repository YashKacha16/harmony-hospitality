import { r as __toESM } from "../_runtime.mjs";
import { n as apiClient, r as settingsService, t as BASE_URL } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { n as useTheme } from "./theme-G0Ttq5RK.mjs";
import { n as Input, t as Button } from "./button-juXZH0rY.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { F as Lock, T as Plus, c as Trash2, h as Shield, o as Upload } from "../_libs/lucide-react.mjs";
import { o as permissionService, t as AppShell } from "./app-shell-C6Y1qr1C.mjs";
import { t as Card } from "./card-DNWGqbqR.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CUQVyHA-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-DDHupNVK.mjs";
import { t as Label } from "./label-Bkz_RwW1.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogFooter, t as Dialog } from "./dialog-BtIFXM_M.mjs";
import { t as Textarea } from "./textarea-CiyhCZVs.mjs";
import { t as Switch } from "./switch-BIIbVvK-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-c3WDZ6Z8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var chefService = {
	getChefs: async () => {
		return apiClient.get("/api/Chefs");
	},
	getChef: async (id) => {
		return apiClient.get(`/api/Chefs/${id}`);
	},
	createChef: async (data) => {
		return apiClient.post("/api/Chefs", data);
	},
	updateChef: async (id, data) => {
		return apiClient.put(`/api/Chefs/${id}`, data);
	},
	deleteChef: async (id) => {
		return apiClient.delete(`/api/Chefs/${id}`);
	},
	uploadImage: async (file) => {
		const formData = new FormData();
		formData.append("file", file);
		const res = await fetch("http://localhost:5157/api/Chefs/upload-image", {
			method: "POST",
			body: formData
		});
		if (!res.ok) throw new Error("Upload failed");
		return res.json();
	}
};
function SettingsPage() {
	const { theme, setTheme } = useTheme();
	const queryClient = useQueryClient();
	const fileInputRef = (0, import_react.useRef)(null);
	const welcomeImageRef = (0, import_react.useRef)(null);
	const chefImageRef = (0, import_react.useRef)(null);
	const { data: settings, isLoading } = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.getGeneralSettings(),
		staleTime: 1e3 * 60 * 5
	});
	const [form, setForm] = (0, import_react.useState)({});
	const { data: roles = [], refetch: refetchRoles } = useQuery({
		queryKey: ["roles"],
		queryFn: () => permissionService.getRoles()
	});
	const [selectedRole, setSelectedRole] = (0, import_react.useState)("Admin");
	const [editingPermissions, setEditingPermissions] = (0, import_react.useState)(null);
	const [isAddRoleOpen, setIsAddRoleOpen] = (0, import_react.useState)(false);
	const [newRoleName, setNewRoleName] = (0, import_react.useState)("");
	const { data: chefs = [], refetch: refetchChefs } = useQuery({
		queryKey: ["chefs"],
		queryFn: () => chefService.getChefs()
	});
	const [isChefModalOpen, setIsChefModalOpen] = (0, import_react.useState)(false);
	const [selectedChef, setSelectedChef] = (0, import_react.useState)(null);
	const [chefFormName, setChefFormName] = (0, import_react.useState)("");
	const [chefFormRole, setChefFormRole] = (0, import_react.useState)("");
	const [chefFormDescription, setChefFormDescription] = (0, import_react.useState)("");
	const [chefFormImageUrl, setChefFormImageUrl] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const roleConfig = roles.find((r) => r.name.toLowerCase() === selectedRole.toLowerCase());
		if (roleConfig) setEditingPermissions(JSON.parse(JSON.stringify(roleConfig.permissions)));
	}, [selectedRole, roles]);
	if (settings && !form.name && !form.currency) setForm({ ...settings });
	const updateMutation = useMutation({
		mutationFn: (data) => settingsService.updateGeneralSettings(data),
		onSuccess: (updatedSettings) => {
			queryClient.setQueryData(["settings"], updatedSettings);
			toast.success("Settings saved successfully");
		},
		onError: () => {
			toast.error("Failed to save settings");
		}
	});
	const uploadLogoMutation = useMutation({
		mutationFn: (file) => settingsService.uploadLogo(file),
		onSuccess: (data) => {
			setForm((prev) => ({
				...prev,
				logoUrl: data.logoUrl
			}));
			queryClient.invalidateQueries({ queryKey: ["settings"] });
			toast.success("Logo uploaded successfully");
		},
		onError: () => {
			toast.error("Failed to upload logo");
		}
	});
	const uploadWelcomeImageMutation = useMutation({
		mutationFn: (file) => settingsService.uploadWelcomeImage(file),
		onSuccess: (data) => {
			setForm((prev) => ({
				...prev,
				welcomeImageUrl: data.welcomeImageUrl
			}));
			queryClient.invalidateQueries({ queryKey: ["settings"] });
			toast.success("Welcome image uploaded successfully");
		},
		onError: () => {
			toast.error("Failed to upload welcome image");
		}
	});
	const createChefMutation = useMutation({
		mutationFn: (data) => chefService.createChef(data),
		onSuccess: () => {
			refetchChefs();
			setIsChefModalOpen(false);
			toast.success("Chef added successfully");
		},
		onError: () => toast.error("Failed to add chef")
	});
	const updateChefMutation = useMutation({
		mutationFn: ({ id, data }) => chefService.updateChef(id, data),
		onSuccess: () => {
			refetchChefs();
			setIsChefModalOpen(false);
			toast.success("Chef updated successfully");
		},
		onError: () => toast.error("Failed to update chef")
	});
	const deleteChefMutation = useMutation({
		mutationFn: (id) => chefService.deleteChef(id),
		onSuccess: () => {
			refetchChefs();
			toast.success("Chef deleted successfully");
		},
		onError: () => toast.error("Failed to delete chef")
	});
	const chefPhotoUploadMutation = useMutation({
		mutationFn: (file) => chefService.uploadImage(file),
		onSuccess: (data) => {
			setChefFormImageUrl(data.imageUrl);
			toast.success("Chef photo uploaded successfully");
		},
		onError: () => {
			toast.error("Failed to upload chef photo");
		}
	});
	const handleSave = () => {
		if (!form.name || !form.address || !form.email || !form.phone) {
			toast.error("Please fill in all required fields (Name, Address, Email, Phone)");
			return;
		}
		updateMutation.mutate(form);
	};
	const handleFileChange = (e) => {
		if (e.target.files && e.target.files[0]) uploadLogoMutation.mutate(e.target.files[0]);
	};
	const handleWelcomeFileChange = (e) => {
		if (e.target.files && e.target.files[0]) uploadWelcomeImageMutation.mutate(e.target.files[0]);
	};
	const handleChefFileChange = (e) => {
		if (e.target.files && e.target.files[0]) chefPhotoUploadMutation.mutate(e.target.files[0]);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Settings",
		breadcrumbs: [{
			label: "Home",
			to: "/dashboard"
		}, { label: "Settings" }],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "general",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "rounded-xl mb-4 flex-wrap h-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "general",
								className: "rounded-lg",
								children: "General"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "policy",
								className: "rounded-lg",
								children: "Cancellation policy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "roles",
								className: "rounded-lg",
								children: "Roles & permissions"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "general",
						className: "grid md:grid-cols-2 gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-6 rounded-2xl space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-serif text-lg",
								children: "Property"
							}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "animate-pulse space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 bg-muted rounded-xl" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-20 bg-muted rounded-xl" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-20 bg-muted rounded-xl" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 bg-muted rounded-xl" })
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Hotel / restaurant name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.name || "",
									onChange: (e) => setForm((f) => ({
										...f,
										name: e.target.value
									})),
									className: "rounded-xl mt-1"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Logo" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-1 h-24 rounded-xl border-2 border-dashed flex flex-col items-center justify-center text-xs gap-2 text-muted-foreground cursor-pointer hover:bg-muted/50 overflow-hidden relative",
										onClick: () => fileInputRef.current?.click(),
										children: form.logoUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: `${BASE_URL}${form.logoUrl}`,
											alt: "Logo",
											className: "h-full object-contain"
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), uploadLogoMutation.isPending ? "Uploading..." : "Upload Logo"] })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										ref: fileInputRef,
										className: "hidden",
										accept: "image/*",
										onChange: handleFileChange
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Welcome Section Background Image" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-1 h-24 rounded-xl border-2 border-dashed flex flex-col items-center justify-center text-xs gap-2 text-muted-foreground cursor-pointer hover:bg-muted/50 overflow-hidden relative",
										onClick: () => welcomeImageRef.current?.click(),
										children: form.welcomeImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: `${BASE_URL}${form.welcomeImageUrl}`,
											alt: "Welcome Image",
											className: "h-full object-cover w-full"
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), uploadWelcomeImageMutation.isPending ? "Uploading..." : "Upload Welcome Image"] })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										ref: welcomeImageRef,
										className: "hidden",
										accept: "image/*",
										onChange: handleWelcomeFileChange
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Address" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									value: form.address || "",
									onChange: (e) => setForm((f) => ({
										...f,
										address: e.target.value
									})),
									className: "rounded-xl mt-1"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "About us description (Multiline support)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									value: form.aboutText || "",
									onChange: (e) => setForm((f) => ({
										...f,
										aboutText: e.target.value
									})),
									className: "rounded-xl mt-1 min-h-[120px]",
									placeholder: "Enter details of your hotel, history, and experience..."
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Phone" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: form.phone || "",
										onChange: (e) => setForm((f) => ({
											...f,
											phone: e.target.value
										})),
										className: "rounded-xl mt-1"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: form.email || "",
										onChange: (e) => setForm((f) => ({
											...f,
											email: e.target.value
										})),
										className: "rounded-xl mt-1"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "border-t border-border pt-6 mt-4 space-y-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-serif text-lg text-gold",
											children: "Chef Team Directory"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: "Manage the chefs shown on the About page of your hotel."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											onClick: () => {
												setSelectedChef(null);
												setChefFormName("");
												setChefFormRole("");
												setChefFormDescription("");
												setChefFormImageUrl("");
												setIsChefModalOpen(true);
											},
											size: "sm",
											className: "rounded-xl flex items-center gap-1 bg-gold text-gold-foreground hover:bg-gold/90",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add Chef"]
										})]
									}), chefs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "border border-dashed rounded-xl p-8 text-center text-sm text-muted-foreground",
										children: "No chefs added yet. Click \"Add Chef\" to build your culinary team."
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 md:grid-cols-2 gap-4",
										children: chefs.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-3 p-3 border rounded-xl items-start relative bg-card text-card-foreground",
											children: [
												c.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: `${BASE_URL}${c.imageUrl}`,
													alt: c.name,
													className: "size-16 rounded-lg object-cover"
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "size-16 rounded-lg bg-muted flex items-center justify-center text-xs text-muted-foreground",
													children: "No Photo"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex-1 min-w-0",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "font-medium truncate text-sm",
															children: c.name
														}),
														c.role && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "text-xs text-gold font-medium truncate",
															children: c.role
														}),
														c.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-xs text-muted-foreground line-clamp-2 mt-1",
															children: c.description
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex gap-1 shrink-0 ml-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														type: "button",
														onClick: () => {
															setSelectedChef(c);
															setChefFormName(c.name);
															setChefFormRole(c.role || "");
															setChefFormDescription(c.description || "");
															setChefFormImageUrl(c.imageUrl || "");
															setIsChefModalOpen(true);
														},
														variant: "ghost",
														size: "sm",
														className: "h-7 text-xs px-2 text-muted-foreground hover:text-foreground",
														children: "Edit"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														type: "button",
														onClick: () => {
															if (confirm(`Are you sure you want to delete Chef ${c.name}?`)) deleteChefMutation.mutate(c.id);
														},
														variant: "ghost",
														size: "icon",
														className: "size-7 rounded-lg text-destructive hover:text-destructive/90",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
													})]
												})
											]
										}, c.id))
									})]
								})
							] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-6 rounded-2xl space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-serif text-lg",
								children: "Tax & currency"
							}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "animate-pulse space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 bg-muted rounded-xl" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 bg-muted rounded-xl" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 bg-muted rounded-xl" })
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Currency" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: form.currency || "INR (₹)",
										onValueChange: (val) => setForm((prev) => ({
											...prev,
											currency: val
										})),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "rounded-xl mt-1",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select Currency" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "INR (₹)",
												children: "INR (₹)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "USD ($)",
												children: "USD ($)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "EUR (€)",
												children: "EUR (€)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "GBP (£)",
												children: "GBP (£)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "AED (د.إ)",
												children: "AED (د.إ)"
											})
										] })]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Service charge %" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: form.serviceChargePercent ?? 10,
										onChange: (e) => setForm((prev) => ({
											...prev,
											serviceChargePercent: parseFloat(e.target.value) || 0
										})),
										className: "rounded-xl mt-1"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "CGST %" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: form.cgstPercent ?? 9,
										onChange: (e) => setForm((prev) => ({
											...prev,
											cgstPercent: parseFloat(e.target.value) || 0
										})),
										className: "rounded-xl mt-1"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "SGST %" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: form.sgstPercent ?? 9,
										onChange: (e) => setForm((prev) => ({
											...prev,
											sgstPercent: parseFloat(e.target.value) || 0
										})),
										className: "rounded-xl mt-1"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3 mt-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Estimated wait time (minutes)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											value: form.waitlistEstimatedWaitMinutes ?? 22,
											onChange: (e) => setForm((prev) => ({
												...prev,
												waitlistEstimatedWaitMinutes: parseInt(e.target.value) || 0
											})),
											className: "rounded-xl mt-1"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Minimum advance booking (%)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: 0,
											max: 100,
											value: form.minimumAdvancePercent ?? 0,
											onChange: (e) => setForm((prev) => ({
												...prev,
												minimumAdvancePercent: parseFloat(e.target.value) || 0
											})),
											className: "rounded-xl mt-1"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "col-span-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Waitlist descriptive message" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
												value: form.waitlistMessage ?? "Based on average turnover of 48m over the last hour and 3 free tables.",
												onChange: (e) => setForm((prev) => ({
													...prev,
													waitlistMessage: e.target.value
												})),
												className: "rounded-xl mt-1"
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									disabled: updateMutation.isPending,
									className: "rounded-xl bg-primary text-primary-foreground mt-4",
									onClick: handleSave,
									children: updateMutation.isPending ? "Saving..." : "Save Changes"
								})
							] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "policy",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-6 rounded-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-serif text-lg mb-2",
									children: "Cancellation tiers"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground mb-4",
									children: "These rules appear in the Bookings cancellation flow."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid md:grid-cols-3 gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
											className: "p-4 rounded-xl border-success/40 bg-success/5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs text-muted-foreground",
												children: "7+ days before check-in"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: 0,
													max: 100,
													value: form.cancellation7DaysRefundPercent ?? 100,
													onChange: (e) => setForm({
														...form,
														cancellation7DaysRefundPercent: parseFloat(e.target.value) || 0
													}),
													className: "w-24 rounded-lg"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-sm text-muted-foreground",
													children: "% refunded"
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
											className: "p-4 rounded-xl border-warning/40 bg-warning/5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs text-muted-foreground",
												children: "3–6 days before"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: 0,
													max: 100,
													value: form.cancellation3To6DaysRefundPercent ?? 50,
													onChange: (e) => setForm({
														...form,
														cancellation3To6DaysRefundPercent: parseFloat(e.target.value) || 0
													}),
													className: "w-24 rounded-lg"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-sm text-muted-foreground",
													children: "% refunded"
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
											className: "p-4 rounded-xl border-destructive/40 bg-destructive/5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs text-muted-foreground",
												children: "Within 48 hrs"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: 0,
													max: 100,
													value: form.cancellationWithin48HoursRefundPercent ?? 0,
													onChange: (e) => setForm({
														...form,
														cancellationWithin48HoursRefundPercent: parseFloat(e.target.value) || 0
													}),
													className: "w-24 rounded-lg"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-sm text-muted-foreground",
													children: "% refunded"
												})]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-6",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										disabled: updateMutation.isPending,
										className: "rounded-xl bg-primary text-primary-foreground",
										onClick: handleSave,
										children: updateMutation.isPending ? "Saving..." : "Save policy"
									})
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "roles",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid md:grid-cols-[250px_1fr] gap-6 items-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "p-4 rounded-2xl border border-border/40 bg-sidebar/20 space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-serif font-bold text-foreground",
										children: "Roles"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										className: "size-8 p-0 rounded-lg",
										onClick: () => setIsAddRoleOpen(true),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-1",
									children: roles.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium cursor-pointer transition-all ${selectedRole.toLowerCase() === r.name.toLowerCase() ? "bg-primary text-primary-foreground shadow-sm" : "hover:bg-muted text-muted-foreground hover:text-foreground"}`,
										onClick: () => setSelectedRole(r.name),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r.name })]
											}),
											!r.isSystem && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												className: `size-6 rounded-md flex items-center justify-center transition-colors ${selectedRole.toLowerCase() === r.name.toLowerCase() ? "hover:bg-primary-foreground/15 text-primary-foreground" : "hover:bg-destructive/10 text-muted-foreground hover:text-destructive"}`,
												onClick: (e) => {
													e.stopPropagation();
													if (confirm(`Are you sure you want to delete the role "${r.name}"?`)) permissionService.deleteRole(r.name).then(() => {
														refetchRoles();
														if (selectedRole === r.name) setSelectedRole("Admin");
														toast.success(`Role "${r.name}" deleted successfully.`);
													}).catch(() => {
														toast.error(`Failed to delete role "${r.name}".`);
													});
												},
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
											}),
											r.isSystem && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5 opacity-40" })
										]
									}, r.name))
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "p-6 rounded-2xl border border-border/40 bg-sidebar/20 space-y-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "font-serif text-xl font-bold flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-5 text-primary" }),
										"Permissions for ",
										selectedRole
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1",
									children: "Configure module access and dynamic actions for this user role."
								})] }), editingPermissions && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-4",
									children: [Object.entries({
										dashboard: { label: "Dashboard" },
										rooms: {
											label: "Rooms",
											sub: [
												{
													key: "add",
													label: "Add Room"
												},
												{
													key: "edit",
													label: "Edit Room Status/Details"
												},
												{
													key: "delete",
													label: "Delete Room"
												}
											]
										},
										bookings: {
											label: "Bookings",
											sub: [
												{
													key: "add",
													label: "Create Booking"
												},
												{
													key: "edit",
													label: "Modify booking"
												},
												{
													key: "delete",
													label: "Cancel booking"
												}
											]
										},
										tables: {
											label: "Restaurant Tables",
											sub: [
												{
													key: "add",
													label: "Add Table / Manage Zones"
												},
												{
													key: "edit",
													label: "Merge / Edit Table Status"
												},
												{
													key: "delete",
													label: "Delete Table"
												}
											]
										},
										waitlist: {
											label: "Waiting List",
											sub: [
												{
													key: "add",
													label: "Add to Waitlist"
												},
												{
													key: "edit",
													label: "Update Status"
												},
												{
													key: "delete",
													label: "Remove from Waitlist"
												}
											]
										},
										orders: {
											label: "Restaurant Orders",
											sub: [
												{
													key: "add",
													label: "Create Order"
												},
												{
													key: "edit",
													label: "Modify Order / Status"
												},
												{
													key: "delete",
													label: "Cancel Order"
												},
												{
													key: "waiterSide",
													label: "Access Waiter Side (POS Menu)"
												},
												{
													key: "kitchenSide",
													label: "Access Kitchen Side (KDS Board)"
												}
											]
										},
										menu: {
											label: "Restaurant Menu",
											sub: [
												{
													key: "add",
													label: "Add Menu Item"
												},
												{
													key: "edit",
													label: "Edit Item Details / Price"
												},
												{
													key: "delete",
													label: "Remove Menu Item"
												}
											]
										},
										billing: {
											label: "Billing & Invoicing",
											sub: [
												{
													key: "add",
													label: "Generate Bills"
												},
												{
													key: "edit",
													label: "Apply Discount / Modify Payment"
												},
												{
													key: "delete",
													label: "Void Bill"
												}
											]
										},
										employees: {
											label: "Employees (Directory)",
											sub: [
												{
													key: "add",
													label: "Add Employee"
												},
												{
													key: "edit",
													label: "Edit Role / Profile"
												},
												{
													key: "delete",
													label: "Terminate Employee"
												}
											]
										},
										settings: {
											label: "System Settings",
											sub: [{
												key: "edit",
												label: "Configure Brand, Taxes & Tiers"
											}]
										}
									}).map(([moduleKey, config]) => {
										const modulePerm = editingPermissions[moduleKey] || { access: false };
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "border border-border/40 rounded-xl p-4 bg-background/40 space-y-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-semibold text-sm",
													children: config.label
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs text-muted-foreground",
														children: modulePerm.access ? "Enabled" : "Disabled"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
														checked: modulePerm.access,
														onCheckedChange: (checked) => {
															setEditingPermissions((prev) => {
																if (!prev) return null;
																const updated = { ...prev };
																updated[moduleKey] = {
																	...updated[moduleKey],
																	access: checked
																};
																return updated;
															});
														}
													})]
												})]
											}), modulePerm.access && config.sub && config.sub.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "pt-3 border-t border-dashed border-border/60 grid grid-cols-1 sm:grid-cols-2 gap-3 animate-in slide-in-from-top-2 duration-200",
												children: config.sub.map((subItem) => {
													return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														className: "flex items-center gap-2.5 text-xs text-muted-foreground hover:text-foreground cursor-pointer select-none",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															type: "checkbox",
															checked: !!modulePerm[subItem.key],
															onChange: (e) => {
																const isChecked = e.target.checked;
																setEditingPermissions((prev) => {
																	if (!prev) return null;
																	const updated = { ...prev };
																	updated[moduleKey] = {
																		...updated[moduleKey],
																		[subItem.key]: isChecked
																	};
																	return updated;
																});
															},
															className: "rounded border-border text-primary focus:ring-primary size-4"
														}), subItem.label]
													}, subItem.key);
												})
											})]
										}, moduleKey);
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "pt-4 border-t border-border/60 flex justify-end",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											className: "rounded-xl bg-primary text-primary-foreground font-semibold px-6",
											onClick: () => {
												if (!editingPermissions) return;
												permissionService.saveRolePermissions(selectedRole, editingPermissions).then(() => {
													refetchRoles();
													toast.success(`Permissions for "${selectedRole}" saved successfully!`);
												}).catch(() => {
													toast.error(`Failed to save permissions for "${selectedRole}".`);
												});
											},
											children: "Save Permissions"
										})
									})]
								})]
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isAddRoleOpen,
				onOpenChange: setIsAddRoleOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md rounded-2xl p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "font-serif text-2xl",
							children: "Create New Role"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-4 my-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "roleName",
									children: "Role Name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "roleName",
									placeholder: "e.g. Receptionist, Cashier",
									value: newRoleName,
									onChange: (e) => setNewRoleName(e.target.value),
									className: "rounded-xl"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "rounded-xl",
							onClick: () => setIsAddRoleOpen(false),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "rounded-xl bg-primary text-primary-foreground",
							onClick: () => {
								const name = newRoleName.trim();
								if (!name) return toast.error("Role name cannot be empty.");
								if (roles.some((r) => r.name.toLowerCase() === name.toLowerCase())) return toast.error("A role with this name already exists.");
								const adminPerms = roles.find((r) => r.name === "Admin")?.permissions || roles[0]?.permissions;
								permissionService.saveRolePermissions(name, adminPerms).then(() => {
									refetchRoles();
									setSelectedRole(name);
									setIsAddRoleOpen(false);
									setNewRoleName("");
									toast.success(`Role "${name}" created successfully!`);
								}).catch(() => {
									toast.error(`Failed to create role "${name}".`);
								});
							},
							children: "Create Role"
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isChefModalOpen,
				onOpenChange: setIsChefModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md rounded-2xl p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "font-serif text-2xl",
							children: selectedChef ? "Edit Chef Profile" : "Add Chef"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4 my-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "chefName",
										children: "Chef Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "chefName",
										placeholder: "e.g. Aditi Rao",
										value: chefFormName,
										onChange: (e) => setChefFormName(e.target.value),
										className: "rounded-xl"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "chefPhoto",
											children: "Chef Photo"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-1 h-28 rounded-xl border-2 border-dashed flex flex-col items-center justify-center text-xs gap-1 text-muted-foreground cursor-pointer hover:bg-muted/50 overflow-hidden relative",
											onClick: () => chefImageRef.current?.click(),
											children: chefFormImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: `${BASE_URL}${chefFormImageUrl}`,
												alt: "Chef Photo",
												className: "h-full object-cover w-full"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), chefPhotoUploadMutation.isPending ? "Uploading..." : "Upload Chef Photo"] })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "file",
											ref: chefImageRef,
											className: "hidden",
											accept: "image/*",
											onChange: handleChefFileChange
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "chefDescription",
										children: "Bio / Description"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "chefDescription",
										placeholder: "Chef details...",
										value: chefFormDescription,
										onChange: (e) => setChefFormDescription(e.target.value),
										className: "rounded-xl min-h-[100px]"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "rounded-xl",
							onClick: () => setIsChefModalOpen(false),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "rounded-xl bg-gold text-gold-foreground hover:bg-gold/90",
							onClick: () => {
								if (!chefFormName.trim()) return toast.error("Chef name cannot be empty.");
								const data = {
									name: chefFormName,
									role: chefFormRole || null,
									description: chefFormDescription || null,
									imageUrl: chefFormImageUrl || null
								};
								if (selectedChef) updateChefMutation.mutate({
									id: selectedChef.id,
									data: {
										...selectedChef,
										...data
									}
								});
								else createChefMutation.mutate(data);
							},
							disabled: createChefMutation.isPending || updateChefMutation.isPending,
							children: selectedChef ? "Update Profile" : "Add Chef"
						})] })
					]
				})
			})
		]
	});
}
//#endregion
export { SettingsPage as component };
