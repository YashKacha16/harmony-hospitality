//#region node_modules/.nitro/vite/services/ssr/assets/settingsService-Dilksh94.js
var BASE_URL = "http://localhost:5157";
var apiClient = {
	async request(endpoint, options = {}) {
		const url = `${BASE_URL}${endpoint}`;
		const headers = {};
		if (!(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
		if (options.headers) Object.entries(options.headers).forEach(([key, value]) => {
			if (value !== void 0) headers[key] = value;
		});
		const response = await fetch(url, {
			...options,
			headers
		});
		if (!response.ok) {
			let errorMessage = `HTTP error! status: ${response.status}`;
			try {
				errorMessage = (await response.json()).message || errorMessage;
			} catch (e) {}
			throw new Error(errorMessage);
		}
		if (response.status === 204) return null;
		return await response.json();
	},
	get(endpoint, options) {
		return this.request(endpoint, {
			...options,
			method: "GET"
		});
	},
	post(endpoint, body, options) {
		return this.request(endpoint, {
			...options,
			method: "POST",
			body: body instanceof FormData ? body : JSON.stringify(body)
		});
	},
	put(endpoint, body, options) {
		return this.request(endpoint, {
			...options,
			method: "PUT",
			body: body instanceof FormData ? body : JSON.stringify(body)
		});
	},
	delete(endpoint, options) {
		return this.request(endpoint, {
			...options,
			method: "DELETE"
		});
	}
};
var settingsService = {
	getGeneralSettings: async () => {
		return await apiClient.get("/api/Settings/general");
	},
	updateGeneralSettings: async (data) => {
		return await apiClient.put("/api/Settings/general", data);
	},
	uploadLogo: async (file) => {
		const formData = new FormData();
		formData.append("logo", file);
		const res = await fetch("http://localhost:5157/api/Settings/logo", {
			method: "POST",
			body: formData
		});
		if (!res.ok) throw new Error("Upload failed");
		return res.json();
	},
	uploadWelcomeImage: async (file) => {
		const formData = new FormData();
		formData.append("file", file);
		const res = await fetch("http://localhost:5157/api/Settings/welcome-image", {
			method: "POST",
			body: formData
		});
		if (!res.ok) throw new Error("Upload failed");
		return res.json();
	},
	uploadChefImage: async (file) => {
		const formData = new FormData();
		formData.append("file", file);
		const res = await fetch("http://localhost:5157/api/Settings/chef-image", {
			method: "POST",
			body: formData
		});
		if (!res.ok) throw new Error("Upload failed");
		return res.json();
	}
};
//#endregion
export { apiClient as n, settingsService as r, BASE_URL as t };
