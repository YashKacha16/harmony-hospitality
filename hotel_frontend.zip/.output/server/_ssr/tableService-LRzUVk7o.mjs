import { n as apiClient } from "./settingsService-Dilksh94.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tableService-LRzUVk7o.js
var tableService = {
	getAll: () => apiClient.get("/api/tables"),
	getGrouped: () => apiClient.get("/api/tables/grouped"),
	getById: (id) => apiClient.get(`/api/tables/${id}`),
	create: (table) => apiClient.post("/api/tables", table),
	update: (id, table) => apiClient.put(`/api/tables/${id}`, table),
	delete: (id) => apiClient.delete(`/api/tables/${id}`),
	merge: (tableIds) => apiClient.post("/api/tables/merge", { tableIds }),
	unmerge: (mergeGroupId) => apiClient.post(`/api/tables/${mergeGroupId}/unmerge`, {}),
	bulkStatus: (tableIds, status) => apiClient.request("/api/tables/bulk-status", {
		method: "PATCH",
		body: JSON.stringify({
			tableIds,
			status
		})
	}),
	bulkCategory: (tableIds, categoryId) => apiClient.request("/api/tables/bulk-category", {
		method: "PATCH",
		body: JSON.stringify({
			tableIds,
			categoryId
		})
	}),
	bulkDelete: (tableIds) => apiClient.request("/api/tables/bulk", {
		method: "DELETE",
		body: JSON.stringify({ tableIds })
	}),
	regenerateQr: (id) => apiClient.post(`/api/tables/${id}/regenerate-qr`, {}),
	getTableCategories: () => apiClient.get("/api/table-category"),
	createTableCategory: (category) => apiClient.post("/api/table-category", category),
	deleteTableCategory: (id) => apiClient.delete(`/api/table-category/${id}`),
	resolveByQrToken: (qrToken) => apiClient.get(`/api/tables/resolve/${qrToken}`),
	getAvailable: (partySize, seating) => {
		let url = `/api/tables/available?partySize=${partySize}`;
		if (seating) url += `&seating=${encodeURIComponent(seating)}`;
		return apiClient.get(url);
	},
	assignTable: (id, data) => apiClient.post(`/api/tables/${id}/assign`, data)
};
//#endregion
export { tableService as t };
