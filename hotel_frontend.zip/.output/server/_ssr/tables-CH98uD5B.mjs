import { r as __toESM } from "../_runtime.mjs";
import { t as BASE_URL } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { n as Input, r as cn, t as Button } from "./button-juXZH0rY.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { C as QrCode, G as Combine, T as Plus, U as Download, c as Trash2, et as ChevronDown, f as Split, k as MousePointerClick, s as TriangleAlert, t as X, w as Printer, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { o as permissionService, t as AppShell } from "./app-shell-C6Y1qr1C.mjs";
import { t as Card } from "./card-DNWGqbqR.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as TabsTrigger, r as TabsList, t as Tabs } from "./tabs-DDHupNVK.mjs";
import { a as SheetTitle, i as SheetHeader, n as SheetContent, t as Sheet } from "./sheet-DgrR67wC.mjs";
import { t as Label } from "./label-Bkz_RwW1.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, t as Dialog } from "./dialog-BtIFXM_M.mjs";
import { t as tableService } from "./tableService-LRzUVk7o.mjs";
import { t as orderService } from "./orderService-CwnQmAjk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tables-CH98uD5B.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TableQrModal({ tableId, tableName, qrToken, open, onClose }) {
	const queryClient = useQueryClient();
	const [cacheBuster, setCacheBuster] = (0, import_react.useState)(Date.now());
	const [showConfirmRegen, setShowConfirmRegen] = (0, import_react.useState)(false);
	const regenerateMutation = useMutation({
		mutationFn: () => tableService.regenerateQr(tableId),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["groupedTables"] });
			setCacheBuster(Date.now());
			toast.success("QR code regenerated successfully.");
			setShowConfirmRegen(false);
		},
		onError: (err) => {
			toast.error(err.message || "Failed to regenerate QR code.");
		}
	});
	const handleDownload = async () => {
		try {
			const blob = await (await fetch(`${BASE_URL}/api/tables/${tableId}/qr-image?t=${cacheBuster}`)).blob();
			const url = window.URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = `Table-${tableName}-QR.png`;
			document.body.appendChild(a);
			a.click();
			a.remove();
			window.URL.revokeObjectURL(url);
		} catch (err) {
			toast.error("Failed to download QR code.");
		}
	};
	const handlePrint = () => {
		const printWindow = window.open("", "_blank");
		if (printWindow) {
			printWindow.document.write(`
        <html>
          <head>
            <title>Print QR Code - Table ${tableName}</title>
            <style>
              body { display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
              img { max-width: 100%; max-height: 100%; }
            </style>
          </head>
          <body>
            <img src="${BASE_URL}/api/tables/${tableId}/qr-image?t=${cacheBuster}" onload="window.print(); window.close();" />
          </body>
        </html>
      `);
			printWindow.document.close();
		}
	};
	const qrImageUrl = `${BASE_URL}/api/tables/${tableId}/qr-image?t=${cacheBuster}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (isOpen) => !isOpen && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md rounded-2xl p-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
				className: "font-serif text-2xl text-center",
				children: [
					"Table ",
					tableName,
					" QR Code"
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center space-y-6 mt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-4 rounded-2xl border border-muted shadow-sm flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: qrImageUrl,
							alt: `QR Code for Table ${tableName}`,
							className: "size-48 object-contain"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full text-center text-xs text-muted-foreground break-all px-4",
						children: ["Token: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "bg-muted px-1.5 py-0.5 rounded font-mono",
							children: qrToken
						})]
					}),
					showConfirmRegen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full bg-destructive/10 border border-destructive/20 rounded-xl p-4 space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-destructive font-medium text-center",
							children: "Old QR code will stop working. Continue?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 justify-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								className: "rounded-lg text-xs",
								onClick: () => setShowConfirmRegen(false),
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "destructive",
								className: "rounded-lg text-xs",
								onClick: () => regenerateMutation.mutate(),
								disabled: regenerateMutation.isPending,
								children: regenerateMutation.isPending ? "Regenerating..." : "Confirm"
							})]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								className: "rounded-xl flex flex-col items-center justify-center h-16 text-xs gap-1 border-muted hover:bg-muted",
								onClick: handleDownload,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Download"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								className: "rounded-xl flex flex-col items-center justify-center h-16 text-xs gap-1 border-muted hover:bg-muted",
								onClick: handlePrint,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "Print"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								className: "rounded-xl flex flex-col items-center justify-center h-16 text-xs gap-1 border-muted text-destructive hover:bg-destructive/5 hover:border-destructive/20",
								onClick: () => setShowConfirmRegen(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" }), "Regenerate"]
							})
						]
					})
				]
			})]
		})
	});
}
var statusColor = {
	Free: "bg-success/20 border-success text-success",
	Occupied: "bg-destructive/20 border-destructive text-destructive",
	Reserved: "bg-warning/20 border-warning [color:var(--warning)]",
	Cleaning: "bg-muted border-muted-foreground/30 text-muted-foreground",
	Merged: "bg-special/20 border-special [color:var(--special)]"
};
var statusLegendColors = {
	Free: "bg-success border-success",
	Occupied: "bg-destructive border-destructive",
	Reserved: "bg-warning border-warning",
	Cleaning: "bg-muted-foreground/60 border-muted-foreground/60",
	Merged: "bg-special border-special"
};
function TablesPage() {
	const queryClient = useQueryClient();
	const navigate = useNavigate();
	const userRaw = typeof window !== "undefined" ? localStorage.getItem("user") : null;
	const user = userRaw ? JSON.parse(userRaw) : { role: "Admin" };
	const canAdd = permissionService.hasPermission(user.role, "tables", "add");
	const canDelete = permissionService.hasPermission(user.role, "tables", "delete");
	const canEdit = permissionService.hasPermission(user.role, "tables", "edit");
	const [zone, setZone] = (0, import_react.useState)("All");
	const [selectMode, setSelectMode] = (0, import_react.useState)(false);
	const [selectedIds, setSelectedIds] = (0, import_react.useState)([]);
	const [sideTableId, setSideTableId] = (0, import_react.useState)(null);
	const [qrModalTable, setQrModalTable] = (0, import_react.useState)(null);
	const [isAddOpen, setIsAddOpen] = (0, import_react.useState)(false);
	const [createError, setCreateError] = (0, import_react.useState)(null);
	const [newTable, setNewTable] = (0, import_react.useState)({
		name: "",
		capacity: 4,
		categoryId: null
	});
	const [isManageZonesOpen, setIsManageZonesOpen] = (0, import_react.useState)(false);
	const [newZoneName, setNewZoneName] = (0, import_react.useState)("");
	const [showStatusDropdown, setShowStatusDropdown] = (0, import_react.useState)(false);
	const [showCategoryDropdown, setShowCategoryDropdown] = (0, import_react.useState)(false);
	const [showDeleteConfirm, setShowDeleteConfirm] = (0, import_react.useState)(false);
	const { data: groupedTables = [], isLoading } = useQuery({
		queryKey: ["groupedTables"],
		queryFn: tableService.getGrouped
	});
	const { data: tableCategories = [] } = useQuery({
		queryKey: ["tableCategories"],
		queryFn: tableService.getTableCategories
	});
	const { data: kanbanOrders } = useQuery({
		queryKey: ["kanbanOrders", "DineIn"],
		queryFn: () => orderService.getKanban("DineIn")
	});
	const allTables = groupedTables.flatMap((g) => g.tables);
	zone === "All" || groupedTables.find((g) => g.categoryName === zone)?.tables;
	const mergeMutation = useMutation({
		mutationFn: (ids) => tableService.merge(ids),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["groupedTables"] });
			toast.success(`Tables merged successfully`);
			setSelectedIds([]);
			setSelectMode(false);
		},
		onError: (err) => {
			toast.error(err.message || "Failed to merge tables");
		}
	});
	const unmergeMutation = useMutation({
		mutationFn: (mergeGroupId) => tableService.unmerge(mergeGroupId),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["groupedTables"] });
			toast.success("Tables successfully split/unmerged");
			setSideTableId(null);
		},
		onError: (err) => {
			toast.error(err.message || "Failed to unmerge tables");
		}
	});
	const bulkStatusMutation = useMutation({
		mutationFn: ({ ids, status }) => tableService.bulkStatus(ids, status),
		onSuccess: (_, variables) => {
			queryClient.invalidateQueries({ queryKey: ["groupedTables"] });
			toast.success(`Updated status of ${variables.ids.length} tables to ${variables.status}`);
			setSelectedIds([]);
			setSelectMode(false);
			setShowStatusDropdown(false);
		},
		onError: (err) => {
			toast.error(err.message || "Failed to update status");
		}
	});
	const bulkCategoryMutation = useMutation({
		mutationFn: ({ ids, catId }) => tableService.bulkCategory(ids, catId),
		onSuccess: (_, variables) => {
			queryClient.invalidateQueries({ queryKey: ["groupedTables"] });
			const catName = tableCategories.find((c) => c.id === variables.catId)?.name || "selected category";
			toast.success(`Moved ${variables.ids.length} tables to ${catName}`);
			setSelectedIds([]);
			setSelectMode(false);
			setShowCategoryDropdown(false);
		},
		onError: (err) => {
			toast.error(err.message || "Failed to update category");
		}
	});
	const bulkDeleteMutation = useMutation({
		mutationFn: (ids) => tableService.bulkDelete(ids),
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["groupedTables"] });
			const skippedCount = data.skippedIds?.length || 0;
			const deletedCount = selectedIds.length - skippedCount;
			if (skippedCount > 0) toast.warning(`Deleted ${deletedCount} tables. ${skippedCount} occupied tables were skipped.`);
			else toast.success(`Deleted ${deletedCount} tables`);
			setSelectedIds([]);
			setSelectMode(false);
			setShowDeleteConfirm(false);
		},
		onError: (err) => {
			toast.error(err.message || "Failed to delete tables");
		}
	});
	const createTableMutation = useMutation({
		mutationFn: (table) => tableService.create(table),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["groupedTables"] });
			toast.success("Table created successfully");
			setIsAddOpen(false);
			setNewTable({
				name: "",
				capacity: 4,
				categoryId: null
			});
			setCreateError(null);
		},
		onError: (err) => {
			setCreateError(err.message || "Failed to create table");
		}
	});
	const createZoneMutation = useMutation({
		mutationFn: (name) => tableService.createTableCategory({
			name,
			position: tableCategories.length + 1,
			isActive: true
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["tableCategories"] });
			queryClient.invalidateQueries({ queryKey: ["groupedTables"] });
			toast.success("Zone created successfully");
			setNewZoneName("");
		},
		onError: (err) => {
			toast.error(err.message || "Failed to create zone");
		}
	});
	const deleteZoneMutation = useMutation({
		mutationFn: (id) => tableService.deleteTableCategory(id),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["tableCategories"] });
			queryClient.invalidateQueries({ queryKey: ["groupedTables"] });
			toast.success("Zone deleted successfully");
		},
		onError: (err) => {
			toast.error(err.message || "Failed to delete zone");
		}
	});
	const handleCreateTable = (e) => {
		e.preventDefault();
		if (!newTable.name.trim()) return setCreateError("Table number is required");
		if (newTable.capacity < 1) return setCreateError("Capacity must be at least 1");
		createTableMutation.mutate({
			name: newTable.name,
			capacity: newTable.capacity,
			categoryId: newTable.categoryId
		});
	};
	const toggleTableSelection = (id) => {
		if (!selectMode) {
			setSideTableId(id);
			return;
		}
		setSelectedIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
	};
	const selectedTables = allTables.filter((t) => selectedIds.includes(t.id));
	const canMerge = selectedIds.length >= 2 && selectedTables.every((t) => !t.isMerged && t.status !== "Occupied") && selectedTables.every((t) => t.categoryId === selectedTables[0].categoryId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Restaurant floor",
		breadcrumbs: [{
			label: "Home",
			to: "/dashboard"
		}, { label: "Tables" }],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mb-4 flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
					value: zone,
					onValueChange: setZone,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, {
						className: "rounded-xl",
						children: ["All", ...tableCategories.map((c) => c.name)].map((z) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: z,
							className: "rounded-lg",
							children: z
						}, z))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "rounded-xl",
							onClick: () => setIsManageZonesOpen(true),
							children: "Manage zones"
						}),
						(canEdit || canDelete) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: selectMode ? "default" : "outline",
							className: "rounded-xl",
							onClick: () => {
								setSelectMode(!selectMode);
								setSelectedIds([]);
								setShowStatusDropdown(false);
								setShowCategoryDropdown(false);
								setShowDeleteConfirm(false);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MousePointerClick, { className: "size-4 mr-1" }), selectMode ? "Selecting…" : "Select mode"]
						}),
						canAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							className: "rounded-xl animate-pulse bg-primary/10 border-primary text-primary",
							onClick: () => setIsAddOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1" }), " Add table"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "rounded-2xl p-6 relative overflow-hidden bg-gradient-to-br from-muted/40 to-background border-dashed select-none",
				style: { minHeight: 600 },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-6 rounded-xl border-2 border-dashed border-border pointer-events-none" }),
					isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 flex items-center justify-center text-muted-foreground",
						children: "Loading tables..."
					}) : groupedTables.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 flex items-center justify-center text-muted-foreground",
						children: "No tables found"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-8 w-full relative z-10 p-4",
						children: groupedTables.filter((g) => zone === "All" || g.categoryName === zone).map((g) => {
							if (g.tables.length === 0) return null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "font-serif text-lg font-bold flex items-center gap-2 border-b pb-2 text-foreground/80",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: g.categoryName }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs font-sans font-normal bg-muted text-muted-foreground px-2 py-0.5 rounded-full",
										children: [g.tables.length, " tables"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4",
									children: g.tables.map((t) => {
										const isSelected = selectedIds.includes(t.id);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											onClick: () => toggleTableSelection(t.id),
											className: cn("relative flex flex-col items-center justify-center border-2 p-6 transition-all hover:scale-105 cursor-pointer shadow-sm rounded-2xl aspect-square", statusColor[t.isMerged ? "Merged" : t.status], isSelected && "ring-4 ring-primary ring-offset-2 ring-offset-background"),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													className: "absolute top-2 right-2 p-1.5 rounded-full hover:bg-muted text-muted-foreground hover:text-foreground transition-colors z-20",
													onClick: (e) => {
														e.stopPropagation();
														setQrModalTable({
															id: t.id,
															name: t.name,
															qrToken: t.qrToken
														});
													},
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "size-4" })
												}),
												selectMode && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "absolute top-2 left-2 bg-background border rounded-full size-4 flex items-center justify-center",
													children: isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-2 rounded-full bg-primary" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "font-serif text-2xl leading-none font-bold text-foreground",
													children: t.name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-xs opacity-80 mt-2 font-medium",
													children: ["Cap: ", t.capacity]
												}),
												t.isMerged && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-[10px] mt-2 px-2.5 py-0.5 rounded-full bg-special text-white font-semibold shadow-xs",
													children: "Merged"
												})
											]
										}, t.id);
									})
								})]
							}, g.categoryId || "unassigned");
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between flex-wrap gap-2 text-[11px] border-t border-muted/50 pt-3 mt-8 bg-background/50 backdrop-blur-xs rounded-lg px-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-4 flex-wrap",
							children: Object.entries(statusLegendColors).map(([k, cls]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5 font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 rounded-full border", cls) }), k]
							}, k))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Click a table to manage guests or check status"
						})]
					})
				]
			}),
			selectMode && selectedIds.length >= 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed bottom-6 left-1/2 -translate-x-1/2 bg-background/95 backdrop-blur-md border border-border shadow-2xl rounded-2xl px-6 py-4 flex items-center gap-4 z-50 animate-in fade-in slide-in-from-bottom-4 duration-200",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm font-semibold border-r border-border pr-4 mr-2",
						children: [selectedIds.length, " selected"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 flex-wrap",
						children: [
							canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								className: "rounded-xl bg-special text-white hover:bg-special/95",
								disabled: !canMerge,
								onClick: () => mergeMutation.mutate(selectedIds),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Combine, { className: "size-4 mr-1" }), " Merge"]
							}),
							canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									className: "rounded-xl",
									onClick: () => {
										setShowStatusDropdown(!showStatusDropdown);
										setShowCategoryDropdown(false);
										setShowDeleteConfirm(false);
									},
									children: ["Change status ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 ml-1" })]
								}), showStatusDropdown && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute bottom-full mb-2 left-0 w-40 bg-background border border-border rounded-xl shadow-xl p-1.5 flex flex-col gap-1 z-50",
									children: [
										"Free",
										"Occupied",
										"Reserved",
										"Cleaning"
									].map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "w-full text-left px-3 py-1.5 text-xs rounded-lg hover:bg-muted font-medium transition-colors",
										onClick: () => bulkStatusMutation.mutate({
											ids: selectedIds,
											status
										}),
										children: status
									}, status))
								})]
							}),
							canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									className: "rounded-xl",
									onClick: () => {
										setShowCategoryDropdown(!showCategoryDropdown);
										setShowStatusDropdown(false);
										setShowDeleteConfirm(false);
									},
									children: ["Change category ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 ml-1" })]
								}), showCategoryDropdown && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute bottom-full mb-2 left-0 w-48 max-h-56 overflow-y-auto bg-background border border-border rounded-xl shadow-xl p-1.5 flex flex-col gap-1 z-50",
									children: tableCategories.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "w-full text-left px-3 py-1.5 text-xs rounded-lg hover:bg-muted font-medium transition-colors",
										onClick: () => bulkCategoryMutation.mutate({
											ids: selectedIds,
											catId: cat.id
										}),
										children: cat.name
									}, cat.id))
								})]
							}),
							canDelete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "destructive",
									className: "rounded-xl",
									onClick: () => {
										setShowDeleteConfirm(!showDeleteConfirm);
										setShowStatusDropdown(false);
										setShowCategoryDropdown(false);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 mr-1" }), " Delete"]
								}), showDeleteConfirm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute bottom-full mb-2 right-0 w-64 bg-background border border-destructive/20 rounded-xl shadow-2xl p-4 flex flex-col gap-3 z-50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground flex gap-1.5 items-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 text-destructive shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"Are you sure you want to delete these ",
											selectedIds.length,
											" tables? Occupied tables will be skipped."
										] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2 justify-end",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											className: "rounded-lg text-xs",
											onClick: () => setShowDeleteConfirm(false),
											children: "Cancel"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "destructive",
											className: "rounded-lg text-xs",
											onClick: () => bulkDeleteMutation.mutate(selectedIds),
											children: "Confirm"
										})]
									})]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "ml-4 p-1 hover:bg-muted rounded-full transition-colors",
						onClick: () => {
							setSelectMode(false);
							setSelectedIds([]);
							setShowStatusDropdown(false);
							setShowCategoryDropdown(false);
							setShowDeleteConfirm(false);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: !!sideTableId,
				onOpenChange: (o) => !o && setSideTableId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
					className: "w-full sm:max-w-md",
					children: sideTableId && (() => {
						const t = allTables.find((x) => x.id === sideTableId);
						if (!t) return null;
						const mergedSiblings = t.mergeGroupId ? allTables.filter((x) => x.mergeGroupId === t.mergeGroupId && x.id !== t.id) : [];
						const rawActiveOrder = (kanbanOrders ? [
							...kanbanOrders.new || [],
							...kanbanOrders.preparing || [],
							...kanbanOrders.ready || [],
							...kanbanOrders.served || []
						] : []).find((o) => (t.isMerged && t.mergeGroupId ? o.mergeGroupId === t.mergeGroupId : o.tableId === t.id) && o.billStatus !== "Paid");
						const activeOrder = rawActiveOrder && !rawActiveOrder.billId ? rawActiveOrder : null;
						const hasUnpaidOrder = !!rawActiveOrder;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
							className: "font-serif text-2xl flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.name }), mergedSiblings.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm font-normal text-muted-foreground",
								children: ["+ ", mergedSiblings.map((m) => m.name).join(", ")]
							})]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 space-y-6 px-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
										className: "p-3 rounded-xl",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-muted-foreground",
											children: "Capacity"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-serif text-xl mt-1",
											children: t.isMerged ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												t.combinedCapacity || t.capacity,
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs text-muted-foreground",
													children: "(combined)"
												})
											] }) : t.capacity
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
										className: "p-3 rounded-xl",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-muted-foreground",
											children: "Status"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "font-serif text-xl mt-1 flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 rounded-full", statusLegendColors[t.isMerged ? "Merged" : t.status]) }), t.isMerged ? "Merged" : t.status]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs font-semibold text-muted-foreground flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Manual Status Override" }), hasUnpaidOrder && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] text-destructive font-bold flex items-center gap-1 normal-case",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3" }), " Active order pending bill"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "outline",
												className: cn("rounded-xl justify-start", t.status === "Free" && !t.isMerged && "border-success bg-success/5"),
												onClick: () => bulkStatusMutation.mutate({
													ids: [t.id],
													status: "Free"
												}),
												disabled: hasUnpaidOrder || bulkStatusMutation.isPending,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-success mr-2" }), " Free"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "outline",
												className: cn("rounded-xl justify-start", t.status === "Occupied" && !t.isMerged && "border-destructive bg-destructive/5"),
												onClick: () => bulkStatusMutation.mutate({
													ids: [t.id],
													status: "Occupied"
												}),
												disabled: hasUnpaidOrder || bulkStatusMutation.isPending,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-destructive mr-2" }), " Occupied"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "outline",
												className: cn("rounded-xl justify-start", t.status === "Reserved" && !t.isMerged && "border-warning bg-warning/5"),
												onClick: () => bulkStatusMutation.mutate({
													ids: [t.id],
													status: "Reserved"
												}),
												disabled: hasUnpaidOrder || bulkStatusMutation.isPending,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-warning mr-2" }), " Reserved"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "outline",
												className: cn("rounded-xl justify-start", t.status === "Cleaning" && !t.isMerged && "border-muted bg-muted/10"),
												onClick: () => bulkStatusMutation.mutate({
													ids: [t.id],
													status: "Cleaning"
												}),
												disabled: hasUnpaidOrder || bulkStatusMutation.isPending,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-muted-foreground/60 mr-2" }), " Cleaning"]
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-2 border-t border-muted",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											className: "rounded-xl bg-primary text-primary-foreground",
											onClick: () => {
												bulkStatusMutation.mutate({
													ids: [t.id],
													status: "Occupied"
												});
												toast.success("Guests seated");
											},
											disabled: hasUnpaidOrder,
											children: "Seat guests"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "outline",
											className: "rounded-xl",
											onClick: () => {
												if (activeOrder) navigate({
													to: "/orders",
													search: {
														editOrderId: activeOrder.id,
														tableId: void 0,
														mergeGroupId: void 0,
														tab: void 0,
														roomNumber: void 0
													}
												});
												else {
													bulkStatusMutation.mutate({
														ids: [t.id],
														status: "Occupied"
													});
													toast.success("Order started");
													if (t.isMerged && t.mergeGroupId) navigate({
														to: "/orders",
														search: {
															mergeGroupId: t.mergeGroupId,
															tableId: void 0,
															editOrderId: void 0,
															tab: void 0,
															roomNumber: void 0
														}
													});
													else navigate({
														to: "/orders",
														search: {
															tableId: t.id,
															mergeGroupId: void 0,
															editOrderId: void 0,
															tab: void 0,
															roomNumber: void 0
														}
													});
												}
											},
											disabled: !!rawActiveOrder?.billId,
											children: rawActiveOrder ? rawActiveOrder.billId ? "Bill generated" : "Edit order" : "Start order"
										})]
									})
								}),
								t.isMerged && t.mergeGroupId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									className: "w-full rounded-xl text-special border-special/30 hover:bg-special/5",
									onClick: () => unmergeMutation.mutate(t.mergeGroupId),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Split, { className: "size-4 mr-1" }), " Split / unmerge group"]
								})
							]
						})] });
					})()
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: isAddOpen,
				onOpenChange: (isOpen) => {
					setIsAddOpen(isOpen);
					if (!isOpen) setCreateError(null);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
					className: "w-full sm:max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
						className: "font-serif text-2xl",
						children: "Add New Table"
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleCreateTable,
						className: "mt-6 space-y-5 px-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "tableNumber",
										children: "Table Number"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "tableNumber",
										placeholder: "e.g. T-13",
										value: newTable.name,
										onChange: (e) => {
											setNewTable((prev) => ({
												...prev,
												name: e.target.value
											}));
											setCreateError(null);
										},
										required: true,
										className: "rounded-xl font-medium"
									}),
									createError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-destructive font-medium mt-1",
										children: createError
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "capacity",
									children: "Capacity"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "outline",
											className: "rounded-xl size-10 flex items-center justify-center text-lg font-bold",
											onClick: () => setNewTable((prev) => ({
												...prev,
												capacity: Math.max(1, prev.capacity - 1)
											})),
											children: "-"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "capacity",
											type: "number",
											min: 1,
											value: newTable.capacity,
											onChange: (e) => setNewTable((prev) => ({
												...prev,
												capacity: Math.max(1, Number(e.target.value))
											})),
											required: true,
											className: "rounded-xl text-center font-bold flex-1"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "outline",
											className: "rounded-xl size-10 flex items-center justify-center text-lg font-bold",
											onClick: () => setNewTable((prev) => ({
												...prev,
												capacity: prev.capacity + 1
											})),
											children: "+"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "category",
									children: "Category / Zone"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									id: "category",
									className: "w-full rounded-xl border border-input bg-background px-3 py-2 text-sm focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring font-medium",
									value: newTable.categoryId || "",
									onChange: (e) => setNewTable((prev) => ({
										...prev,
										categoryId: e.target.value ? Number(e.target.value) : null
									})),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Unassigned"
									}), tableCategories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: c.id,
										children: c.name
									}, c.id))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pt-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "w-full rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-base py-3",
									disabled: createTableMutation.isPending,
									children: createTableMutation.isPending ? "Creating..." : "Create Table"
								})
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: isManageZonesOpen,
				onOpenChange: setIsManageZonesOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
					className: "w-full sm:max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
						className: "font-serif text-2xl",
						children: "Manage Zones"
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 space-y-6 px-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: (e) => {
								e.preventDefault();
								if (!newZoneName.trim()) return;
								createZoneMutation.mutate(newZoneName.trim());
							},
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "zoneName",
								children: "Add New Zone"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "zoneName",
									placeholder: "e.g. Patio, Rooftop",
									value: newZoneName,
									onChange: (e) => setNewZoneName(e.target.value),
									className: "rounded-xl font-medium flex-1"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold",
									disabled: createZoneMutation.isPending,
									children: createZoneMutation.isPending ? "Adding..." : "Add"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-t border-muted pt-4 space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Active Zones" }), tableCategories.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "No active zones. Tables will be Unassigned."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2 max-h-80 overflow-y-auto pr-1",
								children: tableCategories.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between p-3 rounded-xl border border-muted bg-muted/20",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-sm",
										children: cat.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "ghost",
										className: "rounded-lg text-destructive hover:bg-destructive/10 hover:text-destructive size-8 p-0",
										onClick: () => {
											if (confirm(`Are you sure you want to delete the zone "${cat.name}"? Tables in this zone will be set to Unassigned.`)) deleteZoneMutation.mutate(cat.id);
										},
										disabled: deleteZoneMutation.isPending,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
									})]
								}, cat.id))
							})]
						})]
					})]
				})
			}),
			qrModalTable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableQrModal, {
				tableId: qrModalTable.id,
				tableName: qrModalTable.name,
				qrToken: qrModalTable.qrToken,
				open: !!qrModalTable,
				onClose: () => setQrModalTable(null)
			})
		]
	});
}
//#endregion
export { TablesPage as component };
