import { r as __toESM } from "../_runtime.mjs";
import { r as settingsService } from "./settingsService-Dilksh94.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { n as Input, t as Button } from "./button-juXZH0rY.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { I as LoaderCircle, T as Plus, Y as CircleCheckBig, i as Users, l as Timer } from "../_libs/lucide-react.mjs";
import { a as StatusBadge, t as AppShell } from "./app-shell-C6Y1qr1C.mjs";
import { t as Card } from "./card-DNWGqbqR.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CUQVyHA-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Label } from "./label-Bkz_RwW1.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as DialogTrigger, t as Dialog } from "./dialog-BtIFXM_M.mjs";
import { t as tableService } from "./tableService-LRzUVk7o.mjs";
import { t as waitlistService } from "./waitlistService-BB0IpGbl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/waitlist-DjUA58Pb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WaitPage() {
	const queryClient = useQueryClient();
	const { data: waitlist = [], isFetching } = useQuery({
		queryKey: ["waitlist"],
		queryFn: () => waitlistService.getAll()
	});
	const { data: settings } = useQuery({
		queryKey: ["settings", "general"],
		queryFn: () => settingsService.getGeneralSettings()
	});
	useMutation({
		mutationFn: (id) => waitlistService.updateStatus(id, 1),
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["waitlist"] });
			toast.success(`SMS sent to ${data.guestName}`);
		},
		onError: (err) => {
			toast.error(err.message || "Failed to notify guest");
		}
	});
	const assignMutation = useMutation({
		mutationFn: ({ id, tableId }) => waitlistService.assignTable(id, tableId),
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["waitlist"] });
			queryClient.invalidateQueries({ queryKey: ["tables"] });
			queryClient.invalidateQueries({ queryKey: ["kanbanOrders"] });
			toast.success(`${data.guestName} seated to table!`);
		},
		onError: (err) => {
			toast.error(err.message || "Failed to assign table");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Waiting list",
		breadcrumbs: [{
			label: "Home",
			to: "/dashboard"
		}, { label: "Waitlist" }],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "p-4 rounded-2xl mb-4 stat-gradient flex items-center justify-between flex-wrap gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-10 rounded-xl bg-primary/15 text-primary flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-widest text-muted-foreground",
						children: "Estimated wait"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-serif text-2xl",
						children: [
							"~ ",
							settings?.waitlistEstimatedWaitMinutes ?? 22,
							" minutes"
						]
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm text-muted-foreground max-w-md",
					children: settings?.waitlistMessage || "Based on average turnover of 48m over the last hour and 3 free tables."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddDialog, {})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid md:grid-cols-2 xl:grid-cols-3 gap-4",
			children: [
				isFetching && waitlist.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "col-span-full py-8 text-center text-muted-foreground animate-pulse flex items-center justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" }), " Loading waitlist..."]
				}),
				waitlist.length === 0 && !isFetching && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-span-full py-8 text-center text-muted-foreground border border-dashed border-border/50 rounded-2xl glass",
					children: "No guests currently on the waitlist."
				}),
				waitlist.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5 rounded-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] uppercase tracking-widest text-muted-foreground",
								children: "Token"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-serif text-4xl text-primary",
								children: w.token
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: w.status })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-medium",
								children: w.guestName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: w.phone
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center gap-3 text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3" }),
										" Party ",
										w.partySize
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: w.seatingPreference }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-primary",
									children: [w.waitedMin, "m waiting"]
								})
							]
						}),
						w.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 text-xs text-muted-foreground bg-muted/20 p-2 rounded-lg",
							children: ["Note: ", w.notes]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssignTableDialog, {
								waitlistEntry: w,
								assignMutation
							})
						})
					]
				}, w.id))
			]
		})]
	});
}
function AddDialog() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [partySize, setPartySize] = (0, import_react.useState)(2);
	const [seating, setSeating] = (0, import_react.useState)("No preference");
	const [guestName, setGuestName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const queryClient = useQueryClient();
	const [debouncedPartySize, setDebouncedPartySize] = (0, import_react.useState)(partySize);
	const [debouncedSeating, setDebouncedSeating] = (0, import_react.useState)(seating);
	(0, import_react.useEffect)(() => {
		const timer = setTimeout(() => {
			setDebouncedPartySize(partySize);
			setDebouncedSeating(seating);
		}, 400);
		return () => clearTimeout(timer);
	}, [partySize, seating]);
	const { data: availableTables, isFetching } = useQuery({
		queryKey: [
			"availableTables",
			debouncedPartySize,
			debouncedSeating
		],
		queryFn: () => tableService.getAvailable(debouncedPartySize, debouncedSeating),
		enabled: debouncedPartySize > 0 && open
	});
	const { data: categories = [] } = useQuery({
		queryKey: ["tableCategories"],
		queryFn: () => tableService.getTableCategories(),
		enabled: open
	});
	const assignMutation = useMutation({
		mutationFn: (tableId) => tableService.assignTable(tableId, {
			guestName,
			phone,
			partySize,
			notes
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["tables"] });
			toast.success(`${guestName || "Guest"} seated directly to table!`);
			setOpen(false);
		},
		onError: (err) => {
			toast.error(err.message || "Failed to assign table");
		}
	});
	const bestTable = availableTables && availableTables.length > 0 ? availableTables[0] : null;
	const createMutation = useMutation({
		mutationFn: () => waitlistService.create({
			guestName,
			phone,
			partySize,
			seatingPreference: seating,
			notes
		}),
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["waitlist"] });
			toast.success(`Token ${data.token} issued successfully`);
			setOpen(false);
			setGuestName("");
			setPhone("");
			setNotes("");
		},
		onError: (err) => {
			toast.error(err.message || "Failed to create waitlist entry");
		}
	});
	const handleSubmit = (e) => {
		e.preventDefault();
		createMutation.mutate();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "rounded-xl bg-primary text-primary-foreground copper-glow",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1" }), " Add to waitlist"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md rounded-2xl glass",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-serif text-2xl",
				children: "Add to waitlist"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-3",
				onSubmit: handleSubmit,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Guest name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						required: true,
						className: "rounded-xl mt-1",
						value: guestName,
						onChange: (e) => setGuestName(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Phone" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "rounded-xl mt-1",
							value: phone,
							onChange: (e) => setPhone(e.target.value)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Party size" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 1,
							value: partySize,
							onChange: (e) => setPartySize(parseInt(e.target.value) || 1),
							className: "rounded-xl mt-1"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Seating preference" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: seating,
						onValueChange: setSeating,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "rounded-xl mt-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "No preference" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "No preference",
							children: "No preference"
						}), categories.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: cat.name,
							children: cat.name
						}, cat.id))] })]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Notes" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Anniversary",
						className: "rounded-xl mt-1",
						value: notes,
						onChange: (e) => setNotes(e.target.value)
					})] }),
					isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3 bg-muted/30 rounded-xl flex items-center justify-center text-sm text-muted-foreground animate-pulse",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 mr-2 animate-spin" }), " Checking availability..."]
					}) : bestTable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3 bg-success/15 border border-success/30 rounded-xl flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "size-5 text-success mt-0.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-medium text-success-foreground",
							children: [
								"Table ",
								bestTable.name,
								" (seats ",
								bestTable.capacity,
								") is available now for your party of ",
								partySize,
								" (",
								bestTable.categoryName || "General",
								") — no need to wait."
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								className: "flex-1 rounded-xl bg-success text-white hover:bg-success/90 font-bold shadow-md",
								onClick: () => assignMutation.mutate(bestTable.id),
								disabled: assignMutation.isPending,
								children: assignMutation.isPending ? "Assigning..." : "Seat now"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								variant: "outline",
								className: "flex-1 rounded-xl border-success/30 text-success hover:bg-success/10 font-bold",
								disabled: assignMutation.isPending,
								children: "Waitlist instead"
							})]
						})] })]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: createMutation.isPending,
						className: "w-full rounded-xl bg-primary text-primary-foreground copper-glow font-bold pt-1.5",
						children: createMutation.isPending ? "Issuing..." : "Issue token"
					})
				]
			})]
		})]
	});
}
function AssignTableDialog({ waitlistEntry, assignMutation }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const { data: availableTables = [], isFetching } = useQuery({
		queryKey: [
			"availableTables",
			waitlistEntry.partySize,
			waitlistEntry.seatingPreference
		],
		queryFn: () => tableService.getAvailable(waitlistEntry.partySize, waitlistEntry.seatingPreference),
		enabled: open
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				className: "w-full rounded-lg bg-primary text-primary-foreground",
				children: "Assign table"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md rounded-2xl glass",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-serif text-2xl",
					children: "Assign Table"
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-sm text-muted-foreground mb-4",
					children: [
						"Assigning table for ",
						waitlistEntry.guestName,
						" (Party of ",
						waitlistEntry.partySize,
						")"
					]
				}),
				isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3 bg-muted/30 rounded-xl flex items-center justify-center text-sm text-muted-foreground animate-pulse",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 mr-2 animate-spin" }), " Checking availability..."]
				}) : availableTables.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-4 text-center border border-dashed rounded-xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted-foreground",
						children: [
							"No free tables found for ",
							waitlistEntry.partySize,
							" guests."
						]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar",
					children: availableTables.map((table) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between p-3 border rounded-xl hover:bg-muted/30 transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-medium",
							children: ["Table ", table.name]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground",
							children: [
								"Seats ",
								table.capacity,
								" · ",
								table.categoryName || "General"
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							className: "rounded-lg",
							disabled: assignMutation.isPending,
							onClick: () => {
								assignMutation.mutate({
									id: waitlistEntry.id,
									tableId: table.id
								}, { onSuccess: () => setOpen(false) });
							},
							children: "Seat here"
						})]
					}, table.id))
				})
			]
		})]
	});
}
//#endregion
export { WaitPage as component };
