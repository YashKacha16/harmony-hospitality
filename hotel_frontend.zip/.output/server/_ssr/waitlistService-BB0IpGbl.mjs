import { n as apiClient } from "./settingsService-Dilksh94.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/waitlistService-BB0IpGbl.js
var waitlistService = {
	getAll: () => apiClient.get("/api/waitlist"),
	create: (dto) => apiClient.post("/api/waitlist", dto),
	updateStatus: (id, status) => apiClient.put(`/api/waitlist/${id}/status`, status),
	assignTable: (id, tableId) => apiClient.post(`/api/waitlist/${id}/assign`, tableId)
};
//#endregion
export { waitlistService as t };
