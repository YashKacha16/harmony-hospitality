//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-OhAravWE.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/__root.tsx",
		children: [
			"/",
			"/billing",
			"/bookings",
			"/clients",
			"/dashboard",
			"/employees",
			"/menu",
			"/orders",
			"/rooms",
			"/settings",
			"/tables",
			"/waitlist",
			"/order/$token",
			"/print-booking/$bookingId",
			"/print/$billId"
		],
		preloads: [
			"/assets/index-BEMfhz1c.js",
			"/assets/rolldown-runtime-BHe-jwch.js",
			"/assets/settingsService-5eRXN9OL.js",
			"/assets/link-QtMW14hl.js",
			"/assets/preload-helper-btW8_LZ9.js",
			"/assets/mutation-EgnKKk1I.js",
			"/assets/theme-OCddHRa-.js",
			"/assets/dist-BmBkF085.js",
			"/assets/orders-jXHOrIpq.js",
			"/assets/order._token-DuByPWp1.js",
			"/assets/print-booking._bookingId-C036euIQ.js",
			"/assets/print._billId-BRyg0e_x.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BEMfhz1c.js"
		} }]
	},
	"/": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-TPfYemli.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/authService-D4G2WGUb.js",
			"/assets/label-nAtPBdNm.js",
			"/assets/checkbox-DPIQecjM.js"
		]
	},
	"/billing": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/billing.tsx",
		children: void 0,
		preloads: [
			"/assets/billing-CxzaEmXO.js",
			"/assets/app-shell-BV7WQpWK.js",
			"/assets/useMutation-Cd7RZ6BP.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/select-DaLXuxVU.js",
			"/assets/card-D3F_TmZK.js",
			"/assets/loader-circle-DJlbdOvK.js",
			"/assets/printer-BQDbBDVq.js",
			"/assets/billingService-Cak3GlV4.js"
		]
	},
	"/bookings": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/bookings.tsx",
		children: void 0,
		preloads: [
			"/assets/bookings-CSIJrJG7.js",
			"/assets/app-shell-BV7WQpWK.js",
			"/assets/useMutation-Cd7RZ6BP.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/authService-D4G2WGUb.js",
			"/assets/select-DaLXuxVU.js",
			"/assets/circle-check-big-CD1Nsgds.js",
			"/assets/card-D3F_TmZK.js",
			"/assets/loader-circle-DJlbdOvK.js",
			"/assets/plus-DSNdVvnG.js",
			"/assets/printer-BQDbBDVq.js",
			"/assets/triangle-alert-Bk8x8Ng_.js",
			"/assets/upload-CUMf9aqW.js",
			"/assets/user-check-DbHWB7GO.js",
			"/assets/tabs-3IMmf5Z9.js",
			"/assets/bookingService-BH9g0JS4.js",
			"/assets/sheet-Cnb3wjJr.js",
			"/assets/label-nAtPBdNm.js",
			"/assets/roomService-DGC894kz.js",
			"/assets/dialog-CVBaX_go.js",
			"/assets/textarea-POTtlmid.js"
		]
	},
	"/clients": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/clients.tsx",
		children: void 0,
		preloads: [
			"/assets/clients-BXGJJ8TI.js",
			"/assets/app-shell-BV7WQpWK.js",
			"/assets/useMutation-Cd7RZ6BP.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/calendar-BxVgv1y8.js",
			"/assets/card-D3F_TmZK.js",
			"/assets/phone-B0eZROv_.js",
			"/assets/plus-DSNdVvnG.js",
			"/assets/sparkles-DEA_PfZq.js",
			"/assets/trash-2-Dp81ID2Q.js",
			"/assets/user-check-DbHWB7GO.js",
			"/assets/sheet-Cnb3wjJr.js",
			"/assets/label-nAtPBdNm.js"
		]
	},
	"/dashboard": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-Cu8HMFB8.js",
			"/assets/app-shell-BV7WQpWK.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/card-D3F_TmZK.js",
			"/assets/plus-DSNdVvnG.js",
			"/assets/shopping-bag-C4oUoYQr.js",
			"/assets/sparkles-DEA_PfZq.js",
			"/assets/triangle-alert-Bk8x8Ng_.js",
			"/assets/tableService-XEANq6m1.js",
			"/assets/orderService-DWFobVSx.js",
			"/assets/bookingService-BH9g0JS4.js",
			"/assets/roomService-DGC894kz.js",
			"/assets/waitlistService-Dg9Z5PhY.js"
		]
	},
	"/employees": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/employees.tsx",
		children: void 0,
		preloads: [
			"/assets/employees-CfyRoHgH.js",
			"/assets/app-shell-BV7WQpWK.js",
			"/assets/useMutation-Cd7RZ6BP.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/select-DaLXuxVU.js",
			"/assets/card-D3F_TmZK.js",
			"/assets/phone-B0eZROv_.js",
			"/assets/plus-DSNdVvnG.js",
			"/assets/sheet-Cnb3wjJr.js",
			"/assets/label-nAtPBdNm.js"
		]
	},
	"/menu": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/menu.tsx",
		children: void 0,
		preloads: [
			"/assets/menu-_JbT5ZYl.js",
			"/assets/app-shell-BV7WQpWK.js",
			"/assets/useMutation-Cd7RZ6BP.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/card-D3F_TmZK.js",
			"/assets/pencil-KjGxdnh5.js",
			"/assets/plus-DSNdVvnG.js",
			"/assets/trash-2-Dp81ID2Q.js",
			"/assets/menuService-BwFQF-WO.js",
			"/assets/sheet-Cnb3wjJr.js",
			"/assets/label-nAtPBdNm.js",
			"/assets/textarea-POTtlmid.js",
			"/assets/switch-Ci65R1E4.js"
		]
	},
	"/orders": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/orders.tsx",
		children: void 0,
		preloads: [
			"/assets/orders-YuNM-vby.js",
			"/assets/app-shell-BV7WQpWK.js",
			"/assets/useMutation-Cd7RZ6BP.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/HubConnectionBuilder-BGr9-sF6.js",
			"/assets/card-D3F_TmZK.js",
			"/assets/plus-DSNdVvnG.js",
			"/assets/trash-2-Dp81ID2Q.js",
			"/assets/menuService-BwFQF-WO.js",
			"/assets/tableService-XEANq6m1.js",
			"/assets/orderService-DWFobVSx.js",
			"/assets/billingService-Cak3GlV4.js",
			"/assets/tabs-3IMmf5Z9.js",
			"/assets/label-nAtPBdNm.js",
			"/assets/dialog-CVBaX_go.js",
			"/assets/switch-Ci65R1E4.js"
		]
	},
	"/rooms": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/rooms.tsx",
		children: void 0,
		preloads: [
			"/assets/rooms-CADJ0lEL.js",
			"/assets/app-shell-BV7WQpWK.js",
			"/assets/useMutation-Cd7RZ6BP.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/calendar-BxVgv1y8.js",
			"/assets/select-DaLXuxVU.js",
			"/assets/card-D3F_TmZK.js",
			"/assets/loader-circle-DJlbdOvK.js",
			"/assets/pencil-KjGxdnh5.js",
			"/assets/plus-DSNdVvnG.js",
			"/assets/trash-2-Dp81ID2Q.js",
			"/assets/upload-CUMf9aqW.js",
			"/assets/tabs-3IMmf5Z9.js",
			"/assets/sheet-Cnb3wjJr.js",
			"/assets/label-nAtPBdNm.js",
			"/assets/roomService-DGC894kz.js",
			"/assets/dialog-CVBaX_go.js",
			"/assets/textarea-POTtlmid.js",
			"/assets/checkbox-DPIQecjM.js",
			"/assets/switch-Ci65R1E4.js"
		]
	},
	"/settings": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DjKQ9QCn.js",
			"/assets/app-shell-BV7WQpWK.js",
			"/assets/useMutation-Cd7RZ6BP.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/select-DaLXuxVU.js",
			"/assets/card-D3F_TmZK.js",
			"/assets/plus-DSNdVvnG.js",
			"/assets/trash-2-Dp81ID2Q.js",
			"/assets/upload-CUMf9aqW.js",
			"/assets/tabs-3IMmf5Z9.js",
			"/assets/label-nAtPBdNm.js",
			"/assets/dialog-CVBaX_go.js",
			"/assets/textarea-POTtlmid.js",
			"/assets/switch-Ci65R1E4.js"
		]
	},
	"/tables": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/tables.tsx",
		children: void 0,
		preloads: [
			"/assets/tables-ggn9aHcS.js",
			"/assets/app-shell-BV7WQpWK.js",
			"/assets/useMutation-Cd7RZ6BP.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/chevron-down-CvG6d9YS.js",
			"/assets/card-D3F_TmZK.js",
			"/assets/plus-DSNdVvnG.js",
			"/assets/printer-BQDbBDVq.js",
			"/assets/trash-2-Dp81ID2Q.js",
			"/assets/triangle-alert-Bk8x8Ng_.js",
			"/assets/tableService-XEANq6m1.js",
			"/assets/orderService-DWFobVSx.js",
			"/assets/tabs-3IMmf5Z9.js",
			"/assets/sheet-Cnb3wjJr.js",
			"/assets/label-nAtPBdNm.js",
			"/assets/dialog-CVBaX_go.js"
		]
	},
	"/waitlist": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-aZDJmUHt.js",
			"/assets/app-shell-BV7WQpWK.js",
			"/assets/useMutation-Cd7RZ6BP.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/select-DaLXuxVU.js",
			"/assets/circle-check-big-CD1Nsgds.js",
			"/assets/card-D3F_TmZK.js",
			"/assets/loader-circle-DJlbdOvK.js",
			"/assets/plus-DSNdVvnG.js",
			"/assets/tableService-XEANq6m1.js",
			"/assets/label-nAtPBdNm.js",
			"/assets/dialog-CVBaX_go.js",
			"/assets/waitlistService-Dg9Z5PhY.js"
		]
	},
	"/order/$token": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/order.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/order._token-cdVsI6Qv.js",
			"/assets/useMutation-Cd7RZ6BP.js",
			"/assets/button-BPO2Anxa.js",
			"/assets/HubConnectionBuilder-BGr9-sF6.js",
			"/assets/circle-check-big-CD1Nsgds.js",
			"/assets/card-D3F_TmZK.js",
			"/assets/plus-DSNdVvnG.js",
			"/assets/shopping-bag-C4oUoYQr.js",
			"/assets/triangle-alert-Bk8x8Ng_.js",
			"/assets/menuService-BwFQF-WO.js",
			"/assets/tableService-XEANq6m1.js",
			"/assets/orderService-DWFobVSx.js",
			"/assets/tabs-3IMmf5Z9.js",
			"/assets/sheet-Cnb3wjJr.js"
		]
	},
	"/print-booking/$bookingId": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/print-booking.$bookingId.tsx",
		children: void 0,
		preloads: ["/assets/print-booking._bookingId-CwAkFAYL.js", "/assets/bookingService-BH9g0JS4.js"]
	},
	"/print/$billId": {
		filePath: "C:/Hotel_Management/harmony-hospitality/src/routes/print.$billId.tsx",
		children: void 0,
		preloads: ["/assets/print._billId-DXvDXCfz.js", "/assets/billingService-Cak3GlV4.js"]
	}
} });
//#endregion
export { tsrStartManifest };
