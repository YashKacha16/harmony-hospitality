globalThis.__nitro_main__ = import.meta.url;
import { a as FastResponse, n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-07-24T13:20:24.528Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/billing-CxzaEmXO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1675-ctiADqpfNLiuGt5UEU3Izv2utWA\"",
		"mtime": "2026-08-04T04:05:25.816Z",
		"size": 5749,
		"path": "../public/assets/billing-CxzaEmXO.js"
	},
	"/assets/app-shell-BV7WQpWK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10c79-q81J0oxc5CCgqWYF4r9/KxGsXYI\"",
		"mtime": "2026-08-04T04:05:25.816Z",
		"size": 68729,
		"path": "../public/assets/app-shell-BV7WQpWK.js"
	},
	"/assets/authService-D4G2WGUb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"59b-WUed8NlXJ7y13P0wm/Ozysjf8LQ\"",
		"mtime": "2026-08-04T04:05:25.816Z",
		"size": 1435,
		"path": "../public/assets/authService-D4G2WGUb.js"
	},
	"/assets/calendar-BxVgv1y8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f7-kWztcH655bW2pDIwyMoFCX8cm9c\"",
		"mtime": "2026-08-04T04:05:25.824Z",
		"size": 247,
		"path": "../public/assets/calendar-BxVgv1y8.js"
	},
	"/assets/bookingService-BH9g0JS4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"254-p9v/jzatnn69yJSDEsZ5MUbAxPQ\"",
		"mtime": "2026-08-04T04:05:25.824Z",
		"size": 596,
		"path": "../public/assets/bookingService-BH9g0JS4.js"
	},
	"/assets/billingService-Cak3GlV4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d5-nV8PKlneH8BAJigOXOml+ZvkdIk\"",
		"mtime": "2026-08-04T04:05:25.824Z",
		"size": 469,
		"path": "../public/assets/billingService-Cak3GlV4.js"
	},
	"/assets/button-BPO2Anxa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a42f-MY6tTcJvynEssLz3f0be906mHCw\"",
		"mtime": "2026-08-04T04:05:25.824Z",
		"size": 42031,
		"path": "../public/assets/button-BPO2Anxa.js"
	},
	"/assets/bookings-CSIJrJG7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7462-kxZ3O89o3raIGoMewreYFqdgjjE\"",
		"mtime": "2026-08-04T04:05:25.824Z",
		"size": 29794,
		"path": "../public/assets/bookings-CSIJrJG7.js"
	},
	"/assets/card-D3F_TmZK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a0b-CAVAL5IdokZtVkstVPOKTjdiaiI\"",
		"mtime": "2026-08-04T04:05:25.824Z",
		"size": 35339,
		"path": "../public/assets/card-D3F_TmZK.js"
	},
	"/assets/chevron-down-CvG6d9YS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"76-ctktlSzevsW73nRdB8DM1EEa87w\"",
		"mtime": "2026-08-04T04:05:25.824Z",
		"size": 118,
		"path": "../public/assets/chevron-down-CvG6d9YS.js"
	},
	"/assets/checkbox-DPIQecjM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"116b-EiYihE1FteLry2UokhTxlI/itlc\"",
		"mtime": "2026-08-04T04:05:25.824Z",
		"size": 4459,
		"path": "../public/assets/checkbox-DPIQecjM.js"
	},
	"/assets/circle-check-big-CD1Nsgds.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b8-XAbxL+z3RNdmzkXxF3ROP10tQbc\"",
		"mtime": "2026-08-04T04:05:25.824Z",
		"size": 184,
		"path": "../public/assets/circle-check-big-CD1Nsgds.js"
	},
	"/assets/clients-BXGJJ8TI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34db-DNC1VN6KHuyruSEzwo8bAtH9pwU\"",
		"mtime": "2026-08-04T04:05:25.824Z",
		"size": 13531,
		"path": "../public/assets/clients-BXGJJ8TI.js"
	},
	"/assets/dashboard-Cu8HMFB8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16a4-8xYvMpvsAtTvy05/ixUIrGG6/AQ\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 5796,
		"path": "../public/assets/dashboard-Cu8HMFB8.js"
	},
	"/assets/dialog-CVBaX_go.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"87f-Mk7dMPQBzNUyy8N+9fVmMrv9G6c\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 2175,
		"path": "../public/assets/dialog-CVBaX_go.js"
	},
	"/assets/dist-Cnam085E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"139b-zwNUy/+x/6CnaK1g/aMTzLUjFKw\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 5019,
		"path": "../public/assets/dist-Cnam085E.js"
	},
	"/assets/dist-BmBkF085.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7f4c-uh99wY0PTqNiwLnDEYsMajwD3Uw\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 32588,
		"path": "../public/assets/dist-BmBkF085.js"
	},
	"/assets/employees-CfyRoHgH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21c0-6JsZkPDqhGhORZy+VfM7BT0wKGs\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 8640,
		"path": "../public/assets/employees-CfyRoHgH.js"
	},
	"/assets/HubConnectionBuilder-BGr9-sF6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d7eb-WX7KBxmpMqPkzKO2XYbfHeR7q7s\"",
		"mtime": "2026-08-04T04:05:25.816Z",
		"size": 55275,
		"path": "../public/assets/HubConnectionBuilder-BGr9-sF6.js"
	},
	"/assets/menu-_JbT5ZYl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f09b-F1N5+NQacUDwxvawuJv/A2bepHc\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 61595,
		"path": "../public/assets/menu-_JbT5ZYl.js"
	},
	"/assets/link-QtMW14hl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5d02-0EL4nNPlfGm+yzGEWEIDQzmL+ww\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 23810,
		"path": "../public/assets/link-QtMW14hl.js"
	},
	"/assets/loader-circle-DJlbdOvK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"86-Owpe283OO/eG9JlohS/XykQcChU\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 134,
		"path": "../public/assets/loader-circle-DJlbdOvK.js"
	},
	"/assets/label-nAtPBdNm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2be-ctYDrCHCM+TN5w597iu1SIiwnWE\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 702,
		"path": "../public/assets/label-nAtPBdNm.js"
	},
	"/assets/index-BEMfhz1c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"47ca9-uWK1NO68MQT218aBFGcsnJi5tSU\"",
		"mtime": "2026-08-04T04:05:25.816Z",
		"size": 294057,
		"path": "../public/assets/index-BEMfhz1c.js"
	},
	"/assets/menuService-BwFQF-WO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"273-amWYKYEpD6z0BgqHU2YCWfpOAVs\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 627,
		"path": "../public/assets/menuService-BwFQF-WO.js"
	},
	"/assets/order._token-cdVsI6Qv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30e1-L5afFNfsRAkp+UkIKQ6oVY36/jA\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 12513,
		"path": "../public/assets/order._token-cdVsI6Qv.js"
	},
	"/assets/mutation-EgnKKk1I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d39-stBB7VmntthgU266Jyq6SHge1b0\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 3385,
		"path": "../public/assets/mutation-EgnKKk1I.js"
	},
	"/assets/order._token-DuByPWp1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"426-UhBD6/0pu9n2iztXARHHRyE1Gkk\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 1062,
		"path": "../public/assets/order._token-DuByPWp1.js"
	},
	"/assets/orders-YuNM-vby.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"785e-PiGjxjZWEHWInc98cOt0BQ95R/k\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 30814,
		"path": "../public/assets/orders-YuNM-vby.js"
	},
	"/assets/orders-jXHOrIpq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5ba-apCzTt1jFwplknfUczolwGPRQo8\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 1466,
		"path": "../public/assets/orders-jXHOrIpq.js"
	},
	"/assets/pencil-KjGxdnh5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10a-x1YZKVL5t75Bwyuq7XoPnVVikR0\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 266,
		"path": "../public/assets/pencil-KjGxdnh5.js"
	},
	"/assets/phone-B0eZROv_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"138-0R75pM+pPYlitMxDpXpF7x/gLrM\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 312,
		"path": "../public/assets/phone-B0eZROv_.js"
	},
	"/assets/preload-helper-btW8_LZ9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"164a-q2kdUk7p2rwBviHSHTc/Gk5aFuQ\"",
		"mtime": "2026-08-04T04:05:25.849Z",
		"size": 5706,
		"path": "../public/assets/preload-helper-btW8_LZ9.js"
	},
	"/assets/print-booking._bookingId-C036euIQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d1-U3RuI9wfT9/y1afQE4zK8E5jr/k\"",
		"mtime": "2026-08-04T04:05:25.850Z",
		"size": 465,
		"path": "../public/assets/print-booking._bookingId-C036euIQ.js"
	},
	"/assets/orderService-DWFobVSx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ad-6kwU6wbQRC1F+22329kesRaXjUQ\"",
		"mtime": "2026-08-04T04:05:25.833Z",
		"size": 429,
		"path": "../public/assets/orderService-DWFobVSx.js"
	},
	"/assets/print._billId-BRyg0e_x.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b0-CvNtHJ8RvY/P+OWqrfFC7FSkoIg\"",
		"mtime": "2026-08-04T04:05:25.850Z",
		"size": 432,
		"path": "../public/assets/print._billId-BRyg0e_x.js"
	},
	"/assets/print-booking._bookingId-CwAkFAYL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bc0-+XeB4o84wlq58LjTxyQPWuCwkOk\"",
		"mtime": "2026-08-04T04:05:25.850Z",
		"size": 7104,
		"path": "../public/assets/print-booking._bookingId-CwAkFAYL.js"
	},
	"/assets/rolldown-runtime-BHe-jwch.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3bd-oed+/PJavFpEIvuOvBOJyseqyfo\"",
		"mtime": "2026-08-04T04:05:25.850Z",
		"size": 957,
		"path": "../public/assets/rolldown-runtime-BHe-jwch.js"
	},
	"/assets/print._billId-DXvDXCfz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"166d-994m3BVByPBi4qcCpQZCS6Xt/yU\"",
		"mtime": "2026-08-04T04:05:25.850Z",
		"size": 5741,
		"path": "../public/assets/print._billId-DXvDXCfz.js"
	},
	"/assets/rooms-CADJ0lEL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"89dc-27LplNChI7rrD26Qqk1/8NI3px0\"",
		"mtime": "2026-08-04T04:05:25.850Z",
		"size": 35292,
		"path": "../public/assets/rooms-CADJ0lEL.js"
	},
	"/assets/printer-BQDbBDVq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"135-7FX42cDre2ujrf4WhOKPpCdY/T8\"",
		"mtime": "2026-08-04T04:05:25.850Z",
		"size": 309,
		"path": "../public/assets/printer-BQDbBDVq.js"
	},
	"/assets/roomService-DGC894kz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ed-yPdyuu+f72o5AAnKo510mejyj38\"",
		"mtime": "2026-08-04T04:05:25.850Z",
		"size": 493,
		"path": "../public/assets/roomService-DGC894kz.js"
	},
	"/assets/routes-TPfYemli.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16e4-xhR56SFd3eaDb1e/UBWg4bP0GBY\"",
		"mtime": "2026-08-04T04:05:25.850Z",
		"size": 5860,
		"path": "../public/assets/routes-TPfYemli.js"
	},
	"/assets/select-DaLXuxVU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5795-3YNAR+OvCGQBOglCTvk0+wek4h0\"",
		"mtime": "2026-08-04T04:05:25.850Z",
		"size": 22421,
		"path": "../public/assets/select-DaLXuxVU.js"
	},
	"/assets/settingsService-5eRXN9OL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8ff7-wzxtDV6HVaW8Bxl7mkl0wedkj04\"",
		"mtime": "2026-08-04T04:05:25.850Z",
		"size": 36855,
		"path": "../public/assets/settingsService-5eRXN9OL.js"
	},
	"/assets/plus-DSNdVvnG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8f-Xjle1EjcSIPwlYePZGR5Dh96mZ8\"",
		"mtime": "2026-08-04T04:05:25.848Z",
		"size": 143,
		"path": "../public/assets/plus-DSNdVvnG.js"
	},
	"/assets/sheet-Cnb3wjJr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a00-XIa8pDGX/6SZ3JInVSuioP/X1+8\"",
		"mtime": "2026-08-04T04:05:25.864Z",
		"size": 2560,
		"path": "../public/assets/sheet-Cnb3wjJr.js"
	},
	"/assets/settings-DjKQ9QCn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5a69-p3yj2W27scTrc0r4qSoCOHiblMQ\"",
		"mtime": "2026-08-04T04:05:25.850Z",
		"size": 23145,
		"path": "../public/assets/settings-DjKQ9QCn.js"
	},
	"/assets/shopping-bag-C4oUoYQr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14a-hpYURpDpl6qdPcb2r/MU2dtTdAQ\"",
		"mtime": "2026-08-04T04:05:25.866Z",
		"size": 330,
		"path": "../public/assets/shopping-bag-C4oUoYQr.js"
	},
	"/assets/sparkles-DEA_PfZq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e4-rkmLEDp1rsva3X76nqcB67RRE48\"",
		"mtime": "2026-08-04T04:05:25.866Z",
		"size": 484,
		"path": "../public/assets/sparkles-DEA_PfZq.js"
	},
	"/assets/tables-ggn9aHcS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6524-UzRyIvi783EGxz1gqJPSaLEfZhk\"",
		"mtime": "2026-08-04T04:05:25.866Z",
		"size": 25892,
		"path": "../public/assets/tables-ggn9aHcS.js"
	},
	"/assets/styles-CFHGwT_D.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1da36-kyFKIHjRG1vpTtM74Qa9+qgX5LA\"",
		"mtime": "2026-08-04T04:05:25.883Z",
		"size": 121398,
		"path": "../public/assets/styles-CFHGwT_D.css"
	},
	"/assets/tabs-3IMmf5Z9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc1-XRl5KYZyUP+XpnO4cSvUR4eFPEM\"",
		"mtime": "2026-08-04T04:05:25.872Z",
		"size": 3521,
		"path": "../public/assets/tabs-3IMmf5Z9.js"
	},
	"/assets/tableService-XEANq6m1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a8-EhlJAKnoygTyPJlYrjsiTr2Cszc\"",
		"mtime": "2026-08-04T04:05:25.866Z",
		"size": 1192,
		"path": "../public/assets/tableService-XEANq6m1.js"
	},
	"/assets/textarea-POTtlmid.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"238-B2gf2ay5tlzRmLS7FmG6G1kG2xQ\"",
		"mtime": "2026-08-04T04:05:25.872Z",
		"size": 568,
		"path": "../public/assets/textarea-POTtlmid.js"
	},
	"/assets/theme-OCddHRa-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ec-m4kFwfI6oOCtBieDSety7vxKsVI\"",
		"mtime": "2026-08-04T04:05:25.872Z",
		"size": 748,
		"path": "../public/assets/theme-OCddHRa-.js"
	},
	"/assets/switch-Ci65R1E4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10d6-ONzzLOT07+J6cfIAawMwt+4/Mhk\"",
		"mtime": "2026-08-04T04:05:25.866Z",
		"size": 4310,
		"path": "../public/assets/switch-Ci65R1E4.js"
	},
	"/assets/user-check-DbHWB7GO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e9-T6SJmoEVRrGCeIf6uE3MOTeYj34\"",
		"mtime": "2026-08-04T04:05:25.872Z",
		"size": 233,
		"path": "../public/assets/user-check-DbHWB7GO.js"
	},
	"/assets/upload-CUMf9aqW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc-MEfS7fUvIS8SfuxqzfLbD87vn/I\"",
		"mtime": "2026-08-04T04:05:25.872Z",
		"size": 220,
		"path": "../public/assets/upload-CUMf9aqW.js"
	},
	"/assets/triangle-alert-Bk8x8Ng_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ff-zHJ2CklSDsTqhefimyyD8tAh6EM\"",
		"mtime": "2026-08-04T04:05:25.872Z",
		"size": 255,
		"path": "../public/assets/triangle-alert-Bk8x8Ng_.js"
	},
	"/assets/useMutation-Cd7RZ6BP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8fd-MaToekKggUq76LAghktpgOXqgCY\"",
		"mtime": "2026-08-04T04:05:25.872Z",
		"size": 2301,
		"path": "../public/assets/useMutation-Cd7RZ6BP.js"
	},
	"/assets/trash-2-Dp81ID2Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13e-frazy88ex4CEyiRO88cdtjI2EwU\"",
		"mtime": "2026-08-04T04:05:25.872Z",
		"size": 318,
		"path": "../public/assets/trash-2-Dp81ID2Q.js"
	},
	"/assets/waitlist-aZDJmUHt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27de-sOlgVT+PyD4KHhtKNsnFbCxutwY\"",
		"mtime": "2026-08-04T04:05:25.881Z",
		"size": 10206,
		"path": "../public/assets/waitlist-aZDJmUHt.js"
	},
	"/assets/waitlistService-Dg9Z5PhY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fc-OvyKWK8OCEWEzzLKfEc0ZieKHxE\"",
		"mtime": "2026-08-04T04:05:25.883Z",
		"size": 252,
		"path": "../public/assets/waitlistService-Dg9Z5PhY.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_2DMfiM = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_2DMfiM
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
